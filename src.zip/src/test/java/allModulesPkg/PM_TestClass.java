package allModulesPkg;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
//import pmObjectPkg.PMObjectClasss;

public class PM_TestClass {
	Login ObjectsOfLoginClass = new Login();
	PM_ObjectClasss ObjectsOfPMObjectClass = new PM_ObjectClasss();
	BaseClass ObjectsOfBaseClass = new BaseClass();	

	@Test(priority = 1, enabled = false)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Jun");	
	}
	@Test(priority = 2, enabled = true)
	public void PMNavigation() throws InterruptedException{
		ObjectsOfPMObjectClass.Navigation();		
	}

	@Test(priority = 3, enabled = false)
	public void SwitchToPMPage() throws InterruptedException{
		ObjectsOfPMObjectClass.SwitchTab();
	}
	@Test
	public void Test_AddSOWButton() throws InterruptedException{
		ObjectsOfPMObjectClass.AddSOWButton();
	}
	@Test(priority = 3, enabled = false)
	public void CreateSOW(String SOWCode, String SOWTitle, int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SOW(SOWCode, SOWTitle);
		ObjectsOfPMObjectClass.GetSOWCode();
		ObjectsOfPMObjectClass.WriteSOWCodeToExcel(row, column);
	}
	@Test
	public void Test_CreateSOWNegative() throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SOW_NegativeTitle("Negative", "Negative");
	}
	@Test(priority =4, enabled = false)
	public void Test_EditSOWTitle(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.EditSOWTitle();
	}

	@Test
	public void Test_EditSOWTitleByFileUpload(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.EditSOWTitleByFileUpload();
	}
	@Test
	public void Test_UpdateSOWBudgetAdd(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.UpdateSOWBudgetAdd();
	}

	@Test
	public void Test_UpdateSOWBudgetReduce(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.UpdateSOWBudgetReduce();
	}

	@Test
	public void Test_UpdateSOWBudgetRestructure(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.UpdateSOWBUdgetRestructure();
	}


	@Test
	public void Test_ViewProjectsOfSOW(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.ViewProjectsOfSOW();
	}

	@Test
	public void Test_CloseSOW(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.CloseSOW();
	}

	@Test
	public void Test_SearchExistingSOW(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
	}

	@Test
	public void Test_SOWShowHistory(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.SOWShowHistory();		
	}

	@Test
	public void Test_ViewSOW(int row, int column) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.ViewSOW();
	}

	@Test
	public void Test_AddProjectButtonMain(){
		ObjectsOfPMObjectClass.AddProjectButtonMain();
	}

	@Test
	public void Test_AddProjectSOWOption(int row, int column) throws InterruptedException, IOException{		
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(row, column));
		ObjectsOfPMObjectClass.AddProjectSOWOption();		
	}

	@Test
	public void CreateDelNonStandardProjectThroughAddProjectButton(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAddProjectBUTTON(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		//Objects.SelectSOWthroughAllSOWTAB("Test_SOWCode-SOW");
		//ObjectsOfPMObjectClass.AddProjectSOWOption(); not required as this required when project is added through AllSowTab
		ObjectsOfPMObjectClass.ProjectType("Deliverable");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test(priority = 4, enabled = false)
	public void CreateDelNonStandardProjectThroughAllSOWTab(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		//Objects.SelectSOWthroughAddProjectBUTTON("Test_SOWCode-SOW");
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		ObjectsOfPMObjectClass.AddProjectSOWOption();
		ObjectsOfPMObjectClass.ProjectType("Deliverable");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");		
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateDelStandardProjectThroughAddProjectButton(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAddProjectBUTTON(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		//Objects.SelectSOWthroughAllSOWTAB("Test_SOWCode-SOW");
		//ObjectsOfPMObjectClass.AddProjectSOWOption(); not required as this required when project is added through AllSowTab
		ObjectsOfPMObjectClass.ProjectType("Deliverable");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.StandardTimeline("Narrative - Long");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);		
	}

	@Test
	public void CreateDelStandardProjectThroughAllSOWTab(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		ObjectsOfPMObjectClass.AddProjectSOWOption();
		ObjectsOfPMObjectClass.ProjectType("Deliverable");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");		
		ObjectsOfPMObjectClass.StandardTimeline("Narrative - Long");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateHourlyNonStandardProjectThroughAddProjectButton(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAddProjectBUTTON(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		//Objects.SelectSOWthroughAllSOWTAB("Test_SOWCode-SOW");
		//ObjectsOfPMObjectClass.AddProjectSOWOption();  not required as this required when project is added through AllSowTab
		ObjectsOfPMObjectClass.ProjectType("Hours");
		ObjectsOfPMObjectClass.ManageFianceHourly("1.25", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateHourlyNonStandardProjectThroughAllSOWTab(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		ObjectsOfPMObjectClass.AddProjectSOWOption();
		ObjectsOfPMObjectClass.ProjectType("Hours");
		ObjectsOfPMObjectClass.ManageFianceHourly("1.25", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}


	@Test(priority = 7, enabled = false)
	public void CreateHourlyStandardProjectThroughAddProjectButton(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAddProjectBUTTON(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		//Objects.SelectSOWthroughAllSOWTAB("Test_SOWCode-SOW");
		//	ObjectsOfPMObjectClass.AddProjectSOWOption();  not required as this required when project is added through AllSowTab
		ObjectsOfPMObjectClass.ProjectType("Hours");
		ObjectsOfPMObjectClass.ManageFianceHourly("1.25", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.StandardTimeline("Narrative - Long");	
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateHourlyStandardProjectThroughAllSOWTab(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		ObjectsOfPMObjectClass.AddProjectSOWOption();
		ObjectsOfPMObjectClass.ProjectType("Hours");
		ObjectsOfPMObjectClass.ManageFianceHourly("1.25", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.StandardTimeline("Narrative - Long");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateFTENonStandardProjectThroughAddProjectButton(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAddProjectBUTTON(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		//Objects.SelectSOWthroughAllSOWTAB("Test_SOWCode-SOW");
		//	ObjectsOfPMObjectClass.AddProjectSOWOption();  not required as this required when project is added through AllSowTab
		ObjectsOfPMObjectClass.ProjectType("FTE");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);
	}

	@Test
	public void CreateFTENonStandardProjectThroughAllSOWTab(int SOWrow, int SOWcolumn, int ProjectCoderow, int ProjectCodecolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
		ObjectsOfPMObjectClass.AddProjectSOWOption();
		ObjectsOfPMObjectClass.ProjectType("FTE");
		ObjectsOfPMObjectClass.ManageFinanceDel("2.5", "Test_PONo6_Auto-Test_POName6_Auto");
		ObjectsOfPMObjectClass.ProjectAttributes("Test_SD1_Auto");
		ObjectsOfPMObjectClass.NonStanadardTimeline("Abstract");
		ObjectsOfPMObjectClass.GetProjectCode();
		ObjectsOfPMObjectClass.WriteProjectCodeToExcel(ProjectCoderow, ProjectCodecolumn);		
	}

	@Test
	public void SearchProject(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
	}

	@Test
	public void SearchSOW(int SOWrow, int SOWcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SelectSOWthroughAllSOWTAB(ObjectsOfPMObjectClass.ReadFromExcel(SOWrow, SOWcolumn));
	}

	@Test(priority = 9, enabled = false)
	public void Test_ConfirmProject(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ConfirmProject();	
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn)); //wherever status change validation requires
	}

	@Test
	public void Test_ConfirmProjectLineitem(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ConfirmLineitem();
	}

	@Test
	public void Test_ViewProjectDetails(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ViewProjectDetails();
	}

	@Test
	public void Test_EditProject(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.EditProject();
	}

	@Test
	public void Test_ProjectCommunications(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectCommunications();
	}

	@Test
	public void Test_ProjectTimeline(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectTimeline();
	}

	@Test
	public void Test_ProjectGoToAllocation(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectGoToAllocation();
		ObjectsOfBaseClass.SwitchToChildModule();
	}

	@Test
	public void Test_ProjectScope(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectScope();
		ObjectsOfBaseClass.SwitchToChildModule();
	}

	@Test
	public void Test_ViewProjectCDsPFs(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ViewProjectCDsPFs();
	}

	@Test
	public void Test_ViewPubSupport(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ViewPubSupport();
	}

	@Test
	public void Test_ProjectManageFinance(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectManageFinance();
	}

	@Test
	public void Test_ProjectChangeSOW(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectChangeSOW();
	}

	@Test
	public void Test_ProjectExpense(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectExpense();
	}

	@Test
	public void Test_ProjectShowHistory(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectShowHistory();
	}

	@Test(priority = 10, enabled = false)
	public void ProposeCloseProject_LineitemScheduled_Negative(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProposeClosureAction_Negative();
	}

	@Test
	public void ProposeCloseProject(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProposeClosureAction();
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));	
	}

	@Test(priority = 14, enabled = false)
	public void ProjectOnHold(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectOnHoldAction();
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
	}

	@Test(priority = 15, enabled = false)
	public void ProjectOffHold(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.ProjectOffHoldAction();
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
	}

	@Test(priority = 11, enabled = true)
	public void CSAudit(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.CSAuditAction();
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
	}

	@Test(priority = 12, enabled = false)
	public void FinanceAudit(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.FinanceAuditAction();
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
	}
	
	@Test(priority = 13, enabled = false)
	public void CancelProject(int Projectrow, int Projectcolumn) throws InterruptedException, IOException{
		ObjectsOfPMObjectClass.SearchProjectAction(ObjectsOfPMObjectClass.ReadFromExcel(Projectrow, Projectcolumn));
		ObjectsOfPMObjectClass.CancelProjectAction("Price too High");
	}











	

	





	@Test
	public void Test_HomePageElements() throws InterruptedException{
		ObjectsOfPMObjectClass.HomePageElements();
	}



}
