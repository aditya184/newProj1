package allModulesPkg;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;


public class MyDashboard_TestClass {
	String ProjectCode = "PRA08-MSS-201488";
	String Milestone = "Kick Off";
	String Task = "Write";
	String ShortTitle = "(test)";
	String TaskName = ProjectCode+" "+Milestone+" "+Task+" "+ShortTitle;

	Login ObjectsOfLoginClass = new Login();
	MyDashboard_ObjClass ObjectsOfMyDashboardObjClass = new MyDashboard_ObjClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();
	
	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Apr");	
	}

	@Test
	public void MyDashBoardNavigation() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.Navigation();
		
	}
	
	@Test
	public void SwitchToMyDashBoardPage() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.SwitchTab();
	}
	
	
	@Test
	public void CloseOpenTasksPopUp() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.ClosePopUp();
	}
	
	
	@Test(priority = 4, enabled = true)
	public void CompleteTodayTask() throws InterruptedException, IOException{	
		ObjectsOfMyDashboardObjClass.OpenTasksToday(TaskName);
	}
		
	@Test(priority = 5, enabled = false)
	public void CompleteNext7DaysTask() throws InterruptedException, IOException{		
		ObjectsOfMyDashboardObjClass.OpenTasksNext7Days(TaskName);
	}
		
	@Test(priority = 6, enabled = false)
	public void CompleteNext14DaysTask() throws InterruptedException, IOException{		
		ObjectsOfMyDashboardObjClass.OpenTasksNext14Days(TaskName);
	}	
		
	@Test(priority = 7, enabled = false)
	public void CompletePast7DaysTask() throws InterruptedException, IOException{		
		ObjectsOfMyDashboardObjClass.OpenTasksPast7Days(TaskName);
	}
		
	@Test(priority = 8, enabled = false)
	public void CompletePast14DaysTask() throws InterruptedException, IOException{		
		ObjectsOfMyDashboardObjClass.OpenTasksPast14Days(TaskName);
	}
	
	@Test(priority = 9, enabled = false)
	public void ApplyFullDayLeave(String toDate, String fromDate) throws InterruptedException{
		ObjectsOfMyDashboardObjClass.FullDayLeave(toDate, fromDate);		
	}
	
	@Test
	public void ApplyHalfDayLeave(String toDate, String fromDate) throws InterruptedException{
		ObjectsOfMyDashboardObjClass.HalfDayLeave(toDate, fromDate);
	}
	
	@Test
	public void DeleteHalfDayLeave(String date) throws InterruptedException, ParseException{
		ObjectsOfMyDashboardObjClass.DeleteHalfDay(date);
	}
	
	@Test
	public void DeleteFullDayLeave(String date) throws InterruptedException, ParseException{
		ObjectsOfMyDashboardObjClass.DeleteFullDay(date);
	}
	
	//Delete Leave method needs to be written
	
	@Test(priority = 10, enabled = false)
	public void AddClientMeetingTraining() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.ClientMeetingTraining("Revamp_Praveen");
	}
	
	@Test(priority = 11, enabled = false)
	public void AddInternalMeeting() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.InternalMeeting();
	}
	
	@Test(priority = 12, enabled = false)
	public void AddTraining() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.Training();
	}
	
	@Test(priority = 13, enabled = false)
	public void AddAdminWork() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.Admin();
	}
	
	@Test(priority = 14, enabled = false)
	public void MyrojectsElements(){
		ObjectsOfMyDashboardObjClass.MyProjects();
	
	}
	
	@Test(priority = 15, enabled = false)
	public void MySOWElements(){
		ObjectsOfMyDashboardObjClass.MySOW();
		
	}
	
	public void MyCompletedTaskElements(){
		
	
		
	}
	
	@Test(priority = 16, enabled = false)
	public void SearchProject() throws InterruptedException{
		//Objects.SearchProjectWithCode("PRA08-ABS-201497");
		ObjectsOfMyDashboardObjClass.SearchProjectWithTitle("Test_Auto_Abstract");
	}
	
	@Test(priority = 17, enabled = false)
	public void AddFTETask(){
		ObjectsOfMyDashboardObjClass.FTETask();
	}
	
	@Test(priority = 18, enabled = false)
	public void TimeBooking() throws InterruptedException{
		ObjectsOfMyDashboardObjClass.AddTimeThroughTimeBooking("PRA08-NAR-201175");
	}
	
	
	
		//Objects.SelectTaskNext7Days(ProjectCode+" "+Milestone+" "+TaskName+" "+ShortTitle);
		
		//Objects.getTotalTaskNames("PRA08-MSS-201515"+" Outline"+" Inco");
		
	}
	
	
	
	

