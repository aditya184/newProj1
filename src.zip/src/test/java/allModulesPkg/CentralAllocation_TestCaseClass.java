package allModulesPkg;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CentralAllocation_TestCaseClass extends Login{

	CentralAllocation_TestClass ObjectsOfTestActionsClass = new CentralAllocation_TestClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	Login ObjectsOfLoginClass = new Login();
	
	By ClientFilter = By.xpath("//th[@ng-reflect-ng-switch='ClientName']/p-multiselect");
	By ProjectCodeFilter = By.xpath("//th[@ng-reflect-ng-switch='ProjectCode']/p-multiselect");
	By TaskFilter = By.xpath("//th[@ng-reflect-ng-switch='Task']/p-multiselect");
	By StartDateFilter = By.xpath("//th[@ng-reflect-ng-switch='StartDateText']/p-multiselect");
	By EndDateFilter = By.xpath("//th[@ng-reflect-ng-switch='DueDateText']/p-multiselect");
	By MilestoneFilter = By.xpath("//th[@ng-reflect-ng-switch='Milestone']/p-multiselect");
	By NextTaskStartDate_NegativeValPoint = By.xpath("//th[@ng-reflect-ng-switch='NextTaskStartDate']/p-multiselect");
	By LastTaskStartDate_NegativeValPoint = By.xpath("//th[@ng-reflect-ng-switch='LastTaskStartDate']/p-multiselect");
	By SendToClientDate_NegativeValPoint = By.xpath("//th[@ng-reflect-ng-switch='SendtoClientDate']/p-multiselect");

	By selectedFilterValue_ValPoint = By.xpath("//li[@class='ui-multiselect-item ui-corner-all ui-state-highlight']");
	By HyperLink_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[3]//a");
	By TaskScope_ValPoint = By.xpath("//div[@class='ui-card-header ng-star-inserted']//p-header[contains(text(),'Scope')]");
	
	By AllocationTask_ValPoint = By.xpath("//div[@class='ui-toast-detail' and text()='Slots updated Sucessfully']");
	
	String ResPath1 = "//p-dropdown[contains(@class,'resourceDropdown')]//div[@class='ui-dropdown-label-container']//label[contains(text(),";
	String ResPath2 = ")]";
	//To validate whether 'Client Name' column is having Filter
	@Test(enabled = false)
	public void TC1_ValidateClientColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ClientFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the Client Name.
	@Test(enabled = false)
	public void TC2_ValidateApplyClientFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("Client", "June24");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[text()='June24']");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether 'Project Name' column is having Filter
	@Test(enabled = false)
	public void TC3_ValidateProjectColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ProjectCodeFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the Project Name.
	@Test(enabled = false)
	public void TC4_ValidateApplyProjectFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("Project", "CLE22-ABS-200339");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td//a[text()='CLE22-ABS-200339']");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether 'Task Name' column is having Filter
	@Test(enabled = false)
	public void TC5_ValidateTaskColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TaskFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the Task Name.
	@Test(enabled = false)
	public void TC6_ValidateApplyTaskFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("Task", "Edit");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[text()='Edit']");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether 'Start Date' column is having Filter
	@Test(enabled = false)
	public void TC7_ValidateStartDateColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(StartDateFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the Start Date.
	@Test(enabled = false)
	public void TC8_ValidateApplyStartDateFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("StartDate", "1 Dec, 2020, 11:45 AM");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[text()='1 Dec, 2020, 11:45 AM']");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate whether 'End Date' column is having Filter
	@Test(enabled = false)
	public void TC9_ValidateEndDateColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(EndDateFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the End Date.
	@Test(enabled = false)
	public void TC10_ValidateApplyEndDateFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("EndDate", "1 Dec, 2020, 12:00 PM");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[text()='1 Dec, 2020, 12:00 PM']");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Date(Next Task Start Date) column is having Filter.//TC11,TC12
	@Test(enabled = false)
	public void TC11_ValidateNextTaskStartDateFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(NextTaskStartDate_NegativeValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Date(Last Task Start Date) column is having Filter. //TC13,TC14
	@Test(enabled = false)
	public void TC13_ValidateLastTaskStartDateFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(LastTaskStartDate_NegativeValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Date(Send to Client Date) column is having Filter.//TC15,TC16
	@Test(enabled = false)
	public void TC15_ValidateValidateSendtoClientDateFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(SendToClientDate_NegativeValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether 'Milestone' column is having Filter
	@Test(enabled = false)
	public void TC17_ValidateMilestoneColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(MilestoneFilter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to filter the Milestone Name.
	@Test(enabled = false)
	public void TC18_ValidateApplyMilestoneFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.SelectFilter("Milestone", "Draft 2");
		TimeUnit.SECONDS.sleep(1);
		By FilterData_ValPoint = By.xpath("//div[@class='allocatedUnallocatedTable ng-star-inserted']//td[contains(text(),'Draft 2')]");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(FilterData_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Project ID is containing hyperlink.
	@Test(enabled = false)
	public void TC19_ValidateProjectCodeHyperLink() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(HyperLink_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is getting navigated to Project task details when clicked on 'Project ID'.
	@Test(enabled = false)
	public void TC20_NavigateToProjectTaskDetails() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(HyperLink_ValPoint));
		driver.findElement(HyperLink_ValPoint).click();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Task Scope' of a particular task.
	@Test(enabled = true)
	public void TC21_ValidateTaskScope() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.ValidateTaskScope("JUN24-ANX-200074","Final Draft","GraphicsSlot 2","Review-Graphics");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TaskScope_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC36_AllocationOfQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","QCSlot","QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC37_AllocationOfReviewQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","QCSlot","Review-QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC38_AllocationOfEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","EditSlot","Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC39_AllocationOfReviewEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","EditSlot","Review-Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC40_AllocationOfGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC41_AllocationOfReviewGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Review-Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Galley task through Centralized Allocation.
	@Test(enabled = false)
	public void TC42_AllocationOfGalleyTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","GalleySlot","Galley", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC43_AllocationOfIncoQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","QCSlot","Inco-QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC44_AllocationOfIncoEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","EditSlot","Inco-Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC45_AllocationOfIncoGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Unallocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Inco-Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to QC task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC60_AssignResourceQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200078","Outline","QCSlot","QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to QC task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC61_ReAssignResourceQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","CLE22-DTN-200071","Kick Off","QCSlot","QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Review QC task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC62_AssignResourceReviewQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200119","Outline","QCSlot","Review-QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Review QC task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC63_ReAssignResourceReviewQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-CER-200082","Draft 1","QCSlot","Review-QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Edit task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC64_AssignResourceEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-CER-200113","Draft 1","EditSlot","Edit","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Edit task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC65_ReAssignResourceEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-ERE-200002","Pre Kick-Off","EditSlot","Edit","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Review-Edit task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC66_AssignResourceReviewEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-CER-200113","Draft 1","EditSlot","Review-Edit","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Review-Edit task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC67_ReAssignResourceReviewEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-ERE-200002","Pre Kick-Off","EditSlot","Review-Edit","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Graphics task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC68_AssignResourceGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","CLE22-DTN-200071","Kick Off","GraphicsSlot","Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Graphics task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC69_ReAssignResourceGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","GraphicsSlot","Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Review-Graphics task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC70_AssignResourceReviewGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200078","Draft 1","GraphicsSlot","Review-Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Review-Graphics task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC71_ReAssignResourceReviewGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","GraphicsSlot","Review-Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Galley task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC72_AssignResourceGalleyTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200078","Draft 1","GalleySlot","Galley","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Galley task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC73_ReAssignResourceGalleyTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","GalleySlot","Galley","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Inco-QC task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC74_AssignResourceIncoQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200119","Outline","QCSlot","Inco-QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to Inco-Edit  task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC75_AssignResourceIncoEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200078","Draft 1","EditSlot","Inco-Edit ","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to assign Resource to  Inco-Graphics task through 'CentralizedAlloctaion' page
	@Test(enabled = false)
	public void TC76_AssignResourceIncoGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Unallocated","JUN24-BER-200078","Draft 1","GraphicsSlot","Inco-Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Re-Assign the Resource to Inco-QC task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC77_ReAssignResourceIncoQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","QCSlot","Inco-QC","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate whether user is able to Re-Assign the Resource to Inco-Edit task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC78_ReAssignResourceIncoEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","EditSlot","Inco-Edit","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate whether user is able to Re-Assign the Resource to Inco-Graphics task through CentralizedAllocation page
	@Test(enabled = false)
	public void TC79_ReAssignResourceIncoGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AssignResource("Allocated","JUN24-BER-200104","Draft 1","GraphicsSlot","Inco-Graphics","Test SP");
		By ResourceDropdown = By.xpath(ResPath1+"\"Test SP\""+ResPath2);	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResourceDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	//To validate 'Search' filter functionality with 'Client Name' value under 'Unallocated' section
	@Test(enabled = false)
	public void TC80_ValidateGlobalFilterForClient() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.GlobalFilter("Unallocated","June24");
//		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TaskScope_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	
	//To validate whether user is able to allocate QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC111_AllocationOfQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","QCSlot","QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC112_AllocationOfReviewQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","QCSlot","Review-QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC113_AllocationOfEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","EditSlot","Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC114_AllocationOfReviewEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","EditSlot","Review-Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC115_AllocationOfGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Review-Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC116_AllocationOfReviewGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Review-Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Galley task through Centralized Allocation.
	@Test(enabled = false)
	public void TC117_AllocationOfGalleyTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","GalleySlot","Galley", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-QC task through Centralized Allocation.
	@Test(enabled = false)
	public void TC118_AllocationOfIncoQCTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","QCSlot","Inco-QC", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-Edit task through Centralized Allocation.
	@Test(enabled = false)
	public void TC119_AllocationOfIncoEditTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","EditSlot","Inco-Edit", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to allocate Inco-Graphics task through Centralized Allocation.
	@Test(enabled = false)
	public void TC120_AllocationOfIncoGraphicsTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CentralAllocationNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCentralAllocationPage();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.AllocateTask("Allocated","JUN24-BER-200119","Draft 1","GraphicsSlot","Inco-Graphics", "Test SP");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AllocationTask_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
}
