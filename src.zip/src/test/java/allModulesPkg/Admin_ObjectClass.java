package allModulesPkg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
public class Admin_ObjectClass extends Login{

	BaseClass ObjectsOfBaseClass = new BaseClass();		

	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By AdminLink = By.xpath("//a[text()='Admin']");	
	
	//page buttons
	By AddNewClientFormButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add New Client Form']");
	By AddNewUserButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add New User']");	
	By AddButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add']");

	By UserProfileTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='User Profile']");
	By AttributeTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Attribute']");
	By ProjectTypeTab = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and text()=' Project Types ']");
	By DeliverableTypeTab = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and text()=' Deliverable Types ']");
	By TATab = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and text()=' Therapeutic Areas (TA) ']");
	By PracticeAreaTab = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and text()=' Practice Areas ']");
	By EntitlementTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Entitlement']");
	By CopyPermissionTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Copy Permission']");
	By AddUserToSOWTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Add User To SOW']");
	By AddUserToProjectsTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Add User To Projects']");
	By AddGroupDescription = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Add Group Description']");
	By AddPermissionButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Permission']");
	
	
	//Dialogue buttons
	By DialogueSaveButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Save']");
	By DialogueUpdateButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Update']");
	By DialogueAddNewSubDivisionButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add New Sub-Division']");
	By DialogueSubmitButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Submit']");
	By DialogueAddNewPOCButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add New POC']");
	By DialogueAddNewPOButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add New Purchase Order']");
	By DialogueYesButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Yes']");
	By DialogueNoButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='No']");	
	

	//Dialogue TextFields
	By DialogueNameTextField = By.xpath("//input[@formcontrolname='name']");
	By DialogueAcronymTextField = By.xpath("//input[@formcontrolname='acronym']");
	By DialogueDistributionListTextField = By.xpath("//input[@formcontrolname='distributionList']");
	By DialogueInvoiceNameTextField = By.xpath("//input[@formcontrolname='invoiceName']");
	By DialogueRealiazationTextField = By.xpath("//input[@formcontrolname='realization']");
	By DialogueAPEmailTextField = By.xpath("//input[@formcontrolname='APEmail']"); 
	By DialogueNotesTextField = By.xpath("//textarea[@formcontrolname='notes']");
	By DialogueAdd1TextField = By.xpath("//input[@formcontrolname='address1']");
	By DialogueAdd2TextField = By.xpath("//input[@formcontrolname='address2']");
	By DialogueAdd3TextField = By.xpath("//input[@formcontrolname='address3']");
	By DialogueAdd4TextField = By.xpath("//input[@formcontrolname='address4']");
	By DialogueSubDivisionNameTextField = By.xpath("//input[@formcontrolname='subDivision_Name']");
	By DistributionListTextField = By.xpath("//input[@formcontrolname='distributionList']");
	By DialogueFirstNameTextField = By.xpath("//input[@formcontrolname='fname']");
	By DialogueLastNameTextField = By.xpath("//input[@formcontrolname='lname']");
	By DialogueDesignationTextField = By.xpath("//input[@formcontrolname='designation']");
	By DialogueEmailTextField = By.xpath("//input[@formcontrolname='email']");
	By DialoguePhoneTextField = By.xpath("//input[@formcontrolname='phone']");
	By DialogueDepartmentTextField = By.xpath("//input[@formcontrolname='department']");
	By DialogueEngagementPlanTextField = By.xpath("//textarea[@formcontrolname='engagementPlan']");
	By DialogueCommentsTextField = By.xpath("//textarea[@formcontrolname='comments']");
	By DialoguePONumbrTextField = By.xpath("//input[@formcontrolname='poNumber']");
	By DialoguePONameTextField = By.xpath("//input[@formcontrolname='poName']");
	By DialogueRevenueTextField = By.xpath("//input[@formcontrolname='revenue']");
	By DialogueOOPTextField = By.xpath("//input[@formcontrolname='oop']");
	By DialogueTaxTextField = By.xpath("//input[@formcontrolname='tax']");
	By DialogueUserNameTextField = By.xpath("//input[@placeholder='User Name']");
	By DialogueManagerTextField = By.xpath("//input[@placeholder='Manager']");	
	By DialogueMaxHrsTextField = By.xpath("//input[@formcontrolname='maxHrs']");
	By DialogueReadyToTextField = By.xpath("//textarea[@formcontrolname='readyTo']");
	
	
	//page text box
	By BucketTextBox = By.xpath("//input[@id='float-input']");
	By ProjectTypeTextBox = By.xpath("//input[@id='float-input']|//label[text()='Project Type']");
	By DeliverableTypeTextBox = By.xpath("//input[@id='float-input']|//label[text()='Deliverable Type']");
	By AcronymTextBox = By.xpath("//input[@id='float-input-acronym']");
	By TATextBox = By.xpath("//input[@id='float-input']|//label[text()='Therapeutic Area']");
	By PracticeAreaTextBox = By.xpath("//input[@id='float-input']|//label[text()='Practice Area']");
	
	
	
	
	
	By DialogueDatePicker = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");	
	By DialogueDateOfJoining = By.xpath("//p-calendar[@formcontrolname='dateofjoin']//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");
	By DialogueGoLiveDate = By.xpath("//p-calendar[@formcontrolname='liveDate']//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");
	
	
	
	//Page Dropdown
	By CLEDropdown = By.xpath("//p-multiselect[@defaultlabel='Client Legal Entry']");
	By UserDropdown = By.xpath("//th[@ng-reflect-ng-switch='User']//p-multiselect|//p-multiselect[@defaultlabel='Select User']");
	By BucketDropdown = By.xpath("//p-multiselect[@defaultlabel='Bucket']");
	By ProjectTypeDropdown = By.xpath("//p-multiselect[@defaultlabel='Project Type']");
	By DelTypeDropdown = By.xpath("//p-multiselect[@defaultlabel='Deliverable Type']");
	By TADropdown = By.xpath("//p-multiselect[@defaultlabel='Therapeutic Area']");
	By PracticeAreaDropdown = By.xpath("//p-multiselect[@defaultlabel='Practice Area']");
	By CopyAddPermissionDropdown = By.xpath("//p-dropdown[@placeholder='Select User']");
	
	

	//Dialogue Dropdowns
	By DialogueGroupDropdown = By.xpath("//p-dropdown[@formcontrolname='group']//*[@class='ui-dropdown-trigger ui-state-default ui-corner-right']");
	By DialogueMarketDropdown = By.xpath("//p-dropdown[@formcontrolname='market']");
	By DialogueBillingEntityDropdown = By.xpath("//p-dropdown[@formcontrolname='billingEntry']");
	By DialoguePORequiredDropdown = By.xpath("//p-dropdown[@formcontrolname='poRequired']");
	By DialogueTimeZoneDropdown = By.xpath("//p-dropdown[@formcontrolname='timeZone']");
	By DialogueCML1Dropdown = By.xpath("//p-multiselect[@formcontrolname='cmLevel1']");
	By DialogueCML2Dropdown = By.xpath("//p-dropdown[@formcontrolname='cmLevel2']");
	By DialogueDelL1Dropdown = By.xpath("//p-multiselect[@formcontrolname='deliveryLevel1']");
	By DialogueDelL2Dropdown = By.xpath("//p-dropdown[@formcontrolname='deliveryLevel2']");
	
	By DialogueCurrencyDropdown = By.xpath("//p-dropdown[@formcontrolname='currency']");
	//By DialogueCurrencyDropdown = By.xpath("//p-dropdown[@formcontrolname='currency']//*[@class='ui-dropdown-trigger ui-state-default ui-corner-right']");
	By DialogueBucketDropdown = By.xpath("//p-dropdown[@formcontrolname='bucket']");
	By DialogueSubDivisionDropdown = By.xpath("//p-multiselect[@defaultlabel='Sub-Division']");
	By DialogueRefSourceDropdown = By.xpath("//p-dropdown[@formcontrolname='referralSource']//*[@class='ui-dropdown-trigger ui-state-default ui-corner-right']");
	By DialogueContactsTypeDropdown = By.xpath("//p-dropdown[@formcontrolname='contactsType']");
	By DRelationshipStrengthDropdown = By.xpath("//p-dropdown[@formcontrolname='relationshipStrength']");
	By DialogueFirstNameDropdown = By.xpath("//p-multiselect[@defaultlabel='First Name']");
	
	By DialoguePOCDropdown = By.xpath("//p-dropdown[@formcontrolname='poc']");
	//By DialoguePOCDropdown = By.xpath("//p-dropdown[@formcontrolname='poc']//*[@class='ui-dropdown-trigger ui-state-default ui-corner-right']");
	By DialogueTADropdown = By.xpath("//p-dropdown[@formcontrolname='ta']");
	By DialogueMoleculeDropdown = By.xpath("//p-dropdown[@formcontrolname='molecule']");
	By DialoguePOBuyingEntityDropdown = By.xpath("//p-dropdown[@formcontrolname='poBuyingEntity']");
	By DialoguePONameDropdown = By.xpath("//p-multiselect[@defaultlabel='Po Name']");
	By DialoguePONoDropdown = By.xpath("//p-multiselect[@defaultlabel='Po Number']");
	By DialogueInCapacityDropdown = By.xpath("//p-dropdown[@formcontrolname='inCapacity']");
	By DialoguePADropdown = By.xpath("//p-multiselect[@formcontrolname='practiceArea']");
	By DialogueSkillLevelDropdown = By.xpath("//p-dropdown[@formcontrolname='skillLevel']");
	By DialoguePrimarySkillsDropdown = By.xpath("//p-dropdown[@formcontrolname='primarySkill']");
	By DialogueRoleDropdown = By.xpath("//p-dropdown[@formcontrolname='role']");
	By DialoguePooledDropdown = By.xpath("//p-dropdown[@formcontrolname='pooled']");
	By DialogueTaskDropdown = By.xpath("//p-multiselect[@formcontrolname='task']");
	By DialogueDeliverableDropdown = By.xpath("//p-multiselect[@formcontrolname='deliverable']");
	By DialogueDelExclusionDropdown = By.xpath("//p-multiselect[@formcontrolname='deliverableExclusion']");
	By DialogueTAExclusionDropdown = By.xpath("//p-multiselect[@formcontrolname='taExclusion']");
	By DialogueTAVisibilityDropdown = By.xpath("//p-dropdown[@formcontrolname='taVisibility']");
	By DialogueIsFTEDropdown = By.xpath("//p-dropdown[@formcontrolname='isFTE']");
	By DialogueAccountDropdown = By.xpath("//p-multiselect[@formcontrolname='account']");
	By DialogueCAvisibilityDropdown = By.xpath("//p-dropdown[@formcontrolname='caVisibility']");
	
	
	
	
	
	By DialogueUploadButton_10 = By.xpath("//div[@class='p-col-8']");
	

	By DialogueCloseIcon = By.xpath("//span[@class='pi pi-times']");

	By PagepMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By DialoguepMenu = By.xpath("//div[@role='dialog']//i[@class='pi pi-ellipsis-v']");

	By EditOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Edit']");
	By DeleteOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Delete']");
	By SubDivisionOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Sub-Division Details']");
	By POCOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Point of Contact']");
	By PurchaeOrderOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Purchase Order']");
	By ChangeBudgetOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Change Budget']");
	
	//Radio buttons
	By AddRadioButton = By.xpath("//div[@class='ui-radiobutton ui-widget']");
	By ReduceRadioButton = By.xpath("//p-radiobutton[@inputid='selectedValue']//input[@value='Reduce']");
	By RestructureRadioButton = By.xpath("//p-radiobutton[@inputid='selectedValue']//input[@value='Restructure']");
	


	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AdminLink).click();				
	}

	public void SwitchTab() throws InterruptedException{		
		TimeUnit.SECONDS.sleep(2);   ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));		
	}

	public void AddNewClient(String ClientName, String Acronym, String Group) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddNewClientFormButton));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddNewClientFormButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueSaveButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNameTextField).sendKeys(ClientName);		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAcronymTextField).sendKeys(Acronym);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueGroupDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown(Group);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDistributionListTextField).sendKeys("praveen.amancha@cactusglobal.com");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueInvoiceNameTextField).sendKeys("Test_INVName");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRealiazationTextField).sendKeys("95.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueMarketDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("USA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueBillingEntityDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("CAUS-CACTUS USA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePORequiredDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Yes");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueTimeZoneDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Central America (US&Canada)");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCML1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Sneha Danduk");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueCML1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCML2Dropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDelL1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Maxwell Fargose");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueDelL1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Test SP");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDelL2Dropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Maxwell Fargose");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCurrencyDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("USD");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueBucketDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Others");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAPEmailTextField).sendKeys("praveen.amancha@cactusglobal.com");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNotesTextField).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNotesTextField).sendKeys("Test_Notes");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAdd1TextField).sendKeys("Test_Address1");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd2TextField).sendKeys("Test_Address2");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd3TextField).sendKeys("Test_Address3");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd4TextField).sendKeys("Test_Address4");
		TimeUnit.SECONDS.sleep(2);				
		driver.findElement(DialogueSaveButton).click();
	}

	public void SearchClient(String ClientName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(CLEDropdown));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(CLEDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(ClientName);
		TimeUnit.SECONDS.sleep(2);

	}	

	public void EditClientForm(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		driver.findElement(EditOption).click();
	}

	public void EditClientNotes() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNotesTextField).clear();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNotesTextField).sendKeys("Retest_Notes_Update");	

	}
	
	

	public void EditClientAddress() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAdd1TextField).clear();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAdd1TextField).sendKeys("Retest_Address1");		
	}

	public void UpdateAction() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();
	}

	public void SubDivisionDetails(String SubDivisionName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SubDivisionOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAddNewSubDivisionButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSubDivisionNameTextField).sendKeys(SubDivisionName);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueDistributionListTextField).sendKeys("praveen.amancha@cactusglobal.com");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueDelL1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Maxwell Fargose");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueDelL1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Test SP");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCML1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Sneha Danduk");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueCML1Dropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSubmitButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCloseIcon).click();		
	}

	public void EditSubDivision(String SubDivision) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SubDivisionOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSubDivisionDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(SubDivision);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(EditOption).click();						
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDistributionListTextField).clear();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDistributionListTextField).sendKeys("praveen1.amancha1@cactusglobal.com");
		UpdateAction();
		driver.findElement(DialogueCloseIcon).click();
	}

	public void POC(String POCFirstName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(POCOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAddNewPOCButton).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(DialogueSubmitButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueFirstNameTextField).sendKeys(POCFirstName);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueLastNameTextField).sendKeys("Test_Auto_LN1");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDesignationTextField).sendKeys("Test_QA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueEmailTextField).sendKeys("praveen.amancha@cactusglobal.com");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePhoneTextField).sendKeys("+91-8000000000");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDepartmentTextField).sendKeys("QA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRefSourceDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Client referral");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueContactsTypeDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Procurement");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DRelationshipStrengthDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Very Good");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAdd1TextField).sendKeys("Test_Address1");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd2TextField).sendKeys("Test_Address2");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd3TextField).sendKeys("Test_Address3");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueAdd4TextField).sendKeys("Test_Address4");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(DialogueEngagementPlanTextField).sendKeys("Test_EngagementPlan");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCommentsTextField).sendKeys("Test_Comments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSubmitButton).click();		
	}

	
	public void EditPOC(String POCFN) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(POCOption).click();		
		TimeUnit.SECONDS.sleep(2);		
		driver.findElement(DialogueFirstNameDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(POCFN);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(EditOption).click();						
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueEmailTextField).clear();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueEmailTextField).sendKeys("praveen1.amancha1@cactusglobal.com");
		UpdateAction();
		driver.findElement(DialogueCloseIcon).click();
		
	}
	
	public void PO(String PONumber, String POName, String Currency) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(PurchaeOrderOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAddNewPOButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueSaveButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONumbrTextField).sendKeys(PONumber);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONameTextField).sendKeys(POName);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRevenueTextField).clear();
		driver.findElement(DialogueRevenueTextField).sendKeys("10000.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("1000.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("1000.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCurrencyDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown(Currency);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDatePicker).click();
		TimeUnit.SECONDS.sleep(1);
		ObjectsOfBaseClass.DatepickerAdmin("31-December 2020");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePOCDropdown).click();		
		ObjectsOfBaseClass.SelectItemFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		List<WebElement> CommonButtons = driver.findElements(DialogueUploadButton_10);
		CommonButtons.get(9).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.UploadFile1();
		driver.findElement(DialogueTADropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Devices");
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueMoleculeDropdown).click();
		//ObjectsOfBaseClass.SelectItemFromDropdown("Abrilumab (AMG 181)");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueCML2Dropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePOBuyingEntityDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("US");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSaveButton).click();		
		TimeUnit.SECONDS.sleep(7);		
		driver.findElement(DialogueCloseIcon).click();
		
	}
	
	public void EditPO(String PONumber) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PurchaeOrderOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONoDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PONumber);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(EditOption).click();						
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDatePicker).click();
		TimeUnit.SECONDS.sleep(1);
		ObjectsOfBaseClass.DatepickerAdmin("30-December 2020");
		TimeUnit.SECONDS.sleep(2);
		List<WebElement> CommonButtons = driver.findElements(DialogueUploadButton_10);
		CommonButtons.get(9).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.UploadFile1();
		UpdateAction();
		TimeUnit.SECONDS.sleep(7);	
		driver.findElement(DialogueCloseIcon).click();
	}

	public void AddPOBudget(String PONumber) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PurchaeOrderOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONoDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PONumber);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ChangeBudgetOption).click();	
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AddRadioButton);
		AllRadio.get(0).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRevenueTextField).clear();
		driver.findElement(DialogueRevenueTextField).sendKeys("100.5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("50.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("10.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();
				
	}
	
	
	public void ReducePOBudget(String PONumber) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PurchaeOrderOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONoDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PONumber);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ChangeBudgetOption).click();	
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AddRadioButton);
		AllRadio.get(1).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRevenueTextField).clear();
		driver.findElement(DialogueRevenueTextField).sendKeys("-10.5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("-5.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("-1.5");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();
				
	}
	
	public void RestructurePOBudget(String PONumber) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PurchaeOrderOption).click();		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONoDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PONumber);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ChangeBudgetOption).click();	
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AddRadioButton);
		TimeUnit.SECONDS.sleep(2);
		System.out.println(AllRadio.size());		
		AllRadio.get(2).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRevenueTextField).clear();
		driver.findElement(DialogueRevenueTextField).sendKeys("10.5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("-5.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("-5.0");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();				
	}
	
	public void DeleteClient() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueNoButton).click();
		driver.findElement(DialogueYesButton).click();
		
	}
	
	public void DeleteSubDivision(String SubDivision) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SubDivisionOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSubDivisionDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(SubDivision);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueNoButton).click();
		driver.findElement(DialogueYesButton).click();
		
	}
	
	public void DeletePOC(String POCFN) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(POCOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueFirstNameDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(POCFN);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueNoButton).click();
		driver.findElement(DialogueYesButton).click();
	}
	
	public void DeletePO(String PONumber) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PagepMenu));
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PurchaeOrderOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePONoDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PONumber);
		driver.findElement(DialoguepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueNoButton).click();
		driver.findElement(DialogueYesButton).click();		
	}
	
	public void AddNewUserFTENo(String SkillLevel, String PrimarySkills, String MaxHrs, String Role) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(UserProfileTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(UserProfileTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddNewUserButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueSaveButton));
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(DialogueUserNameTextField).click();
		driver.findElement(DialogueUserNameTextField).sendKeys("Test SP");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueManagerTextField).sendKeys("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDesignationTextField).sendKeys("Test_QAE");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSaveButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSaveButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDateOfJoining).click();
		ObjectsOfBaseClass.Datepicker("10-June 2020");
		driver.findElement(DialogueGoLiveDate).click();
		ObjectsOfBaseClass.Datepicker("10-June 2020");
		driver.findElement(DialogueInCapacityDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Yes");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePADropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Devices");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSkillLevelDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown(SkillLevel);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueTimeZoneDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("India/Srilanka");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueBucketDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Others");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePrimarySkillsDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown(PrimarySkills);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueMaxHrsTextField).sendKeys(MaxHrs);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueRoleDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown(Role);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialoguePooledDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Yes");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueReadyToTextField).sendKeys("Test_ReadyTo");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueTaskDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Write");
		driver.findElement(DialogueTaskDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("QC");
		driver.findElement(DialogueTaskDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Inco-QC");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDeliverableDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Abstract");
		driver.findElement(DialogueDeliverableDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Poster");
		driver.findElement(DialogueDeliverableDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Annotations");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueIsFTEDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("No");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueAccountDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("Test_CLE_DB");		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSaveButton).click();	
	}
	
	public void EditUser(String UserName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(UserProfileTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(UserProfileTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(UserDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(UserName);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(EditOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueSaveButton));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueDesignationTextField).clear();
		driver.findElement(DialogueDesignationTextField).sendKeys("Re-Test_QA");
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogueSaveButton).click();			
	}
	
	public void Bucket() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(BucketTextBox).sendKeys("Test_Auto_Bucket");
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddButton).click();								
	}
	
	public void EditBucket(String BucketName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(BucketDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(BucketName);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(EditOption).click();
	}
	
	
	
	public void ProjectType() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectTypeTab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ProjectTypeTextBox).sendKeys("Test_Auto_ProjectType");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddButton).click();				
	}
	
	public void DeleteProjectType(String ProjectTypeName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectTypeTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectTypeDropdown).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(ProjectTypeName);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogueYesButton).click();				
	}
	
	public void DeliverableType() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DeliverableTypeTab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeliverableTypeTextBox).sendKeys("Test_Auto_DelType1");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AcronymTextBox).sendKeys("Test_Auto_Acronym");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddButton).click();	
	}
	
	public void DeleteDelType(String DelTypeName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DeliverableTypeTab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DelTypeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(DelTypeName);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();		
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogueYesButton).click();	
	}
	
	public void TA() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(TATab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(TATextBox).sendKeys("Test_Auto_TA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddButton).click();		
		
	}
	
	public void DeleteTA(String TAName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(TATab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(TADropdown).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(TAName);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogueYesButton).click();
		
	}
	
	
	public void PracticeArea() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(PracticeAreaTab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(TATextBox).sendKeys("Test_Auto_PracticeArea");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddButton).click();			
	}
	
	public void DeletePracticeArea(String PracticeAreaName) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AttributeTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AttributeTab).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(PracticeAreaTab).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PracticeAreaDropdown).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PracticeAreaName);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PagepMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteOption).click();	
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogueYesButton).click();
		
	}
		
}



