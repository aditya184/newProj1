package allModulesPkg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;


public class FD_ObjectClass extends Login{


	BaseClass ObjectsOgBaseClass = new BaseClass();		
	//Login ObjectsOfLoginClass = new Login();

	//public String ProformaNumber;


	/*//Constructor
	public FD_ObjectClass(WebDriver driver, WebDriverWait wait){				
		this.driver=driver;			
		this.wait=wait;
	}
	 */ //Constructor

	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By FinanceDashboardLink = By.xpath("//a[text()='Finance Dashboard']");
	By ScheduledTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Scheduled']");
	By HourlyBasedTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Hourly Based']");
	By OOPTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='OOP']");
	By ConfirmTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Confirmed']");	
	By ProformaTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Proforma']");
	By OutstandingInvoicesTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Outstanding Invoices']");
	By PaidInvoicesTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Paid Invoices']");
	By ApprovedBillableTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Approved(Billable)']");
	By ApprovedNonBillableTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Approved(Non Billable)']");
	

	By ProjectCodeDropdown = By.xpath("//th[@ng-reflect-ng-switch='ProjectCode']");
	By ProformaNumberDropdown = By.xpath("//th[@ng-reflect-ng-switch='ProformaNumber']");
	By InvoiceNumberDropdown = By.xpath("//th[@ng-reflect-ng-switch='DisplayInvoiceWithAuxiliary']");
	By SelectPODropdown = By.xpath("//p-dropdown[@placeholder='Select PO']");
	By TemplateDropdown = By.xpath("//p-dropdown[@formcontrolname='Template']");
	By StateDropdown = By.xpath("//p-dropdown[@formcontrolname='State']");
	By AddressTypeDropdown = By.xpath("//p-dropdown[@formcontrolname='AddressType' or @placeholder='Select a Address Type']");
	By FreelancerVendorDropdown = By.xpath("//p-dropdown[@placeholder='Select Freelancer/ Vendor Name ']");
	By CurrencyDropdown = By.xpath("//p-dropdown[@formcontrolname='Currency' or @placeholder='Select a Currency']");
	By ExpenseTypeDropdown = By.xpath("//p-dropdown[@formcontrolname='SpendType' or @placeholder='Select a Expense Type']");
	By ProjectClientDropdown = By.xpath("//p-dropdown[@placeholder='Select a Project Code / Client']");
	By PayingEntityDropdown = By.xpath("//p-dropdown[@formcontrolname='PayingEntity' or @placeholder='Select a Billing Entity']");
	By PaymentModeDropdown = By.xpath("//p-dropdown[@formcontrolname='PaymentMode' or @placeholder='Select a Payment Mode']");
	By PONumberDropdown = By.xpath("//p-dropdown[@formcontrolname='PONumber' or @placeholder='Select PO Number']");
	By POCNameDropdown = By.xpath("//p-dropdown[@formcontrolname='POCName' or @placeholder='Select POC Name']");

	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By ConfirmInvoiceOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Confirm Invoice']");	
	By EditInvoiceOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Edit Invoice']");
	By ViewProjectDetailsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View Project Details']");
	By DetailsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Details']");
	By ShowHistoryOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Show History']");
	By MarkAsSentToClientOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Mark as Sent to Client']");
	By SentToAPOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Sent to AP']");
	By MarkAsPaymentResolvedOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Mark as Payment Resolved']");
	By GenerateInvoiceOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Generate Invoice']");
	By ApproveExpenseOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Approve Expense']");
	By RejectExpenseOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Reject Expense']");
	By CancelExpenseOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Cancel Expense']");


	By RateTextBox = By.xpath("//input[@formcontrolname='Rate']");
	By HoursSpentTextBox = By.xpath("//input[@formcontrolname='HoursSpent']");
	By AmountTexBox = By.xpath("//input[@formcontrolname='Amount']");
	By AddAmountTextBox = By.xpath("//input[@class='ui-inputtext ui-corner-all ui-state-default ui-widget ng-untouched ng-pristine ng-valid']");
	By NotesTextBox = By.xpath("//textarea[@formcontrolname='Notes']|//textarea[@formcontrolname='ApproverComments']");
	By ApproveExpenseReferenceNumberTextBox = By.xpath("//input[@formcontrolname='Number' and @type='text']");
	By AddExpenseReferenceNumberTextBox = By.xpath("//input[@formcontrolname='InvoiceNo' and @type='text']");
	By MarkAsPaymentReferenceNumberTextBox = By.xpath("//input[@formcontrolname='Number' and @type='text']");
	
	
	
	By DialogYesButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Yes']");
	By DialogNoButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='No']");
	By DialogueSaveButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Save']");
	By DialogueCanceButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Cancel']");
	By DialogueApproveButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Approve']");
	By DialogueAddExpenseButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Expense']");
	By DialogueApproveExpenseButton = By.xpath("//div[@role='dialog']//span[@class='ui-button-text ui-clickable' and text()='Approve Expense']");
	By DialogueAddToScheduleInvoiceButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add To Schedule Invoice']");
	By DialogueMarkAsPaymentButton = By.xpath("//div[@role='dialog']//span[@class='ui-button-text ui-clickable' and text()='Mark As Payment']");

	By ParentCheckBox = By.xpath("//thead[@class='ui-table-thead']//div[@class='ui-chkbox ui-widget']");
	By SimpleCheckBox = By.xpath("//div[@class='ui-chkbox ui-widget']");

	By AddToProformaButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add to Proforma']");	
	By AdditionalCommentsTextBox = By.xpath("//textarea[@formcontrolname='AdditionalComments']");
	By AddProformaButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Proforma']");
	By DatePickerButton = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");
	By RequestExpenseButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Request expense']");
	By ApproveExpenseButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Approve Expense']");
	By ScheduleOOPInvoiceButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Schedule OOP Invoice']");
	By MarkAsPaymentButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Mark As Payment']");
	
	
	By CreditCardRadioButton = By.xpath("//label[@class='ui-radiobutton-label ng-star-inserted' and text()='Credit Card']");
	By BillableYESRadioButton = By.xpath("//label[@class='ui-radiobutton-label ng-star-inserted' and text()='Yes']");
	By BillableNORadioButton = By.xpath("//label[@class='ui-radiobutton-label ng-star-inserted' and text()='No']");
	By InvoicePaymentRadioButton = By.xpath("//label[@class='ui-radiobutton-label ng-star-inserted' and text()='Invoice Payment']");

	By MonthDropdown = By.xpath("//*[@id='myform']/div/div[22]/div/p-calendar/span/div/div/div[1]/div/select[1]|//*[@id='myform']/div/div[2]/p-calendar/span/div/div/div[1]/div/select[1]|//*[@id='myform']/div/div[6]/p-calendar/span/div/div/div[1]/div/select[1]|//*[@id='WebPartWPQ1']/div[1]/app-root/div[3]/app-finance-dashboard/app-expenditure/app-approved-billable/p-dialog[2]/div/div[2]/form/div/div[13]/p-calendar/span/div/div/div[1]/div/select[1]|//*[@id='WebPartWPQ1']/div[1]/app-root/div[3]/app-finance-dashboard/app-expenditure/app-approved-non-billable/p-dialog/div/div[2]/form/div[2]/div[2]/p-calendar/span/div/div/div[1]/div/select[1]");	
	By YearDropdown = By.xpath("//*[@id='myform']/div/div[22]/div/p-calendar/span/div/div/div[1]/div/select[2]|//*[@id='myform']/div/div[2]/p-calendar/span/div/div/div[1]/div/select[2]|//*[@id='myform']/div/div[6]/p-calendar/span/div/div/div[1]/div/select[2]|//*[@id='WebPartWPQ1']/div[1]/app-root/div[3]/app-finance-dashboard/app-expenditure/app-approved-billable/p-dialog[2]/div/div[2]/form/div/div[13]/p-calendar/span/div/div/div[1]/div/select[2]|//*[@id='WebPartWPQ1']/div[1]/app-root/div[3]/app-finance-dashboard/app-expenditure/app-approved-non-billable/p-dialog/div/div[2]/form/div[2]/div[2]/p-calendar/span/div/div/div[1]/div/select[2]");
	By ActiveDays = By.xpath("//a[@draggable='false']");
	By ProformaNumberBox = By.xpath("//input[@formcontrolname='ProformaNumber']");
	By ProformaInvoiceMessageToast = By.xpath("//div[@class='ui-toast-detail']");

	By ChooseFileButton = By.xpath("//input[@formcontrolname='file' or @id='myfile' or @name='myfile' or @type='file']"); //not working, using common field //div[@class='ui-g-6']
	By CommonFieldsForChooseFileButton = By.xpath("//div[@class='ui-g-6']");
	By AddExpCommonfields = By.xpath("//div[@class='p-col-8']");
	By MarkAsPaymentCommonFileds = By.xpath("//div[@class='ui-g-6']");
			
	
	/*
	By ChooseFileUploadFile1 = By.xpath("//input[@formcontrolname='FileURL']");
	By ChooseFileApprovalEmailFile = By.xpath(" //input[@formcontrolname='CAFileURL']");
	 */ //not working 


	//Base Class Date picker is not working as Month and Year dropdown XPath differs

	//Date picker function		
	public void Datepicker(String date) throws InterruptedException{			
		String splitter1[] = date.split("-");  //1-April 2020
		String SelectDate = splitter1[0];
		String month_year = splitter1[1];
		String splitter2[] = month_year.split(" ");
		String SelectMonth = splitter2[0];
		String SelectYear = splitter2[1];

		Select action_month = new Select(driver.findElement(MonthDropdown));
		action_month.selectByVisibleText(SelectMonth);

		Select action_year = new Select(driver.findElement(YearDropdown));
		action_year.selectByVisibleText(SelectYear);

		//String Today = driver.findElement(TodaySelected).getText();
		//List<WebElement> AllDates = driver.findElements(TotalDays);
		try{
			List<WebElement> SelectableDates = driver.findElements(ActiveDays);

			for(WebElement s:SelectableDates ){			
				if(s.getText().equals(SelectDate)){
					s.click();

				}					
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException e){
			List<WebElement> SelectableDates_New = driver.findElements(ActiveDays);	
			for(WebElement t:SelectableDates_New){			
				if(t.getText().equals(SelectDate)){
					t.click();

				}					//using try catch due to stale element exception 
			}
		}

	}		
	//Date picker function


	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(FinanceDashboardLink).click();				
	}
	
	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	
	public void SearchProjectDeliverableTab(String ProjectCode) throws InterruptedException{		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ScheduledTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ScheduledTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		
	}
	
	public void ConfirmLineitemDel() throws InterruptedException{				
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(pMenu).click();
		driver.findElement(ConfirmInvoiceOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogYesButton));
		driver.findElement(DialogYesButton).click();
	}
	
	public void SearchProjectHourlyTab(String ProjectCode) throws InterruptedException{				
		wait.until(ExpectedConditions.visibilityOfElementLocated(ScheduledTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ScheduledTab).click();						
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(HourlyBasedTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(HourlyBasedTab).click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
	}
	
	public void EditHourlyInvoice(String ProjectCode, String Rate, String HoursSpent) throws InterruptedException{
		/*
		wait.until(ExpectedConditions.visibilityOfElementLocated(ScheduledTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ScheduledTab).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(HourlyBasedTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(HourlyBasedTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		*/
		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(2);
		
		driver.findElement(EditInvoiceOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(RateTextBox).clear();
		driver.findElement(RateTextBox).sendKeys(Rate);
		driver.findElement(HoursSpentTextBox).clear();
		driver.findElement(HoursSpentTextBox).sendKeys(HoursSpent);
		driver.findElement(DialogueSaveButton).click();
		TimeUnit.SECONDS.sleep(10);		
	}
	
	public void ConfirmLineitemHourly(String ApprovalDate) throws InterruptedException{				
		driver.findElement(pMenu).click();
		driver.findElement(ConfirmInvoiceOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DatePickerButton).click();
		Datepicker(ApprovalDate);	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueApproveButton).click();
	}
	
	
	
	
	public void SearchProjectOOPTab(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ScheduledTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ScheduledTab).click();						
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(OOPTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(HourlyBasedTab).click();		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);		
	}
	
	

			

	public void SingleLineitemProforma(String PONameNumber, String ProjectCode1) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ConfirmTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ConfirmTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPODropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(SelectPODropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown(PONameNumber);
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode1);
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ProjectCodeDropdown).click();
		//ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode2);
		driver.findElement(ParentCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddToProformaButton).click();	
		//Date picker
		//Comments
		//AddProforma button click
	}


	public void AddressType(String AddressType) throws InterruptedException{
		driver.findElement(AddressTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown(AddressType);
	}


	public void SelectTemplate(String TemplateName) throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);

		try{
			driver.findElement(TemplateDropdown).click();
			ObjectsOgBaseClass.SelectItemFromSimpleDropdown(TemplateName);
			TimeUnit.SECONDS.sleep(1);
			driver.findElement(StateDropdown).click();
			ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Alaska");						
		}
		catch(NoSuchElementException e){
			System.out.println("Non US Template");
		}		

	}		

	public void DateSelection(String Date) throws InterruptedException{
		driver.findElement(DatePickerButton).click();
		TimeUnit.SECONDS.sleep(2);
		Datepicker(Date);
	}

	public void AddProforma() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AdditionalCommentsTextBox).sendKeys("Test_Additional Comments");
		TimeUnit.SECONDS.sleep(2);

		driver.findElement(AddProformaButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProformaInvoiceMessageToast));	
		String ProformaMessage=driver.findElement(ProformaInvoiceMessageToast).getText();
		String splitter[] = ProformaMessage.split(": ");
		String ProformaNumber = splitter[1];
		System.out.println(ProformaNumber); //copy this number to excel while making Data driven
	}


	public void Generate(String ProformaNumber, String InvoiceDate) throws InterruptedException{	
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProformaTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProformaTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProformaNumberDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(ProformaNumberDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProformaNumber);
		TimeUnit.SECONDS.sleep(2);

		driver.findElement(pMenu).click();		
		driver.findElement(MarkAsSentToClientOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogYesButton).click();						

		wait.until(ExpectedConditions.visibilityOfElementLocated(ProformaNumberDropdown));
		TimeUnit.SECONDS.sleep(20);
		driver.findElement(pMenu).click();		
		driver.findElement(GenerateInvoiceOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DatePickerButton).click();
		TimeUnit.SECONDS.sleep(2);
		Datepicker(InvoiceDate);
		driver.findElement(DialogueSaveButton).click(); 


		wait.until(ExpectedConditions.visibilityOfElementLocated(ProformaInvoiceMessageToast));	
		String ProformaMessage=driver.findElement(ProformaInvoiceMessageToast).getText();
		String splitter[] = ProformaMessage.split(": ");
		String InvoiceNumber = splitter[1];
		System.out.println(InvoiceNumber); //copy this number to excel while making Data driven

	}

	public void PaymentResolved(String InvoiceNumber) throws InterruptedException, IOException{		
		wait.until(ExpectedConditions.visibilityOfElementLocated(OutstandingInvoicesTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(OutstandingInvoicesTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(InvoiceNumberDropdown));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(InvoiceNumberDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(InvoiceNumber);
		TimeUnit.SECONDS.sleep(2);


		driver.findElement(pMenu).click();		
		driver.findElement(SentToAPOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueSaveButton).click();	


		wait.until(ExpectedConditions.visibilityOfElementLocated(OutstandingInvoicesTab));
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(pMenu).click();		
		driver.findElement(MarkAsPaymentResolvedOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ChooseFileButton).click();   not working
		List<WebElement> CommonFields = driver.findElements(CommonFieldsForChooseFileButton);
		CommonFields.get(1).click();
		ObjectsOgBaseClass.UploadFile1();		
		driver.findElement(DialogueSaveButton).click();								
	}


	public void CreditCardBillableFlow() throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(RequestExpenseButton).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(CreditCardRadioButton).click();
		driver.findElement(BillableYESRadioButton).click();
		driver.findElement(FreelancerVendorDropdown).click();	
		ObjectsOgBaseClass.SelectItemFromDropdown("Test_Praveen");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CurrencyDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("INR");		
		driver.findElement(AmountTexBox).sendKeys("5.5");
		driver.findElement(ExpenseTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Submission Fee");
		driver.findElement(NotesTextBox).sendKeys("Test_CreditCardBillbaleExpense");		
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ChooseFileUploadFile1).click(); //not working 
		List<WebElement> CommonFields = driver.findElements(AddExpCommonfields);
		CommonFields.get(7).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		CommonFields.get(8).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		driver.findElement(ProjectClientDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("PRA08-ABS-201610");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddAmountTextBox).sendKeys("5.5");
		driver.findElement(DialogueAddExpenseButton).click();						

	}

	

	public void ApproveExpenseThroughPmenu(String ProjectCode) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(30);	
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		driver.findElement(ParentCheckBox).click();
		TimeUnit.SECONDS.sleep(3);	
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(5);	
		driver.findElement(ApproveExpenseOption).click();

	}	



	public void ApproveExpenseThroughButton(String ProjectCode) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(30);	
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ParentCheckBox).click();
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(ApproveExpenseButton).click();				
	}

	public void ApproveCCExpense() throws InterruptedException, IOException{			
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(PayingEntityDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("CAUS-CACTUS USA");
		driver.findElement(ApproveExpenseReferenceNumberTextBox).sendKeys("Test_Ref_CCBillable_001");
		driver.findElement(DatePickerButton).click();
		ObjectsOgBaseClass.Datepicker("19-May 2020");
		driver.findElement(PaymentModeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Bank Transfer");
		driver.findElement(NotesTextBox).sendKeys("Test_Comments");
		List<WebElement> ApproveExpenseDialogCommonFields = driver.findElements(CommonFieldsForChooseFileButton);
		ApproveExpenseDialogCommonFields.get(10).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT
		driver.findElement(DialogueApproveExpenseButton).click();		
	}
	public void ApproveINVPaymentExpense() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(PayingEntityDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("CAUS-CACTUS USA");
		driver.findElement(NotesTextBox).sendKeys("Test_Comments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueApproveExpenseButton).click();
	}
	
	public void ScheduleOOP(String ProjectCode, String PONumber) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(ApprovedBillableTab).click();
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ParentCheckBox).click();
		TimeUnit.SECONDS.sleep(5);	
		driver.findElement(ScheduleOOPInvoiceButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PONumberDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown(PONumber);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DatePickerButton).click();
		Datepicker("20-May 2020");
		/*
		driver.findElement(POCNameDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Test_FN_2 Test_LN_2");
		*/
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddressTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Client");
		driver.findElement(DialogueAddToScheduleInvoiceButton).click();
		
	}
	
	
	
	public void CreditCardNonBillableFlow() throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(RequestExpenseButton).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(CreditCardRadioButton).click();
		driver.findElement(BillableNORadioButton).click();
		driver.findElement(FreelancerVendorDropdown).click();	
		ObjectsOgBaseClass.SelectItemFromDropdown("Test_Praveen");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CurrencyDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("INR");		
		driver.findElement(AmountTexBox).sendKeys("5.5");
		driver.findElement(ExpenseTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Submission Fee");
		driver.findElement(NotesTextBox).sendKeys("Test_CreditCardNonBillbaleExpense");		
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ChooseFileUploadFile1).click(); //not working 
		List<WebElement> CommonFields = driver.findElements(AddExpCommonfields);
		CommonFields.get(7).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT
		CommonFields.get(8).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT
		driver.findElement(ProjectClientDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("PRA08-ABS-201610");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddAmountTextBox).sendKeys("5.5");
		driver.findElement(DialogueAddExpenseButton).click();
	}

	public void InvoicePaymentBillableFlow() throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(RequestExpenseButton).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(InvoicePaymentRadioButton).click();
		driver.findElement(BillableYESRadioButton).click();
		driver.findElement(FreelancerVendorDropdown).click();	
		ObjectsOgBaseClass.SelectItemFromDropdown("Test_Praveen");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddExpenseReferenceNumberTextBox).sendKeys("Test_AddExp_001");
		driver.findElement(CurrencyDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("INR");		
		driver.findElement(AmountTexBox).sendKeys("5.5");
		driver.findElement(ExpenseTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Submission Fee");
		driver.findElement(NotesTextBox).sendKeys("Test_INVPaymentBillbaleExpense");		
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ChooseFileUploadFile1).click(); //not working 
		List<WebElement> CommonFields = driver.findElements(AddExpCommonfields);
		CommonFields.get(7).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		CommonFields.get(8).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		driver.findElement(ProjectClientDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("PRA08-ABS-201610");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddAmountTextBox).sendKeys("5.5");
		driver.findElement(DialogueAddExpenseButton).click();

	}

	public void InvoicePaymentNonBillableFlow() throws InterruptedException, IOException{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(RequestExpenseButton).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(InvoicePaymentRadioButton).click();
		driver.findElement(BillableNORadioButton).click();
		driver.findElement(FreelancerVendorDropdown).click();	
		ObjectsOgBaseClass.SelectItemFromDropdown("Test_Praveen");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddExpenseReferenceNumberTextBox).sendKeys("Test_AddExp_001");
		driver.findElement(CurrencyDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("INR");		
		driver.findElement(AmountTexBox).sendKeys("5.5");
		driver.findElement(ExpenseTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Submission Fee");
		driver.findElement(NotesTextBox).sendKeys("Test_INVPaymentNonBillbaleExpense");		
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ChooseFileUploadFile1).click(); //not working 
		List<WebElement> CommonFields = driver.findElements(AddExpCommonfields);
		CommonFields.get(7).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		CommonFields.get(8).click();
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT

		driver.findElement(ProjectClientDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("PRA08-ABS-201610");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AddAmountTextBox).sendKeys("5.5");
		driver.findElement(DialogueAddExpenseButton).click();

	}
	
	public void MarkAsPayment(String ProjectCode) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(RequestExpenseButton));
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(ApprovedNonBillableTab).click();
		TimeUnit.SECONDS.sleep(15);	
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ParentCheckBox).click();
		TimeUnit.SECONDS.sleep(5);	
		driver.findElement(MarkAsPaymentButton).click();
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(MarkAsPaymentReferenceNumberTextBox).sendKeys("Test_MarkAsPayment_001");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DatePickerButton).click();
		TimeUnit.SECONDS.sleep(2);
		Datepicker("19-May 2020");
		driver.findElement(PaymentModeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromSimpleDropdown("Bank Transfer");
		TimeUnit.SECONDS.sleep(2);
		List<WebElement> CommonFields = driver.findElements(MarkAsPaymentCommonFileds);
		
		CommonFields.get(2).click();		
		//Integration with AutoIT
		ObjectsOgBaseClass.UploadFile1();
		//Integration with AutoIT
		
		driver.findElement(DialogueMarkAsPaymentButton).click();
	}
		
	public void EditDeleverableInvoice() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(2);
		
	}

	
	public void RevertInvoice(){
		
	}
	
	public void RejectProforma(){
		
	}

	public void ReplaceProforma(){
		
	}

	public void ReplaceInvoice(){
		
	}
	
	public void EditInvoiceNumber(){
		
	}
	
	public void RejectExpense(){
		
	}
	
	public void CancelExpense(){
		
	}
	
	
	
}

	


