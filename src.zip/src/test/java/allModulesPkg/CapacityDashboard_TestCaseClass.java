package allModulesPkg;

import java.io.IOException;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CapacityDashboard_TestCaseClass extends Login {

	CapacityDashboard_TestClass ObjectsOfTestActionsClass = new CapacityDashboard_TestClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	Login ObjectsOfLoginClass = new Login();
	
	By TotalChildCheckboxFieldsInDropdown = By.xpath("//li[contains(@class,'ui-multiselect-item ui-corner-all')]");
	By TotalNonCheckboxFieldsInDropdown = By.xpath("//li[contains(@class,'ui-dropdown-item ui-corner-all')]");
	By Date_ValPoint = By.xpath("//p-calendar[contains(@class,'ng-untouched')]");
	By CapacityTable_ValPoint = By.xpath("//app-usercapacity//table[@id='capacityTable']"); 
	By PracticeAreaDropdown_ValPoint = By.xpath("//p-multiselect[@formcontrolname='practicearea']//span[@class='ui-multiselect-label ui-corner-all' and text()='Select Practice Area']");
	By SkillDropdown_ValPoint = By.xpath("//p-multiselect[@formcontrolname='skill']//span[@class='ui-multiselect-label ui-corner-all' and text()='Select Skill']");
	By ReasourceDropdown_ValPoint = By.xpath("//p-multiselect[@formcontrolname='resources']//span[@class='ui-multiselect-label ui-corner-all' and text()='Select Resource']");
	By TotalSelectedItems = By.xpath("//li[@class='ui-multiselect-item ui-corner-all ui-state-highlight']");
	By ExportExcel = By.xpath("//a[contains(@class,'download-worksheet')]");
	By DaysText_ValPoint = By.xpath("//div[@class='ui-card-content']//span[contains(text(),'Days')]");
	By AvailableText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Available')]");
	By OverAllocatedText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Fully/Over Allocated')]");
	By LeaveText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Leave / Not Working')]");
	By GoliveText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Go Live')]");
	By TraineeText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Trainee')]");
	By TasksText_ValPoint = By.xpath("//div[@class='ui-card-content']//span[contains(text(),'Tasks')]");
	By ConfirmedText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Confirmed')]");
	By PlannedText_ValPoint = By.xpath("//div[@class='ui-card-content']//label[contains(text(),'Planned / Blocked')]");
	By RefreshIcon_ValPoint = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-refresh']");
	By BlockResIcon_ValPoint = By.xpath("//span[@class='ui-button-icon-left ui-clickable fa fa-user-plus']");
	By SearchIcon_ValPoint = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-search']");
	By ResDateColumn_ValPoint = By.xpath("//thead[@class='tableHeader']//th[contains(text(),'Res(s) / Date(s)')]");
	By CapacityRowName_ValPoint = By.xpath("//div[contains(@style,'color:#c53e3e') and contains(text(),'Capacity')]");
	By TimeSpentRowName_ValPoint = By.xpath("//tbody[@class='capacityBody']//div[contains(@style,'color:#c53e3e') and contains(text(),'Time Spent')]");
	By TotalOnJobResource_ValPoint = By.xpath("//div[@class='col-md-3 ng-star-inserted']/div[contains(text(),'Total On Job Resource')]");
	By TotalUnallocatedColumn_ValPoint = By.xpath("//thead[@class='tableHeader']//th[contains(text(),'Total Un-Allocated / Bench')]");
	By TotalAllocatedColumn_ValPoint = By.xpath("//thead[@class='tableHeader']//th[contains(text(),'Total Allocated / Spent')]");
	By CapacityTasks_ValPoint = By.xpath("//app-capacity-tasks/p-table[@id='TasksPerDay']");
	By CapacityTasksTableHeader_ValPoint = By.xpath("//app-capacity-tasks//tr[@class='tableHeader ng-star-inserted']//td[5]");
	By CapacityTasksRow_ValPoint = By.xpath("//tr[@class='tableBody ng-star-inserted']//td[5]//span[contains(text(),'0:0')]");
	By BlockResourceRow_ValPoint = By.xpath("//tr[@class='tableBody ng-star-inserted']//td[6]//span[text()='Active']");
	By BlockResourceSuccess_ValPoint = By.xpath("//div[@class='ui-toast-detail' and text()='Resource Bock Successfully']");
	//Commit Test cases
	
	//To verify if all filters are displayed on capacity dashboard
	@Test(enabled = false)
	public void TC1_CapacityDashboardElements() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateElements();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Bucket filters
	@Test(enabled = false)
	public void TC2_ValidateValuesInBucket() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Bucket");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalChildCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Practice Area filters
	@Test(enabled = false)
	public void TC3_ValidateValuesInPracticeArea() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Practice Area");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalChildCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Skill filters
	@Test(enabled = false)
	public void TC4_ValidateValuesInSkill() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Skill");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalChildCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Resources filters
	@Test(enabled = false)
	public void TC5_ValidateValuesInResources() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Resources");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalChildCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Task Status filters
	@Test(enabled = false)
	public void TC6_ValidateValuesInTaskStatus() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Task Status");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalNonCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To verify value in Resources Type filters
	@Test(enabled = false)
	public void TC7_ValidateValuesInResourcesType() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.VerifyValueInFilters("Resources Type");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalNonCheckboxFieldsInDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate default filter on capacity dashboard page loads
	@Test(enabled = false)
	public void TC8_ValidateDefualtFilter() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.DefaultFilters();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if Bucket filter is selected
	@Test(enabled = false)
	public void TC9_ValidateBucketFilterSelected() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateBucketFilterSelection("Others");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if PA filter is selected
	@Test(enabled = false)
	public void TC10_ValidatePAFilterSelected() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidatePracticeAreaFilterSelection("Devices");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate if Skill filter is selected
	@Test(enabled = false)
	public void TC11_ValidateSkillFilterSelected() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateSkillFilterSelection("Reviewer");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate if Resources filter is selected
	@Test(enabled = false)
	public void TC12_ValidateResourcesFilterSelected() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateResourcesFilterSelection("Maxwell Fargose");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if Bucket and Skill filter is selected
	@Test(enabled = false)
	public void TC13_ValidateBucketAndSkillFilterSelected() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateBucketFilterSelection("Others");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.ValidateSkillFilterSelection("Reviewer");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TotalSelectedItems));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To clear reset filters
	@Test(enabled = false)
	public void TC14_ClearFilters() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ResetFilter();
		ObjectsOfTestActionsClass.ValidationPoint();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if start date and end date is being reset on click of reset
	@Test(enabled = false)
	public void TC15_ClearDates() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SelectDates("1-December 2020", "2-December 2020");
		ObjectsOfTestActionsClass.ResetFilter();
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Date_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if data displayed is being reset on click of reset
	@Test(enabled = false)
	public void TC16_ClearCapacityData() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.ResetFilter();
		Assert.assertFalse(driver.findElement(CapacityTable_ValPoint).isDisplayed());
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if all selected(cascaded) filters get deselected when its previous filter get deselected
	@Test(enabled = false)
	public void TC17_ValidateForDeselectedOfDropdown() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.BucketSelection("Amgen");
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.ClearBucketSelection();
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(PracticeAreaDropdown_ValPoint));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(SkillDropdown_ValPoint));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ReasourceDropdown_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate user capacity assigned on default task
	@Test(enabled = false)
	public void TC18_ValidateAssignedDefaultTask() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.UserCapacityTasks("4 Dec,2020");
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(CapacityTasks_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate user capacity assigned on default task when one day leave is applied
	@Test(enabled = false)
	public void TC19_ValidateAssignedDefaultTaskWithOneDayLeaveApplied() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.UserCapacityTasks("4 Dec,2020");
		TimeUnit.SECONDS.sleep(10);
//		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(CapacityTasksTableHeader_ValPoint));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(CapacityTasksRow_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate user capacity assigned on default task when more than one day leaves are applied
	@Test(enabled = false)
	public void TC20_ValidateAssignedDefaultTaskWithMoreThanOneDayLeaveApplied() throws IOException, InterruptedException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.UserAssignedDefaultTaskForMultipleLeave("7 Dec,2020","9 Dec,2020");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(CapacityTasksRow_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate Add to excel icon is being displayed
	@Test(enabled = false)
	public void TC21_ValidateExportExcel() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ExportExcel));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate when clicked on Add to excel icon
	@Test(enabled = false)
	public void TC22_ValidateExportExcelClicked() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ExportExcel));
		driver.findElement(ExportExcel).click();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate if Go Live& Joining date values are displayed in Excel sheet
	@Test(enabled = false)
	public void TC23_ValidateGoLiveAndJoiningDateValues() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ExportExcel));
		driver.findElement(ExportExcel).click();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	//To validate whether Block Resource icon is available //TC-24,TC-35
	@Test(enabled = false)
	public void TC24_ValidateBlockResourceButton() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResIcon_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate whether Days category text is available
	@Test(enabled = false)
	public void TC25_ValidateDaysText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(DaysText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Available  category text is available
	@Test(enabled = false)
	public void TC26_ValidateAvailbleText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(AvailableText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate whether Fully/ Over Allocated category text is available
	@Test(enabled = false)
	public void TC27_ValidateFullyOverAllocatedText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(OverAllocatedText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Leave/ Not Working category text is available
	@Test(enabled = false)
	public void TC28_ValidateLeaveNotWorkingText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(LeaveText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether GoLive category text is available
	@Test(enabled = false)
	public void TC29_ValidateGoLiveText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(GoliveText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Trainee category text is available
	@Test(enabled = false)
	public void T30_ValidateTraineeText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TraineeText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Tasks category text is available
	@Test(enabled = false)
	public void TC31_ValidateTasksText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TasksText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Confirmed category text is available
	@Test(enabled = false)
	public void TC32_ValidateConfirmedText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ConfirmedText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Planned / Blocked category text is available
	@Test(enabled = false)
	public void TC33_ValidateDaysText() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(PlannedText_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Refresh icon is available
	@Test(enabled = false)
	public void TC34_ValidateRefreshButton() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(RefreshIcon_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether Search icon is available 
	@Test(enabled = false)
	public void TC36_ValidateSearchButton() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(SearchIcon_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Res(s) / Date(s)' column name is available post searching data
	@Test(enabled = false)
	public void TC37_ValidateResourceDateColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ResDateColumn_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	

	//To validate 'Capacity' row name is available post searching data
	@Test(enabled = false)
	public void TC38_ValidateCapacityRowName() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(CapacityRowName_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Time Spent' row name is available post searching data
	@Test(enabled = false)
	public void TC39_ValidateTimeSpentRowName() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TimeSpentRowName_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Total On Job Resource: ' option is available post searching data
	@Test(enabled = false)
	public void TC40_ValidateTotalOnJobResourceColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TotalOnJobResource_ValPoint));
		System.out.println("Value :"+driver.findElement(TotalOnJobResource_ValPoint).getText());
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Total Un-Allocated / Bench' column is available post searching data
	@Test(enabled = false)
	public void TC41_ValidateTotalUnallocatedColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TotalUnallocatedColumn_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate 'Total Allocated / Spent' column is available post searching data
	@Test(enabled = false)
	public void TC42_ValidateTotalAllocatedColumn() throws IOException, InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(TotalAllocatedColumn_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to apply block Resources on one day
	@Test(enabled = false)
	public void TC43_ApplyBlockResourceOnOneDay() throws IOException, InterruptedException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResIcon_ValPoint));
		driver.findElement(BlockResIcon_ValPoint).click();
		ObjectsOfTestActionsClass.ApplyBlockResource("7-December 2020","7-December 2020");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResourceSuccess_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to apply block Resources on one day
	@Test(enabled = false)
	public void TC44_ApplyBlockResourceOnMultipleDay() throws IOException, InterruptedException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResIcon_ValPoint));
		driver.findElement(BlockResIcon_ValPoint).click();
		ObjectsOfTestActionsClass.ApplyBlockResource("8-December 2020","10-December 2020");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResourceSuccess_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether applied block Resources on single day is showing up in capacity 
	@Test(enabled = false)
	public void TC45_ValidateShowingBlockResoureForSingleDay() throws IOException, InterruptedException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.UserCapacityTasks("7 Dec,2020");
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResourceRow_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether applied block Resources on multiple day is showing up in capacity 
	@Test(enabled = false)
	public void TC46_ValidateShowingBlockResoureForMultipleDay() throws IOException, InterruptedException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CapacityDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToCapacityDashboardPage();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfTestActionsClass.FetchCapacitySingleUser();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.ValidateAppliedBlockResourceForMultipleLeave("8 Dec,2020","10 Dec,2020");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResourceRow_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	
}
