package allModulesPkg;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class CentralAllocation_TestClass {
	
	Login ObjectsOfLoginClass = new Login();
	CentralAllocation_ObjectClass ObjectsOfCentralAllocationObjectClass = new CentralAllocation_ObjectClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	
	@Test(priority = 1, enabled = true)
	public void CentralAllocationNavigation() throws InterruptedException{
		ObjectsOfCentralAllocationObjectClass.Navigation();		
	}
	
	@Test(priority = 2, enabled = true)
	public void SwitchToCentralAllocationPage() throws InterruptedException{
		ObjectsOfCentralAllocationObjectClass.SwitchTab();
	}
	
	@Test(priority = 3, enabled = true)
	public void Restructure() throws InterruptedException{
		ObjectsOfCentralAllocationObjectClass.RestructureOption();
	}
	
	@Test(priority = 4, enabled = true)
	public void SelectFilter(String FilterType,String FilterValue) throws InterruptedException {
		switch(FilterType) {
		case "Client":
		ObjectsOfCentralAllocationObjectClass.SelectClientFilter(FilterValue);
		break;
		case "Project":
		ObjectsOfCentralAllocationObjectClass.SelectProjectFilter(FilterValue);
		break;
		case "Task":
		ObjectsOfCentralAllocationObjectClass.SelectTaskFilter(FilterValue);
		break;
		case "StartDate":
		ObjectsOfCentralAllocationObjectClass.SelectStartDateFilter(FilterValue);
		break;
		case "EndDate":
		ObjectsOfCentralAllocationObjectClass.SelectEndDateFilter(FilterValue);
		break;
		case "Milestone":
		ObjectsOfCentralAllocationObjectClass.SelectMilestoneFilter(FilterValue);
		break;
		}
	}
	

	@Test(priority = 5, enabled = true) 
	public void ValidateTaskScope(String ProjectCode, String Milestone, String Slot,String Task) throws InterruptedException {
		ObjectsOfCentralAllocationObjectClass.TaskScopeOfParticularTask(ProjectCode, Milestone, Slot, Task);
	}
	

	@Test(priority = 6, enabled = true) 
	public void GlobalFilter(String Type, String Search) throws InterruptedException {
		ObjectsOfCentralAllocationObjectClass.GlobalFilter(Type,Search);
	}
	
	@Test(priority = 7, enabled = true) 
	public void AllocateTask(String Type, String ProjectCode, String Milestone, String Slot, String Task, String Resource) throws InterruptedException {
		ObjectsOfCentralAllocationObjectClass.AllocateTaskThroughCA(Type, ProjectCode, Milestone, Slot, Task, Resource);
	}
	
	@Test(priority = 8, enabled = true) 
	public void AssignResource(String Type, String ProjectCode,String Milestone, String Slot,String Task,String Resource) throws InterruptedException {
		ObjectsOfCentralAllocationObjectClass.AssignResource(Type, ProjectCode, Milestone, Slot, Task, Resource);
	}
		
}
