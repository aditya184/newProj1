package allModulesPkg;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class BaseClass extends Login {
	int i;
	By TotalChildCheckboxFieldsInDropdown = By.xpath("//li[@class='ui-multiselect-item ui-corner-all']");
	By SelectableDropdownInputBox = By.xpath("//input[@class='ui-inputtext ui-widget ui-state-default ui-corner-all' and @role='textbox']");
	By DropdownClose = By.xpath("//a[@class='ui-multiselect-close ui-corner-all']");
	By NonSelectableDropdownInputBox = By.xpath("//input[@class='ui-dropdown-filter ui-inputtext ui-widget ui-state-default ui-corner-all']");
	By TotalNonCheckFieldsInDropdown = By.xpath("//li[@class='ui-dropdown-item ui-corner-all']|//li[@class='ui-dropdown-item ui-corner-all ui-state-highlight']");
	By NoResultsFound = By.xpath("//li[text()='No results found']");
	By MonthDropdown = By.xpath("//*[contains(@class, 'ui-datepicker-month')]");
	By YearDropdown = By.xpath("//*[contains(@class, 'ui-datepicker-year')]");
	By ActiveDays = By.xpath("//a[@draggable='false']");

	//Function to select an element from dropdown having checkbox and search text field
	public void SelectCheckboxItemsFromDropdown(String text) throws InterruptedException{				
		List<WebElement> CheckboxItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);						
		driver.findElement(SelectableDropdownInputBox).sendKeys(text);
		for(i=0; i<CheckboxItemList.size(); i++)
		{

			if(CheckboxItemList.get(i).getText().equals(text))
			{		

				break;
			}

		}

		try{			
			if(CheckboxItemList.get(i).getText().equals(text)){
				System.out.println("item is available in dropdown");
			}

			CheckboxItemList.get(i).click();
			driver.findElement(DropdownClose).click();	

		}
		catch(IndexOutOfBoundsException e){
			System.out.println("item is not available in dropdown or already selected");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);			
		}
	}
	//Function to select an element from dropdown having checkbox and search text field


	//Function to select an element from dropdown having no checkbox but search field
	public void SelectItemFromDropdown(String text) throws InterruptedException{
		driver.findElement(NonSelectableDropdownInputBox).sendKeys(text);
		try{		
			String NonCheckItemlist = driver.findElement(TotalNonCheckFieldsInDropdown).getText();
			if(NonCheckItemlist.equals(text)){
				System.out.println("Entedred element is avaialble");
				TimeUnit.SECONDS.sleep(2);					
			}
			driver.findElement(TotalNonCheckFieldsInDropdown).click();
		}
		catch(Exception e){	
			System.out.println("Entered element is not available");
			driver.findElement(NoResultsFound).click();
			TimeUnit.SECONDS.sleep(2);				
		}
	}
	//Function to select an element from dropdown having no checkbox but search field	


	//Function to select an element from dropdown having no checkbox and no search box
	public void SelectItemFromSimpleDropdown(String text) throws InterruptedException{
		List<WebElement> ItemList = driver.findElements(TotalNonCheckFieldsInDropdown);	
		for(i=0; i<ItemList.size(); i++)
		{

			if(ItemList.get(i).getText().equals(text))
			{		

				break;
			}

		}

		try{			
			if(ItemList.get(i).getText().equals(text)){
				System.out.println("item is available in dropdown");
			}						
			ItemList.get(i).click();		
		}
		catch(IndexOutOfBoundsException e){
			System.out.println("item is not available in dropdown");
			TimeUnit.SECONDS.sleep(2);			
		}

	}

	//Function to select an element from dropdown having no checkbox and no search box

	//Date picker function		
	public void Datepicker(String date) throws InterruptedException{			
		String splitter1[] = date.split("-");  //1-April 2020
		String SelectDate = splitter1[0];
		String month_year = splitter1[1];
		String splitter2[] = month_year.split(" ");
		String SelectMonth = splitter2[0];
		String SelectYear = splitter2[1];

		Select action_month = new Select(driver.findElement(MonthDropdown));
		action_month.selectByVisibleText(SelectMonth);

		Select action_year = new Select(driver.findElement(YearDropdown));
		action_year.selectByVisibleText(SelectYear);

		//String Today = driver.findElement(TodaySelected).getText();
		//List<WebElement> AllDates = driver.findElements(TotalDays);
		try{
			List<WebElement> SelectableDates = driver.findElements(ActiveDays);

			for(WebElement s:SelectableDates ){			
				if(s.getText().equals(SelectDate)){
					s.click();

				}					
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException e){
			List<WebElement> SelectableDates_New = driver.findElements(ActiveDays);	
			for(WebElement t:SelectableDates_New){			
				if(t.getText().equals(SelectDate)){
					t.click();

				}					//using try catch due to stale element exception 
			}
		}

	}		
	//Date picker function


	//File Upload using AutoIT
	public void UploadFile1() throws InterruptedException, IOException{
		TimeUnit.SECONDS.sleep(3);		
		//integration with AutoIT
		Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\Automation\\AutoITScripts\\Upload_File1.exe");
		//integration with AutoIT
		TimeUnit.SECONDS.sleep(5);
	}

	public void UploadFile2() throws InterruptedException, IOException{
		TimeUnit.SECONDS.sleep(3);		
		//integration with AutoIT
		Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\Automation\\AutoITScripts\\Upload_File2.exe");
		//integration with AutoIT
		TimeUnit.SECONDS.sleep(5);
	}
	//File Upload using AutoIT


	@Test
	public void RefreshPage() throws InterruptedException{

		TimeUnit.SECONDS.sleep(3);
		driver.navigate().refresh();
	}



	@Test
	public void SwitchToChildModule() throws InterruptedException{
		TimeUnit.SECONDS.sleep(5);	
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());				
		driver.switchTo().window(tabs.get(1));
		TimeUnit.SECONDS.sleep(2);	
	}

	@Test
	public void CloseAndSwitchBackToParentModule() throws InterruptedException{
		TimeUnit.SECONDS.sleep(5);	
		driver.close();
		TimeUnit.SECONDS.sleep(2);	
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());						
		driver.switchTo().window(tabs.get(0));	
		TimeUnit.SECONDS.sleep(2);	
	}

	@Test
	public void RefreshParentModule() throws InterruptedException{
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());						
		driver.switchTo().window(tabs.get(0));	
		TimeUnit.SECONDS.sleep(5);
		driver.navigate().refresh();	
		TimeUnit.SECONDS.sleep(2);

	}

	@Test
	public void RefreshChildModule() throws InterruptedException{
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());						
		driver.switchTo().window(tabs.get(1));	
		TimeUnit.SECONDS.sleep(30);
		driver.navigate().refresh();	
		TimeUnit.SECONDS.sleep(2);

	}




	//Date picker function for Admin-->Add PO due to Year dropdown is missing 		
	public void DatepickerAdmin(String date) throws InterruptedException{			
		String splitter1[] = date.split("-");  //1-April 2020
		String SelectDate = splitter1[0];
		String month_year = splitter1[1];
		String splitter2[] = month_year.split(" ");
		String SelectMonth = splitter2[0];
		String SelectYear = splitter2[1];

		Select action_month = new Select(driver.findElement(MonthDropdown));
		action_month.selectByVisibleText(SelectMonth);
		/*
			Select action_year = new Select(driver.findElement(YearDropdown));
			action_year.selectByVisibleText(SelectYear);
		 */
		//String Today = driver.findElement(TodaySelected).getText();
		//List<WebElement> AllDates = driver.findElements(TotalDays);
		try{
			List<WebElement> SelectableDates = driver.findElements(ActiveDays);

			for(WebElement s:SelectableDates ){			
				if(s.getText().equals(SelectDate)){
					s.click();

				}					
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException e){
			List<WebElement> SelectableDates_New = driver.findElements(ActiveDays);	
			for(WebElement t:SelectableDates_New){			
				if(t.getText().equals(SelectDate)){
					t.click();

				}					//using try catch due to stale element exception 
			}
		}

	}		
	//Date picker function for Admin-->Add PO due to Year dropdown is missing


	public void CloseBrowser() throws InterruptedException{
		TimeUnit.SECONDS.sleep(5);
		driver.quit();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public String dayOfWeek(String date) throws InterruptedException, ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMMM yyyy");
		Date date2 = format1.parse(date);
//	    System.out.println(format1.format(date2));
		DateFormat formatter = new SimpleDateFormat("EEEE");
//	    System.out.println(formatter.format(date2));
		String day = formatter.format(date2);
		return day;
	}


	//switch tab
	//perform action on current window
	//close the current window
	//switch back to parent window 
	//perform refresh action

}
