package allModulesPkg;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class PubSupport_TestCaseClass extends Login {
	PubSupport_TestClass ObjectPubSupportTestClass = new PubSupport_TestClass();
	PubSupport_ObjClass ObjectOfPubSupportClass = new PubSupport_ObjClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();
	Login OjectsOfLoginClass = new Login();
	XSSFSheet ws;
	XSSFWorkbook wb;
	By SuccessMsg = By.xpath("//div[text()='Success Message']");
	By SelectedText = By.xpath("//div[@class='pubsuppotTable']//td[text()='Selected']");
	By AddJCoption = By.xpath("//span[text()='Add Journal / Conference']");
	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By AddAUTHoption = By.xpath("//span[text()='Add Authors']");
	By UpdateAUForms = By.xpath("//span[text()='Update Author forms & emails']");
	By EditJConfClick = By.xpath("//span[text()='Edit Journal / Conference']");
	By UpdateJournalRequirementClick = By.xpath("//span[text()='Update Journal Requirement']");
	By UploadFilesUpdateReq = By.xpath("//input[@formcontrolname='JournalRequirementResponse']");
	By CancelJournceConf = By.xpath("//span[text()='Cancel Journal Conference']");
	By RevertDecision = By.xpath("//span[text()='Revert Decision']");
	By UpdateDecisionDetailsOption = By.xpath("//span[text()='Update Decision details']");

	@Test(priority = 1, enabled = true)
	public void ReadExcel() throws IOException {
		wb = ObjectOfPubSupportClass.getExcel();
		ws = wb.getSheet("PubSupportData");
	}

	@Test(priority = 2, enabled = false)
	public void TC_01() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(2).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(2).getCell(2).getStringCellValue();
		String eList = ws.getRow(2).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(2).getCell(4).getStringCellValue();
		ObjectPubSupportTestClass.CreateConference(eDeliveryType, eList, eMilestone);
		// write a validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 3, enabled = false)
	public void TC_08() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(6).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(6).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.IsMilestoneAvailable(eDeliveryType);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 4, enabled = false)
	public void TC_09() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(6).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.IsMilestoneMandatory();
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 5, enabled = false)
	public void TC_10() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(6).getCell(5).getStringCellValue());
		String eMilestone = ws.getRow(6).getCell(6).getStringCellValue();
		ObjectOfPubSupportClass.ValidateMilestones(eMilestone);
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(priority = 6, enabled = false)
	public void TC_11() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(10).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(10).getCell(2).getStringCellValue();
		String eList = ws.getRow(10).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(10).getCell(4).getStringCellValue();
		ObjectPubSupportTestClass.CreateConference(eDeliveryType, eList, eMilestone);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectedText));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 7, enabled = false)
	public void TC_12() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 8, enabled = false)
	public void TC_13() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 9, enabled = false)
	public void TC_14() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 10, enabled = false)
	public void TC_15() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 11, enabled = false)
	public void TC_16() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateDecisionDetailsOption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 12, enabled = false)
	public void TC_17() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(14).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(14).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 13, enabled = false)
	public void TC_18() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(18).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 14, enabled = false)
	public void TC_19() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(18).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 15, enabled = false)
	public void TC_20() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(18).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 16, enabled = false)
	public void TC_21() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(18).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 17, enabled = false)
	public void TC_22() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 18, enabled = false)
	public void TC_23() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 19, enabled = false)
	public void TC_24() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 20, enabled = false)
	public void TC_25() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 21, enabled = false)
	public void TC_26() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 22, enabled = false)
	public void TC_27() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(22).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(22).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CancelJournceConf));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 23, enabled = false)
	public void TC_28() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(26).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(26).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 24, enabled = false)
	public void TC_29() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(26).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(26).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 25, enabled = false)
	public void TC_30() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(26).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(26).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 26, enabled = false)
	public void TC_31() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(26).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(26).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 27, enabled = false)
	public void TC_32() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(26).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(26).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RevertDecision));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 28, enabled = false)
	public void TC_33() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(30).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(30).getCell(2).getStringCellValue();
		String eList = ws.getRow(30).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(30).getCell(4).getStringCellValue();
		ObjectPubSupportTestClass.CreateConference(eDeliveryType, eList, eMilestone);
		// write a validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 29, enabled = false)
	public void TC_40() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(34).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 30, enabled = false)
	public void TC_41() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(34).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 31, enabled = false)
	public void TC_42() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(34).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 32, enabled = false)
	public void TC_43() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(34).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 33, enabled = false)
	public void TC_44() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 34, enabled = false)
	public void TC_45() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(38).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 35, enabled = false)
	public void TC_46() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(38).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 36, enabled = false)
	public void TC_47() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(38).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 37, enabled = false)
	public void TC_48() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(38).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 38, enabled = false)
	public void TC_49() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(38).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(38).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CancelJournceConf));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 39, enabled = false)
	public void TC_50() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 40, enabled = false)
	public void TC_51() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 41, enabled = false)
	public void TC_52() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 42, enabled = false)
	public void TC_53() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 43, enabled = false)
	public void TC_54() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateDecisionDetailsOption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 44, enabled = false)
	public void TC_55() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(42).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(42).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 45, enabled = false)
	public void TC_56() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(46).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(46).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 46, enabled = false)
	public void TC_57() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(46).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(46).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 47, enabled = false)
	public void TC_58() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(46).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(46).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 48, enabled = false)
	public void TC_59() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(46).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(46).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 49, enabled = false)
	public void TC_60() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(46).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(46).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RevertDecision));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 50, enabled = false)
	public void TC_61() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(50).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(50).getCell(2).getStringCellValue();
		String eList = ws.getRow(50).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(50).getCell(4).getStringCellValue();
		ObjectPubSupportTestClass.CreateConference(eDeliveryType, eList, eMilestone);
		// write a validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 51, enabled = false)
	public void TC_68() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(54).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 52, enabled = false)
	public void TC_69() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(54).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 53, enabled = false)
	public void TC_70() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(54).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 54, enabled = false)
	public void TC_71() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(54).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 55, enabled = false)
	public void TC_72() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 56, enabled = false)
	public void TC_73() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(58).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 57, enabled = false)
	public void TC_74() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(58).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 58, enabled = false)
	public void TC_75() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(58).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 59, enabled = false)
	public void TC_76() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(58).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 60, enabled = false)
	public void TC_77() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(58).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(58).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CancelJournceConf));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 61, enabled = false)
	public void TC_78() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 62, enabled = false)
	public void TC_79() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 63, enabled = false)
	public void TC_80() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 64, enabled = false)
	public void TC_81() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 65, enabled = false)
	public void TC_82() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateDecisionDetailsOption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 66, enabled = false)
	public void TC_83() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(62).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(62).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 67, enabled = false)
	public void TC_84() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(66).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(66).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 68, enabled = false)
	public void TC_85() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(66).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(66).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 69, enabled = false)
	public void TC_86() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(66).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(66).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 70, enabled = false)
	public void TC_87() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(66).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(66).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 71, enabled = false)
	public void TC_88() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(66).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(66).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RevertDecision));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 72, enabled = false)
	public void TC_89() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(70).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(70).getCell(2).getStringCellValue();
		String eList = ws.getRow(70).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(70).getCell(4).getStringCellValue();
		String eExpectedReviewPeriod = ws.getRow(70).getCell(5).getStringCellValue();
		String eImpactFactor = ws.getRow(70).getCell(6).getStringCellValue();
		String eRejectionRatio = ws.getRow(70).getCell(7).getStringCellValue();
		String eJournalEditInfo = ws.getRow(70).getCell(8).getStringCellValue();
		ObjectOfPubSupportClass.AddJournal(eDeliveryType, eList, eMilestone, eExpectedReviewPeriod, eImpactFactor,
				eRejectionRatio, eJournalEditInfo);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 73, enabled = false)
	public void TC_98() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(74).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 74, enabled = false)
	public void TC_99() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(74).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 75, enabled = false)
	public void TC_100() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(74).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 76, enabled = false)
	public void TC_101() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(74).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 77, enabled = false)
	public void TC_102() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 78, enabled = false)
	public void TC_103() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(78).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 79, enabled = false)
	public void TC_104() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(78).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 80, enabled = false)
	public void TC_105() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(78).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 81, enabled = false)
	public void TC_106() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(78).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 82, enabled = false)
	public void TC_107() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(78).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(78).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CancelJournceConf));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 83, enabled = false)
	public void TC_108() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 84, enabled = false)
	public void TC_109() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditJConfClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 85, enabled = false)
	public void TC_110() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 86, enabled = false)
	public void TC_111() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 87, enabled = false)
	public void TC_112() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateDecisionDetailsOption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 88, enabled = false)
	public void TC_113() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(82).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(82).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateJournalRequirementClick));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 89, enabled = false)
	public void TC_114() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(86).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(86).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 90, enabled = false)
	public void TC_115() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(86).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(86).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddJCoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 91, enabled = false)
	public void TC_116() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(86).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(86).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddAUTHoption));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 92, enabled = false)
	public void TC_117() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(86).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(86).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAUForms));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 93, enabled = false)
	public void TC_118() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(86).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.SearchPubSupportStatus(ws.getRow(86).getCell(2).getStringCellValue());
		driver.findElement(pMenu).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RevertDecision));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 94, enabled = false)
	public void TC_119() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(90).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(90).getCell(2).getStringCellValue();
		String eConferenceName = ws.getRow(90).getCell(3).getStringCellValue();
		String eConferenceDate = ws.getRow(90).getCell(4).getStringCellValue();
		String eSubmissionDeadline = ws.getRow(90).getCell(5).getStringCellValue();
		String eComments = ws.getRow(90).getCell(6).getStringCellValue();
		String eMilestone = ws.getRow(90).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.CreateConferenceByAddingNewConference(eDeliveryType, eConferenceName, eConferenceDate,
				eSubmissionDeadline, eComments, eMilestone);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectedText));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 95, enabled = false)
	public void TC_120() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(94).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(94).getCell(2).getStringCellValue();
		String eConferenceName = ws.getRow(94).getCell(3).getStringCellValue();
		String eConferenceDate = ws.getRow(94).getCell(4).getStringCellValue();
		String eSubmissionDeadline = ws.getRow(94).getCell(5).getStringCellValue();
		String eComments = ws.getRow(94).getCell(6).getStringCellValue();
		String eMilestone = ws.getRow(94).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.CreateConferenceByAddingNewConference(eDeliveryType, eConferenceName, eConferenceDate,
				eSubmissionDeadline, eComments, eMilestone);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectedText));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 96, enabled = false)
	public void TC_121() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(98).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(98).getCell(2).getStringCellValue();
		String eConferenceName = ws.getRow(98).getCell(3).getStringCellValue();
		String eConferenceDate = ws.getRow(98).getCell(4).getStringCellValue();
		String eSubmissionDeadline = ws.getRow(98).getCell(5).getStringCellValue();
		String eComments = ws.getRow(98).getCell(6).getStringCellValue();
		String eMilestone = ws.getRow(98).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.CreateConferenceByAddingNewConference(eDeliveryType, eConferenceName, eConferenceDate,
				eSubmissionDeadline, eComments, eMilestone);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectedText));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 97, enabled = false)
	public void TC_122() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(102).getCell(1).getStringCellValue());
		String eDeliveryType = ws.getRow(102).getCell(2).getStringCellValue();
		String eJournalName = ws.getRow(102).getCell(3).getStringCellValue();
		String eExpectedReviewPeriod = ws.getRow(102).getCell(4).getStringCellValue();
		String eImpactFactor = ws.getRow(102).getCell(5).getStringCellValue();
		String eRejectionRatio = ws.getRow(102).getCell(6).getStringCellValue();
		String eComments = ws.getRow(102).getCell(7).getStringCellValue();
		String eJournalEditorInfo = ws.getRow(102).getCell(8).getStringCellValue();
		String eMilestone = ws.getRow(102).getCell(9).getStringCellValue();
		ObjectOfPubSupportClass.CreateJournalByAddingNewJournal(eDeliveryType, eJournalName, eExpectedReviewPeriod,
				eImpactFactor, eRejectionRatio, eComments, eJournalEditorInfo, eMilestone);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectedText));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 98, enabled = false)
	public void TC_123() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(106).getCell(1).getStringCellValue());
		String eFirstName = ws.getRow(106).getCell(2).getStringCellValue();
		String eLastName = ws.getRow(106).getCell(3).getStringCellValue();
		String eComments = ws.getRow(106).getCell(4).getStringCellValue();
		String eHighestDegree = ws.getRow(106).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(106).getCell(6).getStringCellValue();
		String eAddress = ws.getRow(106).getCell(7).getStringCellValue();
		String eAffiliation = ws.getRow(106).getCell(8).getStringCellValue();
		String ePhone_x0020_No = String.valueOf(ws.getRow(106).getCell(9).getNumericCellValue());
		String eFax = String.valueOf(ws.getRow(106).getCell(10).getNumericCellValue());
		String eAuthorType = ws.getRow(106).getCell(11).getStringCellValue();
		ObjectOfPubSupportClass.addAuthors(eFirstName, eLastName, eComments, eHighestDegree, eEmailAddress, eAddress,
				eAffiliation, ePhone_x0020_No, eFax, eAuthorType);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 99, enabled = false)
	public void TC_124() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(110).getCell(1).getStringCellValue());
		String eFirstName = ws.getRow(110).getCell(2).getStringCellValue();
		String eLastName = ws.getRow(110).getCell(3).getStringCellValue();
		String eComments = ws.getRow(110).getCell(4).getStringCellValue();
		String eHighestDegree = ws.getRow(110).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(110).getCell(6).getStringCellValue();
		String eAddress = ws.getRow(110).getCell(7).getStringCellValue();
		String eAffiliation = ws.getRow(110).getCell(8).getStringCellValue();
		String ePhone_x0020_No = String.valueOf(ws.getRow(110).getCell(9).getNumericCellValue());
		String eFax = String.valueOf(ws.getRow(110).getCell(10).getNumericCellValue());
		String eAuthorType = ws.getRow(110).getCell(11).getStringCellValue();
		ObjectOfPubSupportClass.addAuthors(eFirstName, eLastName, eComments, eHighestDegree, eEmailAddress, eAddress,
				eAffiliation, ePhone_x0020_No, eFax, eAuthorType);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 100, enabled = false)
	public void TC_125() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(114).getCell(1).getStringCellValue());
		String eFirstName = ws.getRow(114).getCell(2).getStringCellValue();
		String eLastName = ws.getRow(114).getCell(3).getStringCellValue();
		String eComments = ws.getRow(114).getCell(4).getStringCellValue();
		String eHighestDegree = ws.getRow(114).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(114).getCell(6).getStringCellValue();
		String eAddress = ws.getRow(114).getCell(7).getStringCellValue();
		String eAffiliation = ws.getRow(114).getCell(8).getStringCellValue();
		String ePhone_x0020_No = String.valueOf(ws.getRow(114).getCell(9).getNumericCellValue());
		String eFax = String.valueOf(ws.getRow(114).getCell(10).getNumericCellValue());
		String eAuthorType = ws.getRow(114).getCell(11).getStringCellValue();
		ObjectOfPubSupportClass.addAuthors(eFirstName, eLastName, eComments, eHighestDegree, eEmailAddress, eAddress,
				eAffiliation, ePhone_x0020_No, eFax, eAuthorType);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 101, enabled = false)
	public void TC_126() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(118).getCell(1).getStringCellValue());
		String eFirstName = ws.getRow(118).getCell(2).getStringCellValue();
		String eLastName = ws.getRow(118).getCell(3).getStringCellValue();
		String eComments = ws.getRow(118).getCell(4).getStringCellValue();
		String eHighestDegree = ws.getRow(118).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(118).getCell(6).getStringCellValue();
		String eAddress = ws.getRow(118).getCell(7).getStringCellValue();
		String eAffiliation = ws.getRow(118).getCell(8).getStringCellValue();
		String ePhone_x0020_No = String.valueOf(ws.getRow(118).getCell(9).getNumericCellValue());
		String eFax = String.valueOf(ws.getRow(118).getCell(10).getNumericCellValue());
		String eAuthorType = ws.getRow(118).getCell(11).getStringCellValue();
		ObjectOfPubSupportClass.addAuthors(eFirstName, eLastName, eComments, eHighestDegree, eEmailAddress, eAddress,
				eAffiliation, ePhone_x0020_No, eFax, eAuthorType);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 102, enabled = false)
	public void TC_127() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(122).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(122).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateAuthors(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 103, enabled = false)
	public void TC_128() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(126).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(126).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateAuthors(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 104, enabled = false)
	public void TC_129() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(130).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(130).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateAuthors(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 105, enabled = false)
	public void TC_130() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(134).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(134).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateAuthors(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 106, enabled = false)
	public void TC_131() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(138).getCell(1).getStringCellValue());
		String eExistingAuthorProjectCode = ws.getRow(138).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SelectFromExistingAuthors(eExistingAuthorProjectCode);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 107, enabled = false)
	public void TC_132() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(142).getCell(1).getStringCellValue());
		String eExistingAuthorProjectCode = ws.getRow(142).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SelectFromExistingAuthors(eExistingAuthorProjectCode);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 108, enabled = false)
	public void TC_133() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(146).getCell(1).getStringCellValue());
		String eExistingAuthorProjectCode = ws.getRow(146).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SelectFromExistingAuthors(eExistingAuthorProjectCode);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 109, enabled = false)
	public void TC_134() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(150).getCell(1).getStringCellValue());
		String eExistingAuthorProjectCode = ws.getRow(150).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SelectFromExistingAuthors(eExistingAuthorProjectCode);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 110, enabled = false)
	public void TC_135() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(154).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(154).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateJournalRequirement(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 111, enabled = false)
	public void TC_136() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(158).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(158).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateJournalRequirement(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 112, enabled = false)
	public void TC_137() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(162).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(162).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateJournalRequirement(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 113, enabled = false)
	public void TC_138() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(166).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(166).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.UpdateJournalRequirement(eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 114, enabled = false)
	public void TC_139() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(170).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.CancelConference();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 115, enabled = false)
	public void TC_140() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(174).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.CancelConference();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 116, enabled = false)
	public void TC_141() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(178).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.CancelConference();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 117, enabled = false)
	public void TC_142() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(182).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.CancelConference();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 118, enabled = false)
	public void TC_143() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(186).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(186).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(186).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(186).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 119, enabled = false)
	public void TC_144() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(190).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(190).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(190).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(190).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 120, enabled = false)
	public void TC_145() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(194).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(194).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(194).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(194).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 121, enabled = false)
	public void TC_146() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(198).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(198).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(198).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(198).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 122, enabled = false)
	public void TC_147() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(202).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(202).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(202).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(202).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 123, enabled = false)
	public void TC_148() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(206).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(206).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(206).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(206).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 124, enabled = false)
	public void TC_149() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(210).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(210).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(210).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(210).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 125, enabled = false)
	public void TC_150() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(214).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(214).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(214).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(214).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 126, enabled = false)
	public void TC_151() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(218).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(218).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		String eFileName = ws.getRow(218).getCell(3).getStringCellValue();
		String eDecision = ws.getRow(218).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.UpdateDecisionDetails(eFileName, eDecision);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 127, enabled = false)
	public void TC_152() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(222).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(222).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		ObjectOfPubSupportClass.RevertDecision();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 128, enabled = false)
	public void TC_153() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(226).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(226).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		ObjectOfPubSupportClass.RevertDecision();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 129, enabled = false)
	public void TC_154() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(230).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(230).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		ObjectOfPubSupportClass.RevertDecision();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 130, enabled = false)
	public void TC_155() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(234).getCell(1).getStringCellValue());
		String ePubSupportStatus = ws.getRow(234).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.SearchPubSupportStatus(ePubSupportStatus);
		ObjectOfPubSupportClass.RevertDecision();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 131, enabled = false)
	public void TC_156() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(238).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(238).getCell(1).getStringCellValue();
		String eName = ws.getRow(238).getCell(2).getStringCellValue();
		String eHighestDegree = ws.getRow(238).getCell(3).getStringCellValue();
		String eAddress = ws.getRow(238).getCell(4).getStringCellValue();
		String eAffiliation = ws.getRow(238).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(238).getCell(6).getStringCellValue();
		String eAuthorType = ws.getRow(238).getCell(7).getStringCellValue();
		String ePhoneNumber = ws.getRow(238).getCell(8).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthors(eProjectCode, eName, eHighestDegree, eAddress, eAffiliation,
				eEmailAddress, eAuthorType, ePhoneNumber);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 132, enabled = false)
	public void TC_157() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(242).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(242).getCell(1).getStringCellValue();
		String eFileName = ws.getRow(242).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthorsForms(eProjectCode, eFileName);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 133, enabled = false)
	public void TC_158() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(246).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(246).getCell(1).getStringCellValue();
		String eName = ws.getRow(246).getCell(2).getStringCellValue();
		String eHighestDegree = ws.getRow(246).getCell(3).getStringCellValue();
		String eAddress = ws.getRow(246).getCell(4).getStringCellValue();
		String eAffiliation = ws.getRow(246).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(246).getCell(6).getStringCellValue();
		String eAuthorType = ws.getRow(246).getCell(7).getStringCellValue();
		String ePhoneNumber = ws.getRow(246).getCell(8).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthors(eProjectCode, eName, eHighestDegree, eAddress, eAffiliation,
				eEmailAddress, eAuthorType, ePhoneNumber);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 134, enabled = false)
	public void TC_159() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(250).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(250).getCell(1).getStringCellValue();
		String eFileName = ws.getRow(250).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthorsForms(eProjectCode, eFileName);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 135, enabled = false)
	public void TC_160() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(254).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(254).getCell(1).getStringCellValue();
		String eName = ws.getRow(254).getCell(2).getStringCellValue();
		String eHighestDegree = ws.getRow(254).getCell(3).getStringCellValue();
		String eAddress = ws.getRow(254).getCell(4).getStringCellValue();
		String eAffiliation = ws.getRow(254).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(254).getCell(6).getStringCellValue();
		String eAuthorType = ws.getRow(254).getCell(7).getStringCellValue();
		String ePhoneNumber = ws.getRow(254).getCell(8).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthors(eProjectCode, eName, eHighestDegree, eAddress, eAffiliation,
				eEmailAddress, eAuthorType, ePhoneNumber);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 136, enabled = false)
	public void TC_161() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(258).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(258).getCell(1).getStringCellValue();
		String eFileName = ws.getRow(258).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthorsForms(eProjectCode, eFileName);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 137, enabled = false)
	public void TC_162() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(262).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(262).getCell(1).getStringCellValue();
		String eName = ws.getRow(262).getCell(2).getStringCellValue();
		String eHighestDegree = ws.getRow(262).getCell(3).getStringCellValue();
		String eAddress = ws.getRow(262).getCell(4).getStringCellValue();
		String eAffiliation = ws.getRow(262).getCell(5).getStringCellValue();
		String eEmailAddress = ws.getRow(262).getCell(6).getStringCellValue();
		String eAuthorType = ws.getRow(262).getCell(7).getStringCellValue();
		String ePhoneNumber = ws.getRow(262).getCell(8).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthors(eProjectCode, eName, eHighestDegree, eAddress, eAffiliation,
				eEmailAddress, eAuthorType, ePhoneNumber);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 138, enabled = false)
	public void TC_163() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(266).getCell(1).getStringCellValue());
		String eProjectCode = ws.getRow(266).getCell(1).getStringCellValue();
		String eFileName = ws.getRow(266).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.VerifyAuthorsForms(eProjectCode, eFileName);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 139, enabled = false)
	public void TC_164() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(270).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(270).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(270).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(270).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, null, null, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 140, enabled = false)
	public void TC_165() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(274).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(274).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(274).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(274).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, null, null, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 141, enabled = false)
	public void TC_166() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(278).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(278).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(278).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(278).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, null, null, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 142, enabled = false)
	public void TC_167() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(282).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(282).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(282).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(282).getCell(4).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, null, null, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 143, enabled = false)
	public void TC_168() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(286).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(286).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(286).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(286).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(286).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(286).getCell(6).getStringCellValue();
		String eComments = ws.getRow(286).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, eConfDate, eSubDate, eComments);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 144, enabled = false)
	public void TC_169() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(290).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(290).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(290).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(290).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(290).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(290).getCell(6).getStringCellValue();
		String eComments = ws.getRow(290).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, eConfDate, eSubDate, eComments);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 145, enabled = false)
	public void TC_170() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(294).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(294).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(294).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(294).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(294).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(294).getCell(6).getStringCellValue();
		String eComments = ws.getRow(294).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, eConfDate, eSubDate, eComments);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 146, enabled = false)
	public void TC_171() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(298).getCell(1).getStringCellValue());
		String eMilestone = ws.getRow(298).getCell(2).getStringCellValue();
		String eUserName = ws.getRow(298).getCell(3).getStringCellValue();
		String ePassword = ws.getRow(298).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(298).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(298).getCell(6).getStringCellValue();
		String eComments = ws.getRow(298).getCell(7).getStringCellValue();
		ObjectOfPubSupportClass.EditConference(eMilestone, eUserName, ePassword, eConfDate, eSubDate, eComments);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 147, enabled = false)
	public void TC_172() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(302).getCell(1).getStringCellValue());
		String eConferenceName = ws.getRow(302).getCell(2).getStringCellValue();
		String eDeliveryType = ws.getRow(302).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(302).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(302).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(302).getCell(6).getStringCellValue();
		String eUN = ws.getRow(302).getCell(7).getStringCellValue();
		String ePwd = ws.getRow(302).getCell(8).getStringCellValue();
		String eComments = ws.getRow(302).getCell(9).getStringCellValue();
		ObjectOfPubSupportClass.VerifyConferenceDetails(eConferenceName, eDeliveryType, eMilestone, eConfDate, eSubDate,
				eUN, ePwd, eComments);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 148, enabled = false)
	public void TC_173() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(306).getCell(1).getStringCellValue());
		String eConferenceName = ws.getRow(306).getCell(2).getStringCellValue();
		String eDeliveryType = ws.getRow(306).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(306).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(306).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(306).getCell(6).getStringCellValue();
		String eUN = ws.getRow(306).getCell(7).getStringCellValue();
		String ePwd = ws.getRow(306).getCell(8).getStringCellValue();
		String eComments = ws.getRow(306).getCell(9).getStringCellValue();
		ObjectOfPubSupportClass.VerifyConferenceDetails(eConferenceName, eDeliveryType, eMilestone, eConfDate, eSubDate,
				eUN, ePwd, eComments);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 149, enabled = false)
	public void TC_174() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(310).getCell(1).getStringCellValue());
		String eConferenceName = ws.getRow(310).getCell(2).getStringCellValue();
		String eDeliveryType = ws.getRow(310).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(310).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(310).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(310).getCell(6).getStringCellValue();
		String eUN = ws.getRow(310).getCell(7).getStringCellValue();
		String ePwd = ws.getRow(310).getCell(8).getStringCellValue();
		String eComments = ws.getRow(310).getCell(9).getStringCellValue();
		ObjectOfPubSupportClass.VerifyConferenceDetails(eConferenceName, eDeliveryType, eMilestone, eConfDate, eSubDate,
				eUN, ePwd, eComments);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 150, enabled = false)
	public void TC_175() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(314).getCell(1).getStringCellValue());
		String eConferenceName = ws.getRow(314).getCell(2).getStringCellValue();
		String eDeliveryType = ws.getRow(314).getCell(3).getStringCellValue();
		String eMilestone = ws.getRow(314).getCell(4).getStringCellValue();
		String eConfDate = ws.getRow(314).getCell(5).getStringCellValue();
		String eSubDate = ws.getRow(314).getCell(6).getStringCellValue();
		String eUN = ws.getRow(314).getCell(7).getStringCellValue();
		String ePwd = ws.getRow(314).getCell(8).getStringCellValue();
		String eComments = ws.getRow(314).getCell(9).getStringCellValue();
		ObjectOfPubSupportClass.VerifyConferenceDetails(eConferenceName, eDeliveryType, eMilestone, eConfDate, eSubDate,
				eUN, ePwd, eComments);
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 151, enabled = true)
	public void TC_176() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(318).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(1, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 152, enabled = false)
	public void TC_177() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(322).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(322).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(1, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 153, enabled = false)
	public void TC_178() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(326).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(1, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 154, enabled = false)
	public void TC_179() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(330).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(330).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(1, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 155, enabled = false)
	public void TC_180() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(334).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(1, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 156, enabled = false)
	public void TC_181() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(338).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(338).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(1, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 157, enabled = false)
	public void TC_182() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(342).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(1, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 158, enabled = false)
	public void TC_183() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(346).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(346).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(1, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 159, enabled = false)
	public void TC_184() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(350).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(3, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 160, enabled = false)
	public void TC_185() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(354).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(354).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(3, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 161, enabled = false)
	public void TC_186() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(358).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(3, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 162, enabled = false)
	public void TC_187() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(362).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(362).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(3, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 163, enabled = false)
	public void TC_188() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(366).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(3, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 164, enabled = false)
	public void TC_189() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(370).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(370).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(3, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 165, enabled = false)
	public void TC_190() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(374).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(3, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 166, enabled = false)
	public void TC_191() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(378).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(378).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(3, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 167, enabled = false)
	public void TC_192() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(382).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(5, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 168, enabled = false)
	public void TC_193() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(386).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(386).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(5, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 169, enabled = false)
	public void TC_194() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(390).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(5, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 170, enabled = false)
	public void TC_195() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(394).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(394).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(5, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 171, enabled = false)
	public void TC_196() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(398).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(5, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 172, enabled = false)
	public void TC_197() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(402).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(402).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(5, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 173, enabled = false)
	public void TC_198() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(406).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(5, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 174, enabled = false)
	public void TC_199() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(410).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(410).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(5, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 175, enabled = false)
	public void TC_200() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(414).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(7, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 176, enabled = false)
	public void TC_201() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(418).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(418).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(7, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 177, enabled = false)
	public void TC_202() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(422).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(7, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 178, enabled = false)
	public void TC_203() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(426).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(426).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(7, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 179, enabled = false)
	public void TC_204() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(430).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(7, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 180, enabled = false)
	public void TC_205() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(434).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(434).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(7, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 181, enabled = false)
	public void TC_206() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(438).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(7, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 182, enabled = false)
	public void TC_207() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(442).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(442).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(7, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(priority = 183, enabled = false)
	public void TC_208() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(446).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(9, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 184, enabled = false)
	public void TC_209() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(450).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(450).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(9, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 185, enabled = false)
	public void TC_210() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(454).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(9, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 186, enabled = false)
	public void TC_211() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(458).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(458).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(9, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 187, enabled = false)
	public void TC_212() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(462).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(9, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 188, enabled = false)
	public void TC_213() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(466).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(466).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(9, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 189, enabled = false)
	public void TC_214() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(470).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(9, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 190, enabled = false)
	public void TC_215() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(474).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(474).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(9, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(priority = 191, enabled = false)
	public void TC_216() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(478).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(11, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 192, enabled = false)
	public void TC_217() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(482).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(482).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(11, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 193, enabled = false)
	public void TC_218() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(486).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(11, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 194, enabled = false)
	public void TC_219() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(490).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(490).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(11, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 195, enabled = false)
	public void TC_220() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(494).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(11, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 196, enabled = false)
	public void TC_221() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(498).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(498).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(11, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 197, enabled = false)
	public void TC_222() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(502).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(11, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 198, enabled = false)
	public void TC_223() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(506).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(506).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(11, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(priority = 199, enabled = false)
	public void TC_224() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(510).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(13, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 200, enabled = false)
	public void TC_225() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(514).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(514).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(13, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 201, enabled = false)
	public void TC_226() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(518).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(13, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 202, enabled = false)
	public void TC_227() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(522).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(522).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(13, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 203, enabled = false)
	public void TC_228() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(526).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(13, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 204, enabled = false)
	public void TC_229() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(530).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(530).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(13, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 205, enabled = false)
	public void TC_230() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(534).getCell(1).getStringCellValue());
		ObjectOfPubSupportClass.DocumentUploadDownload(13, true, null);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(priority = 206, enabled = false)
	public void TC_231() throws IOException, InterruptedException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectOfPubSupportClass.Navigation();
		ObjectOfPubSupportClass.SearchProjectCode(ws.getRow(538).getCell(1).getStringCellValue());
		String eFileName = ws.getRow(538).getCell(2).getStringCellValue();
		ObjectOfPubSupportClass.DocumentUploadDownload(13, false, eFileName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		ObjectsOfBaseClass.CloseBrowser();
	}
}
