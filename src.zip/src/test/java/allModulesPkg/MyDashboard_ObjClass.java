package allModulesPkg;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.remote.internal.JsonToWebElementConverter;


public class MyDashboard_ObjClass extends Login {
	
	BaseClass ObjectsOfBaseClass = new BaseClass();

	
	int i, j;


	By Username = By.xpath("//input[@name='loginfmt']");
	By NextButton = By.xpath("//input[@id='idSIButton9']");
	By Password = By.xpath("//input[@id='passwordInput']");
	By SignIn = By.xpath("//span[@id='submitButton']");
	By SigninPopup = By.xpath("//input[@id='idSIButton9']");
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By MyDashboardLink = By.xpath("//a[text()='My Dashboard']"); 

	By DropdownInputBoxCommon = By.xpath("//input[@class='ui-inputtext ui-widget ui-state-default ui-corner-all' and @role='textbox']");
	By DropdownInputBoxClientName = By.xpath("//input[@class='ui-dropdown-filter ui-inputtext ui-widget ui-state-default ui-corner-all' and @type='text']");
	//By TaskNameCheckBox = By.xpath("//div[@class='ui-chkbox ui-widget ng-tns-c9-10 ng-star-inserted']");
	By TotalTasks = By.xpath("//li[@class='ui-multiselect-item ui-corner-all']");
	By TotalClientNames = By.xpath("//li[@class='ui-dropdown-item ui-corner-all' or @class='ui-dropdown-item ui-corner-all ui-state-highlight']");
	By DropdownClose = By.xpath("//a[@class='ui-multiselect-close ui-corner-all']");

	By Todaytab = By.xpath("//span[text()='Today']");
	By Next7Daystab = By.xpath("//span[text()='Next 7 Days']"); 
	By Next14Daystab = By.xpath("//span[text()='Next 14 Days']");
	By Past7Daystab = By.xpath("//span[text()='Past 7 Days']");
	By Past14Daystab = By.xpath("//span[text()='Past 14 Days']");

	By TaskNameDropdownToday = By.xpath("//div[@class='ng-tns-c9-10 ui-multiselect ui-widget ui-state-default ui-corner-all']");
	By TaskNameDropdownNext7Days = By.xpath("//div[@class='ng-tns-c9-23 ui-multiselect ui-widget ui-state-default ui-corner-all']");
	By TaskNameDropdownNext14Days = By.xpath("//div[@class='ng-tns-c9-36 ui-multiselect ui-widget ui-state-default ui-corner-all']");
	By TaskNameDropdownPast7Days = By.xpath("//div[@class='ng-tns-c9-49 ui-multiselect ui-widget ui-state-default ui-corner-all']");
	By TaskNameDropdownPast14Days = By.xpath("//div[@class='ng-tns-c9-64 ui-multiselect ui-widget ui-state-default ui-corner-all']");

	By MainStatusNotCompleted = By.xpath("//span[text()=' Not Completed']");
	By TaskStatusNotStarted = By.xpath("//span[text()=' Not Started']");

	By TimeSpentTaskNotStarted = By.xpath("//span[text()=' 0 ']");
	By TimeBlocks = By.xpath("//div[@class='date-as-calendar inline-flex size3x ng-star-inserted']");
	By TimeBocksDisabled = By.xpath("//div[@class='date-as-calendar inline-flex size3x ng-star-inserted']//div[@style='background-color: rgb(205, 205, 205);']");
	By TimeBlocks_TimeBooking = By.xpath("//input[@class='ng-untouched ng-pristine ng-valid ng-star-inserted']");

	By Cancel_Clock = By.xpath("//button[@class='timepicker-button']//*[.='Cancel']");
	By HH_01=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='1']");
	By HH_02=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='2']");
	By HH_03=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='3']");
	By HH_04=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='4']");
	By HH_05=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='5']");
	By HH_06=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='6']");
	By HH_07=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='7']");
	By HH_08=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='8']");
	By HH_09=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='9']");
	By HH_10=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='10']");
	By HH_11=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='11']");
	By HH_12=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.='12']");		
	By MM_15=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.=' 15']");	
	By MM_30=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.=' 30']");		
	By MM_45=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.=' 45']");	
	By MM_00=By.xpath("//div[@class='clock-face__container ng-star-inserted']//span[.=' 00']");
	By Clock_AM=By.xpath("//div[@class='timepicker-period']//*[.='AM']");
	By Clock_PM=By.xpath("//div[@class='timepicker-period']//*[.='PM']");
	By Clock_OK=By.xpath("//button[@class='timepicker-button']//span[.='Ok']");	

	By SaveTimeButton = By.xpath("//span[text()='Save Time']");

	By DropdownCommon = By.xpath("//span[@class='ui-multiselect-label ui-corner-all']");

	By ViewUploadDocumentOption = By.xpath("//span[text()='View / Upload Documents']");
	By MyDraftsTab = By.xpath("//span[text()='My Drafts']");
	By ChooseButton = By.xpath("//span[@icon='pi pi-plus']");
	By UploadButton = By.xpath("//span[text()='Upload']");
	By MarkFinalButton = By.xpath("//th[@ng-reflect-field='Name']//span[text()='Mark final']");
	By CheckBoxUploadedFile = By.xpath("//*[@id='ui-tabpanel-0']/p-table/div/div/table/thead/tr/th[1]/p-tableheadercheckbox/div/div[2]");
	
	By SimpleCheckBox = By.xpath("//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']");
	
	By ClosePopUp = By.xpath("//span[@class='pi pi-times']");

	By MarkCompleteOption = By.xpath("//span[text()='Mark Complete']");
	By SaveWithoutCommentsButton = By.xpath("//span[text()='Save without Comment']");

	By MyOpenTasksTab = By.xpath("//span[text()='My Open Tasks']");
	By MyTimelineTab = By.xpath("//span[text()='My Timeline']");
	By MyProjectsTab = By.xpath("//span[text()='My Projects']");
	By MySOWTab = By.xpath("//span[text()='My SOW']");
	By MyCompletedTasksTab = By.xpath("//span[text()='My Completed Tasks']");
	By SearchProjectsTab = By.xpath("//span[text()='Search Projects']");	

	By AddTasksButton = By.xpath("//button[@class='fc-AddnewEvent-button fc-button fc-button-primary']");
	By LeaveOption = By.xpath("//span[text()='Leave']");
	By ClientMeetingOrTrainingOption = By.xpath("//span[text()='Client Meeting / Training']");
	By InternalMeetingOption = By.xpath("//span[text()='Internal Meeting']");
	By TrainingOption = By.xpath("//span[text()='Training']");
	By AdminOption = By.xpath("//span[text()='Admin']");
	By StartDate = By.xpath("//input[@placeholder='Select Start Date']");
	By EndDate = By.xpath("//input[@placeholder='Select End Date']");
	By Date = By.xpath("//input[@placeholder='Select Date']");
	By DateHeading = By.xpath("//th[text()='Date:']");
	By StartTime = By.xpath("//input[@placeholder='Select Start Time']");
	By EndTime = By.xpath("//input[@placeholder='Select End Time']");	
	By TotalHrs = By.xpath("//input[@placeholder='Select Hours']");

	By DisabledDays = By.xpath("//span[@ng-reflect-klass='ui-state-default ui-state-disa']");
	By ActiveDays = By.xpath("//a[@draggable='false']");
	By TotalDays = By.xpath("//span[@ng-reflect-klass='ui-state-default ui-state-disa']|//a[@draggable='false']");	
	By DatepickerTitle = By.xpath("//div[@class='ui-datepicker-title']");
	//By TodaySelected = By.xpath("//a[@class='ui-state-default ng-tns-c8-16 ui-state-highlight ng-star-inserted']");
	//By InActiveDates = By.xpath("//span[@ng-reflect-klass='ui-state-default ui-state-disa']");
	By CommentsBox = By.xpath("//textarea[@rows='7' and @style='width: 100%;']");
	By SaveButton = By.xpath("//span[text()='Save']");
	By TaskCreateButton = By.xpath("//span[text()='Create']");

	By TaskCancelButton = By.xpath("//span[text()='Cancel']");
	By ClientNameDropdown = By.xpath("//div[@class='ui-dropdown-label-container']//*[.='Select a Client']");
	By NoResultsFound = By.xpath("//li[text()='No results found']");

	//ColumnsAndElementsOfAllTabs
	//By pMenu=By.xpath("//div[@class='ng-star-inserted']//i[@class='pi pi-ellipsis-v']");
	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By Column_SNo = By.xpath("//th[text()='S.No']");
	//By Column_SOWCode = By.xpath("//th[text()=' Sow Code ']"); //For My Projects tab
	//By Column_SOWCode = By.xpath("//th[text()=' SOW Code ']"); //For My SOW tab
	By Column_SOWCode = By.xpath("//th[@ng-reflect-field='SOWCode']"); //Common
	By Column_ProjectCode = By.xpath("//th[text()=' Project Code ']");
	By Column_ShortTitle = By.xpath("//th[text()=' Short Title ']");
	By Column_ClientLegalEntity = By.xpath("//th[text()=' Client Legal Entity ']");
	By Column_ProjectType = By.xpath("//th[text()=' Project Type ']");
	By Column_PrimaryResource = By.xpath("//th[text()=' Primary Resources ']");
	By Column_POC = By.xpath("//th[text()=' POC ']");
	By Column_TA = By.xpath("//th[text()=' TA ']");
	By Column_Molecule = By.xpath("//th[text()=' Molecule ']");
	By Column_Status = By.xpath("//th[text()=' Status ' and @ng-reflect-field='Status']"); //one hidden column is having same text that's wh	y used and operaration
	By ViewDetailsOption = By.xpath("//span[text()='View Details']");
	By ShowHistoryOption = By.xpath("//span[text()='Show History']");
	By Column_SOWTitle = By.xpath("//th[text()=' SOW Title ']");
	By Column_Currency = By.xpath("//th[text()=' Currency ']");
	By Column_RevenueBudget = By.xpath("//th[text()=' Revenue Budget ']");
	By Column_OOPBudget = By.xpath("//th[text()=' OOP Budget ']");
	By Column_ModifiedBy = By.xpath("//th[text()=' Modified By ']");
	By Column_ModifiedDate = By.xpath("//th[text()=' Modified Date ' and @ng-reflect-field='ModifiedDate']");
	By ViewSOWOption = By.xpath("//span[text()='View SOW']");
	By ViewProjectsOption = By.xpath("//span[text()='View Projects']");
	By SearchProjectCodeField = By.xpath("//input[@name='ProjectCode']");
	By SearchProjectTitleField = By.xpath("//input[@name='ProjectTitle']");
	By SearchProjectButton = By.xpath("//span[text()='Search']");	
	By SearchFieldTimeBooking = By.xpath("//input[@class='ui-inputtext ui-corner-all ui-state-default ui-widget']");
	By Column_DeliverableType = By.xpath("//th[text()=' Deliverable Type ']"); //-ve TC My Projects tab

	By ManageFTEIcon = By.xpath("//i[@class='fa fa-user ng-star-inserted' and @title='Manage FTE Work']");
	By TimeBooking = By.xpath("//i[@class='fa fa-calendar-plus-o' and @title='Time Booking']");

	By AppliedHalfDayLeaveElement = By.xpath("//table/tbody/tr/td[@class='fc-event-container' and position()=3]");
	By AppliedFullDayLeaveElement = By.xpath("//table/tbody/tr/td[@class='fc-event-container' and position()=2]");
	By YesButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Yes']");
	By LeaveDelete_ValPoint = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'deleted')]");
	By ApplyLeave_ValPoint2 = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'Leave already exist')]");

	

	

	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(MyDashboardLink).click();
	}

	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	public void ClosePopUp() throws InterruptedException{
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClosePopUp).click();		
	}

	
	public void ClickTodayTaskNameDropdown(){
		//driver.findElement(Todaytab).click();	
		wait.until(ExpectedConditions.visibilityOfElementLocated(DropdownCommon));		
		List<WebElement> C_DropdownToday = driver.findElements(DropdownCommon);
		//System.out.println("there are "+ C_DropdownToday.size() +" Dropdowns available");
		C_DropdownToday.get(2).click();
	}

	public void ClickNext7DaysTaskNameDropdown(){
		driver.findElement(Next7Daystab).click();			
		wait.until(ExpectedConditions.visibilityOfElementLocated(DropdownCommon));		
		List<WebElement> C_DropdownNext7Days = driver.findElements(DropdownCommon);
		C_DropdownNext7Days.get(2).click();
	}

	public void ClickNext14DaysTaskNameDropdown(){
		driver.findElement(Next14Daystab).click();			
		wait.until(ExpectedConditions.visibilityOfElementLocated(DropdownCommon));		
		List<WebElement> C_DropdownNext14Days = driver.findElements(DropdownCommon);
		C_DropdownNext14Days.get(2).click();	
	}

	public void ClickPast7DaysTaskNameDropdown(){
		driver.findElement(Past7Daystab).click();			
		wait.until(ExpectedConditions.visibilityOfElementLocated(DropdownCommon));		
		List<WebElement> C_DropdownPast7Days = driver.findElements(DropdownCommon);
		C_DropdownPast7Days.get(2).click();	
	}

	public void ClickPast14DaysTaskNameDropdown(){
		driver.findElement(Past14Daystab).click();			
		wait.until(ExpectedConditions.visibilityOfElementLocated(DropdownCommon));		
		List<WebElement> C_DropdownPast14Days = driver.findElements(DropdownCommon);
		C_DropdownPast14Days.get(2).click();	
	}

	public void MakeTaskInProgress(){
		String MainStatus = driver.findElement(MainStatusNotCompleted).getText();
		String TaskStatus = driver.findElement(TaskStatusNotStarted).getText();
		if(MainStatus.equals("Not Completed") && TaskStatus.equals("Not Started"))
		{			
			wait.until(ExpectedConditions.visibilityOfElementLocated(TimeSpentTaskNotStarted));	
			driver.findElement(TimeSpentTaskNotStarted).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveTimeButton));
			List<WebElement> TotalBlocks = driver.findElements(TimeBlocks);
			int TotalNumberOfBlocks = TotalBlocks.size();
			List<WebElement> TotalBlocksDisabled = driver.findElements(TimeBocksDisabled);
			int TotalNumberOfDisabledBlocks = TotalBlocksDisabled.size();
			//int TotalNumberOgEnabledBlocks = TotalNumberOfBlocks-TotalNumberOfDisabledBlocks;
			System.out.println("Disabled="+TotalNumberOfDisabledBlocks+ "&" + "Total=" +TotalNumberOfBlocks);
			for(i=TotalNumberOfDisabledBlocks; i<TotalNumberOfBlocks; i++)
			{																								
				TotalBlocks.get(i).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(Cancel_Clock));
				driver.findElement(HH_01).click();
				driver.findElement(Clock_OK).click();																																																												
			}						
			driver.findElement(SaveTimeButton).click();
		}


	}
	
	
	/* not required as inheritng Base Class date picker
	//Date picker function		
	public void Datepicker(String date) throws InterruptedException{			
		String splitter[] = date.split("-");
		//String month_year = splitter[1];
		String SelectDate = splitter[0];
		//String Today = driver.findElement(TodaySelected).getText();
		//List<WebElement> AllDates = driver.findElements(TotalDays);	
		List<WebElement> SelectableDates = driver.findElements(ActiveDays);

		for(WebElement s:SelectableDates ){			
			if(s.getText().equals(SelectDate)){
				s.click();

			}

		}								
	}		
	//Date picker function
	 * 
	 */
	
	

	//Entedred date is not selectable in this month




	public void OpenTasksToday(String text) throws IOException, InterruptedException{
		//Actions act = new Actions(driver);													

		ClickTodayTaskNameDropdown();

		List<WebElement> TodayTasks = driver.findElements(TotalTasks);
		driver.findElement(DropdownInputBoxCommon).sendKeys(text);

		for(i=0; i<TodayTasks.size(); i++)
		{
			//System.out.println(TodayTasks.get(i).getText());

			if(TodayTasks.get(i).getText().equals(text))
			{		

				break;
			}

		}


		try{			
			if(TodayTasks.get(i).getText().equals(text)){
				System.out.println("Task is availavle under 'Today' category");
			}

			TodayTasks.get(i).click();
			driver.findElement(DropdownClose).click();									

			//*****Start making task from Not Started to In Progress then Completed********
			MakeTaskInProgress();

			TimeUnit.SECONDS.sleep(10);
			ClickTodayTaskNameDropdown();

			List<WebElement> TodayTasks_New = driver.findElements(TotalTasks);
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);

			for(i=0; i<TodayTasks_New.size(); i++)
			{
				//System.out.println(TodayTasks.get(i).getText());

				if(TodayTasks_New.get(i).getText().equals(text))
				{		

					break;
				}

			}
			TodayTasks_New.get(i).click();
			driver.findElement(DropdownClose).click();

			//create a separate function as MakeTaskComplete() and call 			
			//upload and finalize docs
			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(ViewUploadDocumentOption).click();
			//wait.until(ExpectedConditions.visibilityOfElementLocated(MyDraftsTab));
			//driver.findElement(MyDraftsTab).click();
			TimeUnit.SECONDS.sleep(5);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ChooseButton));
			driver.findElement(ChooseButton).click();			
			TimeUnit.SECONDS.sleep(3);
			//integration with AutoIT
			Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\AutoITScripts\\Upload_Pub.exe");
			//integration with AutoIT
			TimeUnit.SECONDS.sleep(5);			
			driver.findElement(UploadButton).click();
			TimeUnit.SECONDS.sleep(10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarkFinalButton));
			driver.findElement(CheckBoxUploadedFile).click();
			driver.findElement(MarkFinalButton).click();
			TimeUnit.SECONDS.sleep(4);
			driver.findElement(ClosePopUp).click();	
			TimeUnit.SECONDS.sleep(3);
			//upload and finalize docs

			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(MarkCompleteOption).click();
			//save without comments
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveWithoutCommentsButton));
			driver.findElement(SaveWithoutCommentsButton).click();
			//save without comments
			TimeUnit.SECONDS.sleep(10);
			//create a separate function as MakeTaskComplete() and call 			
			//*********Start making task from Not Started to In Progress then Completed**********************

		}
		catch(IndexOutOfBoundsException e){	
			System.out.println("Task is not availavle under 'Today' category");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);

		}	

	}						


	//Create another function here
	public void OpenTasksNext7Days(String text) throws InterruptedException, IOException{	

		ClickNext7DaysTaskNameDropdown();		

		List<WebElement> Next7DaysTasks = driver.findElements(TotalTasks);
		driver.findElement(DropdownInputBoxCommon).sendKeys(text);
		for(i=0; i<Next7DaysTasks.size(); i++)
		{				
			if(Next7DaysTasks.get(i).getText().equals(text))
			{							
				break;
			}																									
		}

		try{		
			if(Next7DaysTasks.get(i).getText().equals(text)){
				System.out.println("Task is availavle under 'Next 7 Days' category");
			}

			Next7DaysTasks.get(i).click();
			driver.findElement(DropdownClose).click();

			//*****Start making task from Not Started to In Progress then Completed********
			MakeTaskInProgress();

			TimeUnit.SECONDS.sleep(10);
			ClickNext7DaysTaskNameDropdown();

			List<WebElement> Next7DaysTasks_New = driver.findElements(TotalTasks);
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);

			for(i=0; i<Next7DaysTasks_New.size(); i++)
			{
				//System.out.println(TodayTasks.get(i).getText());

				if(Next7DaysTasks_New.get(i).getText().equals(text))
				{		

					break;
				}

			}
			Next7DaysTasks_New.get(i).click();
			driver.findElement(DropdownClose).click();

			//create a separate function as MakeTaskComplete() and call 			
			//upload and finalize docs
			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(ViewUploadDocumentOption).click();
			//wait.until(ExpectedConditions.visibilityOfElementLocated(MyDraftsTab));
			//driver.findElement(MyDraftsTab).click();
			TimeUnit.SECONDS.sleep(5);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ChooseButton));
			driver.findElement(ChooseButton).click();			
			TimeUnit.SECONDS.sleep(3);
			//integration with AutoIT
			Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\AutoITScripts\\Upload_Pub.exe");
			//integration with AutoIT
			TimeUnit.SECONDS.sleep(5);			
			driver.findElement(UploadButton).click();
			TimeUnit.SECONDS.sleep(10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarkFinalButton));
			driver.findElement(CheckBoxUploadedFile).click();
			driver.findElement(MarkFinalButton).click();
			TimeUnit.SECONDS.sleep(4);
			driver.findElement(ClosePopUp).click();	
			TimeUnit.SECONDS.sleep(3);
			//upload and finalize docs

			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(MarkCompleteOption).click();
			//save without comments
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveWithoutCommentsButton));
			driver.findElement(SaveWithoutCommentsButton).click();
			//save without comments
			TimeUnit.SECONDS.sleep(10);
			//create a separate function as MakeTaskComplete() and call 

			//*********Start making task from Not Started to In Progress then Completed**********************








		}

		catch(IndexOutOfBoundsException e){	
			System.out.println("Task is not availavle under 'Next 7 Days' category");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);
		}																		
	}

	public void OpenTasksNext14Days(String text) throws InterruptedException, IOException{

		ClickNext14DaysTaskNameDropdown();

		List<WebElement> Next14DaysTasks = driver.findElements(TotalTasks);
		driver.findElement(DropdownInputBoxCommon).sendKeys(text);

		for(i=0; i<Next14DaysTasks.size(); i++)
		{				
			if(Next14DaysTasks.get(i).getText().equals(text))
			{							
				break;
			}																									
		}
		try{		
			if(Next14DaysTasks.get(i).getText().equals(text)){
				System.out.println("Task is availavle under 'Next 14 Days' category");
			}

			Next14DaysTasks.get(i).click();
			driver.findElement(DropdownClose).click();




			//*****Start making task from Not Started to In Progress then Completed********
			MakeTaskInProgress();

			TimeUnit.SECONDS.sleep(10);
			ClickNext7DaysTaskNameDropdown();

			List<WebElement> Next14DaysTasks_New = driver.findElements(TotalTasks);
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);

			for(i=0; i<Next14DaysTasks_New.size(); i++)
			{
				//System.out.println(TodayTasks.get(i).getText());

				if(Next14DaysTasks_New.get(i).getText().equals(text))
				{		

					break;
				}

			}
			Next14DaysTasks_New.get(i).click();
			driver.findElement(DropdownClose).click();

			//create a separate function as MakeTaskComplete() and call 			
			//upload and finalize docs
			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(ViewUploadDocumentOption).click();
			//wait.until(ExpectedConditions.visibilityOfElementLocated(MyDraftsTab));
			//driver.findElement(MyDraftsTab).click();
			TimeUnit.SECONDS.sleep(5);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ChooseButton));
			driver.findElement(ChooseButton).click();			
			TimeUnit.SECONDS.sleep(3);
			//integration with AutoIT
			Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\AutoITScripts\\Upload_Pub.exe");
			//integration with AutoIT
			TimeUnit.SECONDS.sleep(5);			
			driver.findElement(UploadButton).click();
			TimeUnit.SECONDS.sleep(10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarkFinalButton));
			driver.findElement(CheckBoxUploadedFile).click();
			driver.findElement(MarkFinalButton).click();
			TimeUnit.SECONDS.sleep(4);
			driver.findElement(ClosePopUp).click();	
			TimeUnit.SECONDS.sleep(3);
			//upload and finalize docs

			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(MarkCompleteOption).click();
			//save without comments
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveWithoutCommentsButton));
			driver.findElement(SaveWithoutCommentsButton).click();
			//save without comments
			TimeUnit.SECONDS.sleep(10);
			//create a separate function as MakeTaskComplete() and call 

			//*********Start making task from Not Started to In Progress then Completed**********************





		}


		catch(IndexOutOfBoundsException e){	
			System.out.println("Task is not availavle under 'Next 14 Days' category");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);
		}			

	}
	public void OpenTasksPast7Days(String text) throws InterruptedException, IOException{

		ClickPast7DaysTaskNameDropdown();

		List<WebElement> Past7DaysTasks = driver.findElements(TotalTasks);
		driver.findElement(DropdownInputBoxCommon).sendKeys(text);

		for(i=0; i<Past7DaysTasks.size(); i++)
		{				
			if(Past7DaysTasks.get(i).getText().equals(text))
			{							
				break;
			}																									
		}

		try{		
			if(Past7DaysTasks.get(i).getText().equals(text)){
				System.out.println("Task is availavle under 'Past 7 days' category");
			}

			Past7DaysTasks.get(i).click();
			driver.findElement(DropdownClose).click();




			//*****Start making task from Not Started to In Progress then Completed********
			MakeTaskInProgress();

			TimeUnit.SECONDS.sleep(10);
			ClickPast7DaysTaskNameDropdown();

			List<WebElement> Past7DaysTasks_New = driver.findElements(TotalTasks);
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);

			for(i=0; i<Past7DaysTasks_New.size(); i++)
			{
				//System.out.println(TodayTasks.get(i).getText());

				if(Past7DaysTasks_New.get(i).getText().equals(text))
				{		

					break;
				}

			}
			Past7DaysTasks_New.get(i).click();
			driver.findElement(DropdownClose).click();

			//create a separate function as MakeTaskComplete() and call 			
			//upload and finalize docs
			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(ViewUploadDocumentOption).click();
			//wait.until(ExpectedConditions.visibilityOfElementLocated(MyDraftsTab));
			//driver.findElement(MyDraftsTab).click();
			TimeUnit.SECONDS.sleep(5);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ChooseButton));
			driver.findElement(ChooseButton).click();			
			TimeUnit.SECONDS.sleep(3);
			//integration with AutoIT
			Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\AutoITScripts\\Upload_Pub.exe");
			//integration with AutoIT
			TimeUnit.SECONDS.sleep(5);			
			driver.findElement(UploadButton).click();
			TimeUnit.SECONDS.sleep(10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarkFinalButton));
			driver.findElement(CheckBoxUploadedFile).click();
			driver.findElement(MarkFinalButton).click();
			TimeUnit.SECONDS.sleep(4);
			driver.findElement(ClosePopUp).click();	
			TimeUnit.SECONDS.sleep(3);
			//upload and finalize docs

			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(MarkCompleteOption).click();
			//save without comments
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveWithoutCommentsButton));
			driver.findElement(SaveWithoutCommentsButton).click();
			//save without comments
			TimeUnit.SECONDS.sleep(10);
			//create a separate function as MakeTaskComplete() and call 

			//*********Start making task from Not Started to In Progress then Completed**********************





		}


		catch(IndexOutOfBoundsException e){	
			System.out.println("Task is not availavle under 'Past 7 days' category");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);
		}	

	}
	public void OpenTasksPast14Days(String text) throws InterruptedException, IOException{

		ClickPast14DaysTaskNameDropdown();

		List<WebElement> Past14DaysTasks = driver.findElements(TotalTasks);
		driver.findElement(DropdownInputBoxCommon).sendKeys(text);

		for(i=0; i<Past14DaysTasks.size(); i++)
		{				
			if(Past14DaysTasks.get(i).getText().equals(text))
			{							
				break;
			}																									
		}

		try{		
			if(Past14DaysTasks.get(i).getText().equals(text)){
				System.out.println("Task is availavle under 'Past 14 days' category");
			}

			Past14DaysTasks.get(i).click();
			driver.findElement(DropdownClose).click();




			//*****Start making task from Not Started to In Progress then Completed********
			MakeTaskInProgress();

			TimeUnit.SECONDS.sleep(10);
			ClickPast14DaysTaskNameDropdown();

			List<WebElement> Past14DaysTasks_New = driver.findElements(TotalTasks);
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);

			for(i=0; i<Past14DaysTasks_New.size(); i++)
			{
				//System.out.println(TodayTasks.get(i).getText());

				if(Past14DaysTasks_New.get(i).getText().equals(text))
				{		

					break;
				}

			}
			Past14DaysTasks_New.get(i).click();
			driver.findElement(DropdownClose).click();

			//create a separate function as MakeTaskComplete() and call 			
			//upload and finalize docs
			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(ViewUploadDocumentOption).click();
			//wait.until(ExpectedConditions.visibilityOfElementLocated(MyDraftsTab));
			//driver.findElement(MyDraftsTab).click();
			TimeUnit.SECONDS.sleep(5);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ChooseButton));
			driver.findElement(ChooseButton).click();			
			TimeUnit.SECONDS.sleep(3);
			//integration with AutoIT
			Runtime.getRuntime().exec("C:\\Users\\praveen.amancha\\Desktop\\AutoITScripts\\Upload_Pub.exe");
			//integration with AutoIT
			TimeUnit.SECONDS.sleep(5);			
			driver.findElement(UploadButton).click();
			TimeUnit.SECONDS.sleep(10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarkFinalButton));
			driver.findElement(CheckBoxUploadedFile).click();
			driver.findElement(MarkFinalButton).click();
			TimeUnit.SECONDS.sleep(4);
			driver.findElement(ClosePopUp).click();	
			TimeUnit.SECONDS.sleep(3);
			//upload and finalize docs

			TimeUnit.SECONDS.sleep(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
			driver.findElement(pMenu).click();
			driver.findElement(MarkCompleteOption).click();
			//save without comments
			wait.until(ExpectedConditions.visibilityOfElementLocated(SaveWithoutCommentsButton));
			driver.findElement(SaveWithoutCommentsButton).click();
			//save without comments
			TimeUnit.SECONDS.sleep(10);
			//create a separate function as MakeTaskComplete() and call 

			//*********Start making task from Not Started to In Progress then Completed**********************






		}


		catch(IndexOutOfBoundsException e){	
			System.out.println("Task is not availavle under 'Past 14 days' category");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);
		}	


	}

	public void FullDayLeave(String DateFrom, String DateTo) throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
		driver.findElement(AddTasksButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveOption));
		driver.findElement(LeaveOption).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(StartDate).click();
		ObjectsOfBaseClass.Datepicker(DateFrom);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(EndDate).click();
		ObjectsOfBaseClass.Datepicker(DateTo);
		//TimeUnit.SECONDS.sleep(5);
		//wait.until(ExpectedConditions.elementToBeClickable(CommentsBox));
		driver.findElement(CommentsBox).sendKeys("Test_FullDayComments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SaveButton).click();			
	}
	
	public void HalfDayLeave(String DateFrom, String DateTo) throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
		driver.findElement(AddTasksButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveOption));
		driver.findElement(LeaveOption).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(StartDate).click();
		ObjectsOfBaseClass.Datepicker(DateFrom);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(EndDate).click();
		ObjectsOfBaseClass.Datepicker(DateTo);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(SimpleCheckBox).click();
		//wait.until(ExpectedConditions.elementToBeClickable(CommentsBox));
		driver.findElement(CommentsBox).sendKeys("Test_HalfDayComments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SaveButton).click();			
	}

	public void ClientMeetingTraining(String ClientName) throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddTasksButton).click();
		driver.findElement(ClientMeetingOrTrainingOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientNameDropdown));
		driver.findElement(ClientNameDropdown).click();			
		//List<WebElement> ClientList = driver.findElements(TotalClientNames);
		//***TotalClientName arrey becomes single element after sending matched data
		driver.findElement(DropdownInputBoxClientName).sendKeys(ClientName);
		//***TotalClientName arrey becomes single element after sending matched data

		/*
			for(j=0; j<ClientList.size(); j++)
			{				
				if(ClientList.get(j).getText().equals(text))
				{							
					break;
				}																									
			}
		 */
		try{		
			String ClientNameInThelist = driver.findElement(TotalClientNames).getText();
			if(ClientNameInThelist.equals(ClientName)){
				System.out.println("Client name is avaialble");
			}
			driver.findElement(TotalClientNames).click();						
		}
		catch(Exception e){	
			System.out.println("Entered client is not available");
			driver.findElement(NoResultsFound).click();
			TimeUnit.SECONDS.sleep(2);				
		}	

		driver.findElement(Date).click();
		ObjectsOfBaseClass.Datepicker("24-Apr 2020");
		TimeUnit.SECONDS.sleep(2);

		try{
			if(driver.findElement(DatepickerTitle).isDisplayed()){
				System.out.println("You can't select this date as Client Meeting / TRaining date");
				//To hide date picker
				driver.findElement(DateHeading).click();
				//To hide date picker
				TimeUnit.SECONDS.sleep(1);
			}
		}
		catch(Exception e){
			System.out.println("Client Meeting /Trainig date accepted");

		}

		driver.findElement(StartTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_08).click();
		driver.findElement(MM_15).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EndTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_09).click();
		driver.findElement(MM_30).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsBox).sendKeys("Test_Comments of Client Meetig / Training");			
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SaveButton).click();

	}



	public void InternalMeeting() throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddTasksButton).click();
		driver.findElement(InternalMeetingOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Date));
		driver.findElement(Date).click();

		ObjectsOfBaseClass.Datepicker("27-Apr 2020");
		TimeUnit.SECONDS.sleep(2);

		try{
			if(driver.findElement(DatepickerTitle).isDisplayed()){
				System.out.println("You can't select this date as Internal Meeting date");
				//To hide date picker
				driver.findElement(DateHeading).click();
				//To hide date picker
				TimeUnit.SECONDS.sleep(1);
			}
		}
		catch(Exception e){
			System.out.println("Internal Meeting date accepted");

		}
		driver.findElement(StartTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_08).click();
		driver.findElement(MM_15).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EndTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_09).click();
		driver.findElement(MM_30).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsBox).sendKeys("Test_Comments of Internal Meeting");			
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(SaveButton).click();		

	}

	public void Training() throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddTasksButton).click();
		driver.findElement(TrainingOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Date));
		driver.findElement(Date).click();

		ObjectsOfBaseClass.Datepicker("27-Apr 2020");
		TimeUnit.SECONDS.sleep(2);

		try{
			if(driver.findElement(DatepickerTitle).isDisplayed()){
				System.out.println("You can't select this date as Training date");
				//To hide date picker
				driver.findElement(DateHeading).click();
				//To hide date picker
				TimeUnit.SECONDS.sleep(1);
			}
		}
		catch(Exception e){
			System.out.println("Training date accepted");

		}
		driver.findElement(StartTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_08).click();
		driver.findElement(MM_15).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EndTime).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_09).click();
		driver.findElement(MM_30).click();
		driver.findElement(Clock_AM).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsBox).sendKeys("Test_Comments of Training");	
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(SaveButton).click();		

	}

	public void Admin() throws InterruptedException{
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(AddTasksButton).click();
		driver.findElement(AdminOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Date));
		driver.findElement(Date).click();

		ObjectsOfBaseClass.Datepicker("22-Apr 2020");
		TimeUnit.SECONDS.sleep(2);

		try{
			if(driver.findElement(DatepickerTitle).isDisplayed()){
				System.out.println("You can't select this date as Admin date");
				//To hide date picker
				driver.findElement(DateHeading).click();
				//To hide date picker
				TimeUnit.SECONDS.sleep(1);
			}
		}
		catch(Exception e){
			System.out.println("Admin date accepted");

		}

		driver.findElement(TotalHrs).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(HH_03).click();
		driver.findElement(MM_30).click();
		driver.findElement(Clock_OK).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(CommentsBox).sendKeys("Test_Comments of Admin work");			
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(SaveButton).click();				
	}	


	public void MyProjects(){
		driver.findElement(MyProjectsTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Column_ProjectCode));
		String MyProjects_Column1=driver.findElement(Column_SNo).getText();
		if(MyProjects_Column1.contains("S.No")){
			System.out.println("Column1: "+MyProjects_Column1+" - available\n");
		}
		else{
			System.out.println("Column1: "+MyProjects_Column1+" - not available\n");
		}
		String MyProjects_Column2=driver.findElement(Column_SOWCode).getText();
		if(MyProjects_Column2.contains("Sow Code")){
			System.out.println("Column2: "+MyProjects_Column2+" - available\n");
		}
		else{
			System.out.println("Column2: "+MyProjects_Column2+" - not available\n");
		}

		String MyProjects_Column3=driver.findElement(Column_ProjectCode).getText();
		if(MyProjects_Column3.contains("Project Code")){
			System.out.println("Column3: "+MyProjects_Column3+" - available\n");
		}
		else{
			System.out.println("Column3: "+MyProjects_Column3+" - not available\n");
		}

		/* -ve scenario
			 String MyProjects_Columnx=driver.findElement(Column_DeliverableType).getText();
			 if(MyProjects_Columnx.contains("Deliverable Type")){
				 System.out.println("Columnx: "+MyProjects_Columnx+" - available\n");
			 }
			 else{
				 System.out.println("Columnx: "+MyProjects_Columnx+" - not available\n");
			 }
			 -ve scenario
		 */ 

		String MyProjects_Column4=driver.findElement(Column_ShortTitle).getText();
		if(MyProjects_Column4.contains("Short Title")){
			System.out.println("Column4: "+MyProjects_Column4+" - available\n");
		}
		else{
			System.out.println("Column4: "+MyProjects_Column4+" - not available\n");
		}

		String MyProjects_Column5=driver.findElement(Column_ClientLegalEntity).getText();
		if(MyProjects_Column5.contains("Client Legal Entity")){
			System.out.println("Column5: "+MyProjects_Column5+" - available\n");
		}
		else{
			System.out.println("Column5: "+MyProjects_Column5+" - not available\n");
		}

		String MyProjects_Column6=driver.findElement(Column_ProjectType).getText();
		if(MyProjects_Column6.contains("Project Type")){
			System.out.println("Column6: "+MyProjects_Column6+" - available\n");
		}
		else{
			System.out.println("Column6: "+MyProjects_Column6+" - not available\n");
		}

		String MyProjects_Column7=driver.findElement(Column_PrimaryResource).getText();
		if(MyProjects_Column7.contains("Primary Resource")){
			System.out.println("Column7: "+MyProjects_Column7+" - available\n");
		}
		else{
			System.out.println("Column7: "+MyProjects_Column7+" - not available\n");
		}

		String MyProjects_Column8=driver.findElement(Column_POC).getText();
		if(MyProjects_Column8.contains("POC")){
			System.out.println("Column8: "+MyProjects_Column8+" - available\n");
		}
		else{
			System.out.println("Column8: "+MyProjects_Column8+" - not available\n");
		}

		String MyProjects_Column9=driver.findElement(Column_TA).getText();
		if(MyProjects_Column9.contains("TA")){
			System.out.println("Column9: "+MyProjects_Column9+" - available\n");
		}
		else{
			System.out.println("Column9: "+MyProjects_Column9+" - not available\n");
		}

		String MyProjects_Column10=driver.findElement(Column_Molecule).getText();
		if(MyProjects_Column10.contains("Molecule")){
			System.out.println("Column10: "+MyProjects_Column10+" - available\n");
		}
		else{
			System.out.println("Column10: "+MyProjects_Column10+" - not available\n");
		}

		String MyProjects_Column11=driver.findElement(Column_Status).getText();
		if(MyProjects_Column11.contains("Status")){
			System.out.println("Column11: "+MyProjects_Column11+" - available\n");
		}
		else{
			System.out.println("Column11: "+MyProjects_Column11+" - not available\n");
		}

		driver.findElement(pMenu).click();
		String Project_Option1=driver.findElement(ViewDetailsOption).getText();
		if(Project_Option1.contains("View Details")){
			System.out.println(Project_Option1+" option is available\n");
		}
		else{
			System.out.println(Project_Option1+" option is not availabl\ne");
		}

		String Project_Option2=driver.findElement(ShowHistoryOption).getText();
		if(Project_Option2.contains("Show History")){
			System.out.println(Project_Option2+" option is available\n");
		}
		else{
			System.out.println(Project_Option2+" option is not available\n");
		}

	}	 

	public void MySOW(){
		driver.findElement(MySOWTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Column_SOWTitle));

		String MySOW_Column1=driver.findElement(Column_SNo).getText();
		if(MySOW_Column1.contains("S.No")){
			System.out.println("Column1: "+MySOW_Column1+" - available\n");
		}
		else{
			System.out.println("Column1: "+MySOW_Column1+" - not available\n");
		}

		String MySOW_Column2=driver.findElement(Column_SOWCode).getText();
		if(MySOW_Column2.contains("SOW Code")){
			System.out.println("Column2: "+MySOW_Column2+" - available\n");
		}
		else{
			System.out.println("Column2: "+MySOW_Column2+" - not available\n");
		}

		String MySOW_Column3=driver.findElement(Column_SOWTitle).getText();
		if(MySOW_Column3.contains("SOW Title")){
			System.out.println("Column3: "+MySOW_Column3+" - available\n");
		}
		else{
			System.out.println("Column3: "+MySOW_Column3+" - not available\n");
		}

		String MySOW_Column4=driver.findElement(Column_ClientLegalEntity).getText();
		if(MySOW_Column4.contains("Client Legal Entity")){
			System.out.println("Column4: "+MySOW_Column4+" - available\n");
		}
		else{
			System.out.println("Column4: "+MySOW_Column4+" - not available\n");
		}

		String MySOW_Column5=driver.findElement(Column_POC).getText();
		if(MySOW_Column5.contains("POC")){
			System.out.println("Column5: "+MySOW_Column5+" - available\n");
		}
		else{
			System.out.println("Column5: "+MySOW_Column5+" - not available\n");
		}

		String MySOW_Column6=driver.findElement(Column_Currency).getText();
		if(MySOW_Column6.contains("Currency")){
			System.out.println("Column6: "+MySOW_Column6+" - available\n");
		}
		else{
			System.out.println("Column6: "+MySOW_Column6+" - not available\n");
		}

		String MySOW_Column7=driver.findElement(Column_RevenueBudget).getText();
		if(MySOW_Column7.contains("Revenue Budget")){
			System.out.println("Column7: "+MySOW_Column7+" - available\n");
		}
		else{
			System.out.println("Column7: "+MySOW_Column7+" - not available\n");
		}

		String MySOW_Column8=driver.findElement(Column_OOPBudget).getText();
		if(MySOW_Column8.contains("OOP Budget")){
			System.out.println("Column8: "+MySOW_Column8+" - available\n");
		}
		else{
			System.out.println("Column8: "+MySOW_Column8+" - not available\n");
		}

		String MySOW_Column9=driver.findElement(Column_ModifiedBy).getText();
		if(MySOW_Column9.contains("Modified By")){
			System.out.println("Column9: "+MySOW_Column9+" - available\n");
		}
		else{
			System.out.println("Column9: "+MySOW_Column9+" - not available\n");
		}

		String MySOW_Column10=driver.findElement(Column_ModifiedDate).getText();
		if(MySOW_Column10.contains("Modified Date")){
			System.out.println("Column10: "+MySOW_Column10+" - available\n");
		}
		else{
			System.out.println("Column10: "+MySOW_Column10+" - not available\n");
		}

	}

	public void SearchProjectWithCode(String ProjectCode) throws InterruptedException{
		driver.findElement(SearchProjectsTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectCodeField));
		driver.findElement(SearchProjectCodeField).sendKeys(ProjectCode);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SearchProjectButton).click();			
	}

	public void SearchProjectWithTitle(String ProjectTitle) throws InterruptedException{
		driver.findElement(SearchProjectsTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectTitleField));
		driver.findElement(SearchProjectTitleField).sendKeys(ProjectTitle);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SearchProjectButton).click();	
	}

	public void FTETask(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(ManageFTEIcon));
		driver.findElement(ManageFTEIcon).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(TaskCreateButton));

	}

	public void AddTimeThroughTimeBooking(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(TimeBooking));
		driver.findElement(TimeBooking).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SaveButton));
		driver.findElement(SearchFieldTimeBooking).sendKeys(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		List<WebElement> ActiveTBBlocks = driver.findElements(TimeBlocks_TimeBooking);
		for(int k=0; k<ActiveTBBlocks.size(); k++){
			ActiveTBBlocks.get(k).click();
			TimeUnit.SECONDS.sleep(1);
			driver.findElement(HH_01).click();
			TimeUnit.SECONDS.sleep(1);
			driver.findElement(MM_15).click();
			TimeUnit.SECONDS.sleep(2);
			driver.findElement(Clock_OK).click();;
			TimeUnit.SECONDS.sleep(1);

		}
		driver.findElement(SaveButton).click();
	}
	
	public void DeleteHalfDay(String date) throws InterruptedException, ParseException {
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
//		String date = "Nov 26,2020";

//		List<WebElement>  columns = driver.findElements(By.xpath("//div[@class='fc-view-container']//th/span"));
		WebElement Day = driver.findElement(By.xpath("//button[contains(@class,'fc-timeGridDay-button')]"));
		Day.click();
		WebElement PrevButton = driver.findElement(By.xpath("//button[@aria-label='prev']"));
		WebElement NextButton = driver.findElement(By.xpath("//button[@aria-label='next']"));
		WebElement CurrentDate = driver.findElement(By.xpath("//div[@class='fc-left']/h2"));
		Boolean checkDate = true;
		

		while(checkDate) {
			SimpleDateFormat sdf = new SimpleDateFormat("MMM-dd ,yyyy");
	        Date date1 = sdf.parse(date);
	        Date date2 = sdf.parse(CurrentDate.getText());
			if(date2.compareTo(date1) == 0) {
				//Equal
				checkDate = false;
			   List<WebElement>  row = driver.findElements(By.xpath("//td[@class='fc-event-container']"));
		       System.out.println("Rows Data : " +row);
				System.out.println("Elements:-" +driver.findElement(AppliedHalfDayLeaveElement));
				driver.findElement(AppliedHalfDayLeaveElement).click();
				TimeUnit.SECONDS.sleep(3);
				driver.findElement(YesButton).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveDelete_ValPoint));
				break;
			} else if(date2.compareTo(date1) > 0) {
				checkDate = true;
				NextButton.click();
			} else if(date2.compareTo(date1) < 0 ) {
				checkDate = true;
				PrevButton.click();
			}
		}
	}
	
	public void DeleteFullDay(String date) throws InterruptedException, ParseException {
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
		
		WebElement Day = driver.findElement(By.xpath("//button[contains(@class,'fc-timeGridDay-button')]"));
		Day.click();
		WebElement PrevButton = driver.findElement(By.xpath("//button[@aria-label='prev']"));
		WebElement NextButton = driver.findElement(By.xpath("//button[@aria-label='next']"));
		WebElement CurrentDate = driver.findElement(By.xpath("//div[@class='fc-left']/h2"));
		Boolean checkDate = true;
		

		while(checkDate) {
			SimpleDateFormat sdf = new SimpleDateFormat("MMM-dd ,yyyy");
	        Date date1 = sdf.parse(date);
	        Date date2 = sdf.parse(CurrentDate.getText());
			if(date2.compareTo(date1) == 0) {
				checkDate = false;
			   WebElement  row = driver.findElement(By.xpath("//td[@class='fc-event-container']"));
		       System.out.println("Rows Data : " +row);
				row.click();
				TimeUnit.SECONDS.sleep(3);
				driver.findElement(YesButton).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveDelete_ValPoint));
				break;
			} else if(date2.compareTo(date1) > 0) {
				checkDate = true;
				NextButton.click();
			} else if(date2.compareTo(date1) < 0 ) {
				checkDate = true;
				PrevButton.click();
			}
		}
		
		System.out.println("Elements:-" +driver.findElement(AppliedFullDayLeaveElement));
		driver.findElement(AppliedFullDayLeaveElement).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(YesButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveDelete_ValPoint));	
	}







}//class	








































/*
			if(TodayTasks.get(i).getText().equals(text)){
			System.out.println("Task is availavle under Today category");
			TodayTasks.get(i).click();
			driver.findElement(DropdownClose).click();





			catch(NoSuchElementException e){
			driver.findElement(Next7Daystab).click();				
			wait.until(ExpectedConditions.visibilityOfElementLocated(TaskNameDropdownNext7Days));
			driver.findElement(TaskNameDropdownNext7Days).click();	
			driver.findElement(DropdownInputBoxCommon).sendKeys(text);
			List<WebElement> Next7DaysTasks = driver.findElements(TotalTasks);
			for(int i=0; i<Next7DaysTasks.size(); i++){
				if(Next7DaysTasks.get(i).getText().equals(text)){				
					System.out.println("Task is availavle under Today category");
					act.click(Next7DaysTasks.get(i)).build().perform();	
					driver.findElement(DropdownClose).click();
					}

				}
			}

		}



		for(WebElement t:Tasks){
			System.out.println(t.getText());							
		}


		driver.findElement(TaskNameTextBox).sendKeys(text);
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskNameCheckBox));
		if(Tasks.contains(text)){
			driver.findElement(TaskNameCheckBox).click();
		}


		public void clickTaskNameDropdown(String text){
			wait.until(ExpectedConditions.visibilityOfElementLocated(TaskNameDropdown));
			driver.findElement(TaskNameDropdown).click();
			driver.findElement(TaskNameTextBox).sendKeys(text);
			driver.findElement(TaskNameCheckBox).click();
		}

 */

