package allModulesPkg;

import java.io.IOException;

import org.testng.annotations.Test;

public class FD_TestClass {
	Login ObjectsOfLoginClass = new Login();
	FD_ObjectClass ObjectsOfFDObjectClass = new FD_ObjectClass();
	BaseClass ObjectsOgBaseClass = new BaseClass();			
	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Apr");	
	}
	@Test
	public void FDNavigation() throws InterruptedException{
		ObjectsOfFDObjectClass.Navigation();
		
	}
	@Test
	public void SwitchToFDPage() throws InterruptedException{
		ObjectsOfFDObjectClass.SwitchTab();
	}
	
	@Test(priority = 2, enabled = false)
	public void SearchProjectDeliverable() throws InterruptedException{
		ObjectsOfFDObjectClass.SearchProjectDeliverableTab("PRA08-ABS-201609");
	}
	
	@Test(priority = 2, enabled = false)
	public void ConfirmDeliverableLineitem() throws InterruptedException{
		ObjectsOfFDObjectClass.ConfirmLineitemDel();
	}
	
	@Test(priority = 2, enabled = false)
	public void SearchProjectHourly() throws InterruptedException{
		ObjectsOfFDObjectClass.SearchProjectHourlyTab("PRA08-ORP-201161");
		
	}
	
	@Test(priority = 2, enabled = false)
	public void EditHourlyLineitem() throws InterruptedException{
		ObjectsOfFDObjectClass.EditHourlyInvoice("PRA08-ORP-201161", "5.5", "10");
	}
	
	@Test(priority = 2, enabled = false)
	public void ConfirmHourlyLineitem() throws InterruptedException{
		ObjectsOfFDObjectClass.ConfirmLineitemHourly("19-May 2020");
		
	}
	
	@Test(priority = 3, enabled = false)
	public void SelectDelSingleLineitem() throws InterruptedException{
		ObjectsOfFDObjectClass.SingleLineitemProforma("Test_PO4_INR -- Test_Name_INR", "PRA08-ABS-201609");
	}
	
	@Test(priority = 4, enabled = false)
	public void USTemplate() throws InterruptedException{
		ObjectsOfFDObjectClass.SelectTemplate("US");		
	}
	
	@Test(priority = 4, enabled = false)
	public void IndiaTemplate() throws InterruptedException{
		ObjectsOfFDObjectClass.SelectTemplate("India");		
	}
	
	@Test(priority = 4, enabled = false)
	public void JapanTemplate() throws InterruptedException{
		ObjectsOfFDObjectClass.SelectTemplate("Japan");			
	}
	
	@Test(priority = 4, enabled = false)
	public void KoreaTemplate() throws InterruptedException{
		ObjectsOfFDObjectClass.SelectTemplate("Korea");	
	}
	
	@Test(priority = 5, enabled = false)
	public void AddressTypePOC() throws InterruptedException{
		ObjectsOfFDObjectClass.AddressType("POC");
	}
	
	@Test(priority = 5, enabled = false)
	public void AddressTypeClient() throws InterruptedException{
		ObjectsOfFDObjectClass.AddressType("Client");
	}
	
	@Test(priority = 6, enabled = false)
	public void DateSelection() throws InterruptedException{
		ObjectsOfFDObjectClass.DateSelection("15-May 2020");
	}
	
	@Test(priority = 7, enabled = false)
	public void GenerateProforma() throws InterruptedException{
		ObjectsOfFDObjectClass.AddProforma();		
	}
	
	@Test(priority = 8, enabled = false)
	public void GenerateInvoice() throws InterruptedException{
		ObjectsOfFDObjectClass.Generate("PRA08-PRF-0520-0083", "19-May 2020");
		
	}
	
	@Test(priority = 9, enabled = false)
	public void MakePaidInvoice() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.PaymentResolved("PRA08-0520-0051");
	}
	
	@Test(priority = 10, enabled = false)
	public void OOPCreditCardBillable() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.CreditCardBillableFlow();
	}
		
	@Test(priority = 10, enabled = false)
	public void OOPCreditCardNonBillable() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.CreditCardNonBillableFlow();
	}
	
	@Test(priority = 10, enabled = false)
	public void INVpaymentBillable() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.InvoicePaymentBillableFlow();
	}
	
	
	@Test(priority = 10, enabled = true)
	public void INVpaymentNonBillable() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.InvoicePaymentNonBillableFlow();
	}	
	
	
	@Test(priority = 11, enabled = false)
	public void ApproveOOP_Option1() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.ApproveExpenseThroughPmenu("PRA08-ABS-201610");		
	}
	
	@Test(priority = 11, enabled = true)
	public void ApproveOOP_Option2() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.ApproveExpenseThroughButton("PRA08-ABS-201610");		
	}
	
	@Test(priority = 12, enabled = false)
	public void ApproveOOPCC() throws InterruptedException, IOException{	
		ObjectsOfFDObjectClass.ApproveCCExpense();
	}

	
	@Test(priority = 12, enabled = true)
	public void ApproveOOPINVPayment() throws InterruptedException, IOException{	
		ObjectsOfFDObjectClass.ApproveINVPaymentExpense();
	}	
	
	
	@Test(priority = 13, enabled = false)
	public void ScheduleBillableOOP() throws InterruptedException{
		ObjectsOfFDObjectClass.ScheduleOOP("PRA08-ABS-201610", "Test_PO2_INR -- Test_PO2_INR");
	}
				
	
	@Test(priority = 14, enabled = true)
	public void MarkAsPaymentApprovedNonBINV() throws InterruptedException, IOException{
		ObjectsOfFDObjectClass.MarkAsPayment("PRA08-ABS-201610");
		
	}	
}
