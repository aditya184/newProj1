package allModulesPkg;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LeaveCalendar_ObjectClass extends Login {
	BaseClass ObjectsOfBaseClass = new BaseClass();		
	MyDashboard_TestClass ObjectOfMyDashboardTestClass = new MyDashboard_TestClass();
	
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By LeaveCalendarLink = By.xpath("//a[text()='Leave Calendar']");
	By AppliedLeaveSlots = By.xpath("//*[@class='fc-event-container']");
	By AppliedFullDayLeaveSlots = By.xpath("//td[@class='fc-event-container' and @colspan]|//a[@style='background-color:#e60000']");
	By AppliedHalfDayLeaveSlots = By.xpath("//td[@class='fc-event-container']//a[@style='background-color:#808080']");
	By PrevArrow = By.xpath("//button[contains(@class,'fc-prev-button')]/span");
	By NextArrow = By.xpath("//button[contains(@class,'fc-next-button')]/span");
	By Current = By.xpath("//button[contains(@class,'fc-today-button')]");
	By Month = By.xpath("//button[contains(@class,'fc-dayGridMonth-button')]");
	By Week = By.xpath("//button[contains(@class,'fc-timeGridWeek-button')]");
	By LeaveHeader = By.xpath("//th[contains(@class,\"fc-widget-header\")]//span");

	By PageView = By.xpath("//p-fullcalendar");
	
	
	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(LeaveCalendarLink).click();
	}
	
	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	public void LeaveCalendarPageElements() throws InterruptedException{
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(PageView));
		wait.until(ExpectedConditions.visibilityOfElementLocated(PrevArrow));
		driver.findElement(PrevArrow).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Current));
		if(driver.findElement(Current).isEnabled() == true) {
			driver.findElement(Current).click();
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(NextArrow));
		driver.findElement(NextArrow).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Month));
		driver.findElement(Month).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Week));
		driver.findElement(Week).click();
	}
	
	public void TotalLeaves() throws InterruptedException{
		TimeUnit.SECONDS.sleep(30);
		List<WebElement> TotalBoxes = driver.findElements(AppliedLeaveSlots);
		int LeaveBoxes = TotalBoxes.size();
	//	System.out.println("LeaveBoxes: "+LeaveBoxes);
		int SeqValue = 0;
		for(int i=0; i<LeaveBoxes; i++){		
		String BackToBackLeaves = TotalBoxes.get(i).getAttribute("colspan");
		try{
		int SequencialLeaves = Integer.parseInt(BackToBackLeaves)-1;
		SeqValue =SeqValue+SequencialLeaves;		
		}
		catch(NumberFormatException e){
			
		}
			
		}		
	//	System.out.println("Value: "+Value);
		
		int TotalLeavesApplied = LeaveBoxes+SeqValue;		
		System.out.println("TotalLeaves: "+ TotalLeavesApplied);
		
	}


	public void FullDaylLeaves() throws InterruptedException{
		TimeUnit.SECONDS.sleep(30);
		List<WebElement> TotalBoxes = driver.findElements(AppliedFullDayLeaveSlots);
		int LeaveBoxes = TotalBoxes.size();
	//	System.out.println("LeaveBoxes: "+LeaveBoxes);
		int SeqValue = 0;
		for(int i=0; i<LeaveBoxes; i++){		
		String BackToBackLeaves = TotalBoxes.get(i).getAttribute("colspan");
		try{
		int SequencialLeaves = Integer.parseInt(BackToBackLeaves)-2;
		SeqValue =SeqValue+SequencialLeaves;		
		}
		catch(NumberFormatException e){
			
		}
			
		}		
	//	System.out.println("Value: "+Value);
		
		int TotalFullDayLeavesApplied = LeaveBoxes+SeqValue;		
		System.out.println("TotalFullDayLeaves: "+ TotalFullDayLeavesApplied);
		
	}

	
	public void HalfDaylLeaves() throws InterruptedException{
		TimeUnit.SECONDS.sleep(30);
		List<WebElement> TotalBoxes = driver.findElements(AppliedHalfDayLeaveSlots);
		int LeaveBoxes = TotalBoxes.size();
	//	System.out.println("LeaveBoxes: "+LeaveBoxes);
		int SeqValue = 0;
		for(int i=0; i<LeaveBoxes; i++){		
		String BackToBackLeaves = TotalBoxes.get(i).getAttribute("colspan");
		try{
		int SequencialLeaves = Integer.parseInt(BackToBackLeaves)-1;
		SeqValue =SeqValue+SequencialLeaves;		
		}
		catch(NumberFormatException e){
			
		}
			
		}		
	
		//	System.out.println("Value: "+Value);
		
		int TotalHalfDayLeavesApplied = LeaveBoxes+SeqValue;		
		System.out.println("TotalHalfDayLeaves: "+ TotalHalfDayLeavesApplied);		
	}

	//This method is not required when sarted working with Test.XML file as we can directly include from class
	
	public void MyDashBoardNavigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(10);
		ObjectOfMyDashboardTestClass.MyDashBoardNavigation();
		ObjectsOfBaseClass.SwitchToChildModule();		
	}
	
	public void ApplyLeave(String leaveType,String toDate,String fromDate) throws InterruptedException{
//		ObjectOfMyDashboardTestClass.CloseOpenTasksPopUp();
		TimeUnit.SECONDS.sleep(20);
		if(leaveType == "Half Day") {
			ObjectOfMyDashboardTestClass.ApplyHalfDayLeave(toDate,fromDate);
		} else {
			ObjectOfMyDashboardTestClass.ApplyFullDayLeave(toDate,fromDate);
		}
		TimeUnit.SECONDS.sleep(5);
//		ObjectsOfBaseClass.CloseAndSwitchBackToParentModule();
//		ObjectsOfBaseClass.RefreshParentModule();
	}
	
	public void DeleteLeave(String leaveType,String date) throws InterruptedException, ParseException{
//		ObjectOfMyDashboardTestClass.CloseOpenTasksPopUp();
		TimeUnit.SECONDS.sleep(20);
		if(leaveType == "Half Day") {
			ObjectOfMyDashboardTestClass.DeleteHalfDayLeave(date);
		} else {
			ObjectOfMyDashboardTestClass.DeleteFullDayLeave(date);
		}
		TimeUnit.SECONDS.sleep(5);
//		ObjectsOfBaseClass.CloseAndSwitchBackToParentModule();
//		ObjectsOfBaseClass.RefreshParentModule();
	}
	
	public void ShowLeave(String leaveType,String date) throws InterruptedException, ParseException {		
		TimeUnit.SECONDS.sleep(10);
		WebElement Day = driver.findElement(By.xpath("//button[contains(@class,'fc-timeGridDay-button')]"));
		Day.click();
		WebElement PrevButton = driver.findElement(By.xpath("//button[@aria-label='prev']"));
		WebElement NextButton = driver.findElement(By.xpath("//button[@aria-label='next']"));
		WebElement CurrentDate = driver.findElement(By.xpath("//div[@class='fc-left']/h2"));
		String dateArr[] = date.split(", ");
		String dayMonth = dateArr[0].toString();  
		String year = dateArr[1].toString();
		Boolean checkDate = true;
		wait.until(ExpectedConditions.visibilityOfElementLocated(Week));
        
//		driver.findElement(Week).click();
//		TimeUnit.SECONDS.sleep(10);
		while(checkDate) {
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
	        Date date1 = sdf.parse(date);
	        Date date2 = sdf.parse(CurrentDate.getText());
	        
//	        System.out.println("date1 : " + sdf.format(date1));
//	        System.out.println("date2 : " + sdf.format(date2));
			if(date2.compareTo(date1) == 0) {
				//Equal
		        System.out.println("Equal");
				checkDate = false;
				wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveHeader));
				List<WebElement>  columns = driver.findElements(LeaveHeader);
		        System.out.println("No of columns : " +columns.size());
				for (int i =0;i<columns.size();i++) {
		            String[] colHeader = columns.get(i).getText().split(", ");
			        System.out.println(colHeader[1]);
			        System.out.println(colHeader[2]);
			        System.out.println(dayMonth);
			        System.out.println(year);
			        System.out.println(colHeader[1].equalsIgnoreCase(dayMonth) && colHeader[2].equalsIgnoreCase(year));
					TimeUnit.SECONDS.sleep(5);
		            if(colHeader[1].equalsIgnoreCase(dayMonth) && colHeader[2].equalsIgnoreCase(year)) {
		                int pos = i + 2;
		                By AppliedLeave = By.xpath("//*[@class='fc-content-skeleton']//td[@class='fc-event-container']/a"); //By.xpath("//*[@class='fc-content-skeleton']//td["+pos+"]//div[@class='fc-event-container']/a");
//		                try {
					        System.out.println(driver.findElement(AppliedLeave));
//		                	  if(driver.findElement(AppliedLeave).size() > 0) {
		                		wait.until(ExpectedConditions.visibilityOfElementLocated(AppliedLeave));
			                    WebElement  row = driver.findElement(AppliedLeave);
			                    System.out.println("Rows Data : " +row);
//			                    for (int j =0;j<row.size();j++) {
			                      if(leaveType.equals("Half Day")) {
			                        String HalfDayLeave = row.getAttribute("style");
				                    System.out.println(HalfDayLeave);
				                    System.out.println(HalfDayLeave.contains("background-color: rgb(214, 207, 199)"));
				                    if(HalfDayLeave.contains("background-color:#D6CFC7)")) {
			                        	System.out.println("Half day leave is Applied");
			                        } 
			                      } else {
			                    	  String FullDayLeave = row.getAttribute("style");
			                    	  System.out.println(FullDayLeave);
			                    	  System.out.println(FullDayLeave.contains("background-color: rgb(230, 0, 0)"));
			                          if(FullDayLeave.contains("background-color: rgb(230, 0, 0)")) {
			                          	System.out.println("Full day leave is Applied");
			                          }  
			                      }
//			                    }
//		                	  }
//		                	  else {
//		                		  System.out.println("HERE 1 ,Leave is Deleted / Not Applied");
//		                	  }
//		                } catch(NoSuchElementException ne) {
//		                 	System.out.println("Here 2 ,Leave is Deleted / Not Applied");
//		                }
		            }
		        }
//				break;/
			} else if(date1.compareTo(date2) > 0) {
				checkDate = true;
//	            System.out.println("Date1 is after Date2");
				NextButton.click();
			} else if(date1.compareTo(date2) < 0 ) {
				checkDate = true;
//	            System.out.println("Date1 is before Date2");
				PrevButton.click();
			}
		};
		      
	}
	
	public Boolean CheckDatesInLeave(String date) throws ParseException {
		Boolean isEqual = false;
		List<WebElement>  columns = driver.findElements(By.xpath("//div[@class='fc-view-container']//th/span"));
		for(int i=0;i<columns.size();i++) {
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
	        Date date1 = sdf.parse(date);
			SimpleDateFormat sdf1 = new SimpleDateFormat("EEE, MMM dd, yyyy");
	        Date date2 = sdf1.parse(columns.get(i).getText());
			if(date1.compareTo(date2) == 0) {
		        System.out.println("Equal"+isEqual);
		        isEqual = true;
			}
		}
		return isEqual;
	}
	
	
	public void ValidateDeletedLeave(String date) throws InterruptedException, ParseException {		
		TimeUnit.SECONDS.sleep(10);
		
		WebElement PrevButton = driver.findElement(By.xpath("//button[@aria-label='prev']"));
		WebElement NextButton = driver.findElement(By.xpath("//button[@aria-label='next']"));
		WebElement CurrentDate = driver.findElement(By.xpath("//div[@class='fc-left']/h2"));
		String dateArr[] = date.split(", ");
		String dayMonth = dateArr[0].toString();  
		String year = dateArr[1].toString();
		Boolean checkDate = true;
		wait.until(ExpectedConditions.visibilityOfElementLocated(Week));
		driver.findElement(Week).click();
		TimeUnit.SECONDS.sleep(5);
		Boolean equal = CheckDatesInLeave(date);
		checkDate = equal ? false : true;
        System.out.println(checkDate+""+equal);
		while(checkDate) {
			List<WebElement>  columns = driver.findElements(By.xpath("//div[@class='fc-view-container']//th/span"));
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
	        Date date1 = sdf.parse(date);
			SimpleDateFormat sdf1 = new SimpleDateFormat("EEE, MMM dd, yyyy");
	        Date date2 = sdf1.parse(columns.get(0).getText());
	        
	        System.out.println("date1 : " + sdf.format(date1));
	        System.out.println("date2 : " + sdf.format(date2));
			if(date1.compareTo(date2) > 0) {
				checkDate = true;
	            System.out.println("Date1 is after Date2");
				NextButton.click();
				if(CheckDatesInLeave(date)) {
					checkDate = false;
			        System.out.println("Equal");
				}
			} else if(date1.compareTo(date2) < 0 ) {
				checkDate = true;
	            System.out.println("Date1 is before Date2");
				PrevButton.click();
				if(CheckDatesInLeave(date)) {
					checkDate = false;
				}
			}
		};
		
		if(checkDate == false) {
			List<WebElement>  columns = driver.findElements(By.xpath("//div[@class='fc-view-container']//th/span"));
			for(int i=0;i<columns.size();i++) {
				SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		        Date date1 = sdf.parse(date);
				SimpleDateFormat sdf1 = new SimpleDateFormat("EEE, MMM dd, yyyy");
		        Date date2 = sdf1.parse(columns.get(i).getText());
				if(date1.compareTo(date2) == 0) {
//			        System.out.println("Equal");
			        int pos = i+1;
			        try {
			        	wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='fc-content-skeleton']//td["+pos+"]/*[@class='fc-content-col']/*[@class='fc-event-container']")));
			        	// WebElement row = driver.findElement(leave));
			        }catch(NoSuchElementException ne) {
				        System.out.println("No Leave Found");
			        }
			       break;
				}
			}
		}

	}
	
	
//	public void ValidateDeletedLeave(String leaveType,String date) throws InterruptedException, ParseException {		
//		TimeUnit.SECONDS.sleep(10);
////		WebElement Day = driver.findElement(By.xpath("//button[contains(@class,'fc-timeGridDay-button')]"));
////		Day.click();
//		WebElement PrevButton = driver.findElement(By.xpath("//button[@aria-label='prev']"));
//		WebElement NextButton = driver.findElement(By.xpath("//button[@aria-label='next']"));
//		WebElement CurrentDate = driver.findElement(By.xpath("//div[@class='fc-left']/h2"));
//		List<WebElement>  columns = driver.findElements(By.xpath("//div[@class='fc-view-container']//th/span"));
//		String dateArr[] = date.split(", ");
//		String dayMonth = dateArr[0].toString();
//		String year = dateArr[1].toString();
//		Boolean checkDate = true;
//		
//		String dateRange[] = CurrentDate.getText().split(",")[0].split("\\s+"); 
//		String Month
//		int startDate = Integer.parseInt(dateRange[1].toString());
//		int endDate = Integer.parseInt(dateRange[3].toString()); 
//		int compareDate = Integer.parseInt(dayMonth.split("\\s+")[1].toString());
//		for(int i=startDate;i<=endDate;i++) {
//			if(i == compareDate) {
//		            
//			} else if(i > compareDate) {
//				checkDate = true;
////	            System.out.println("Date1 is after Date2");
//				NextButton.click();
//			} else if(i < compareDate ) {
//				checkDate = true;
////	            System.out.println("Date1 is before Date2");
//				PrevButton.click();
//			}
//		}
//		wait.until(ExpectedConditions.visibilityOfElementLocated(Week));
//		driver.findElement(Week).click();
//		
////		TimeUnit.SECONDS.sleep(10);
//			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
//	        Date date1 = sdf.parse(date);	        
//	        Date date2 = sdf.parse(CurrentDate.getText());
//	        
////	        System.out.println("date1 : " + sdf.format(date1));
////	        System.out.println("date2 : " + sdf.format(date2));
//				//Equal
//		        System.out.println("Equal");
//				checkDate = false;
//		        System.out.println("No of columns : " +columns.size());
//				for (int i =0;i<columns.size();i++) {
//		            String[] colHeader = columns.get(i).getText().split(", ");
//			        System.out.println(colHeader[1]);
//			        System.out.println(colHeader[2]);
//			        System.out.println(dayMonth);
//			        System.out.println(year);
//			        System.out.println(colHeader[1].equalsIgnoreCase(dayMonth) && colHeader[2].equalsIgnoreCase(year));
//					TimeUnit.SECONDS.sleep(5);
//		            if(colHeader[1].equalsIgnoreCase(dayMonth) && colHeader[2].equalsIgnoreCase(year)) {
//		                int pos = i + 2;
//		                By AppliedLeave = By.xpath("//*[@class='fc-content-skeleton']//td["+pos+"]//div[@class='fc-event-container']/a");
////		                try {
//					        System.out.println(driver.findElement(AppliedLeave));
////		                	  if(driver.findElement(AppliedLeave).size() > 0) {
//		                		wait.until(ExpectedConditions.visibilityOfElementLocated(AppliedLeave));
//			                    WebElement  row = driver.findElement(AppliedLeave);
//			                    System.out.println("Rows Data : " +row);
////			                    for (int j =0;j<row.size();j++) {
//			                      if(leaveType.equals("Half Day")) {
//			                        String HalfDayLeave = row.getAttribute("style");
//				                    System.out.println(HalfDayLeave);
//				                    System.out.println(HalfDayLeave.contains("background-color: rgb(128, 128, 128)"));
//				                    if(HalfDayLeave.contains("background-color:#D6CFC7)")) {
//			                        	System.out.println("Half day leave is Applied");
//			                        } 
//			                      } else {
//			                    	  String FullDayLeave = row.getAttribute("style");
//			                    	  System.out.println(FullDayLeave);
//			                    	  System.out.println(FullDayLeave.contains("background-color: rgb(230, 0, 0)"));
//			                          if(FullDayLeave.contains("background-color: rgb(230, 0, 0)")) {
//			                          	System.out.println("Full day leave is Applied");
//			                          }  
//			                      }
////			                    }
////		                	  }
////		                	  else {
////		                		  System.out.println("HERE 1 ,Leave is Deleted / Not Applied");
////		                	  }
////		                } catch(NoSuchElementException ne) {
////		                 	System.out.println("Here 2 ,Leave is Deleted / Not Applied");
////		                }
//		            }
//		        }
//		      
//	}
	
	
	public void Validation() throws InterruptedException{
		System.out.println("\nLeaves data applying a leave: ");
		TotalLeaves();
		FullDaylLeaves();
		HalfDaylLeaves();
		
		
	}
}
