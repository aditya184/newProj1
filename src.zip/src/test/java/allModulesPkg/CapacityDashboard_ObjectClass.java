package allModulesPkg;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


public class CapacityDashboard_ObjectClass extends Login {
	
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");

	By CapacityDashboardLink = By.xpath("//a[text()='Capacity Dashboard']");
	
	By DatePickerButton = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");
	By CalendarMonthYearTitle = By.xpath("//div[@class='ui-datepicker-title']");
	By CalendarMonthTitle = By.xpath("//span[contains(@class, 'ui-datepicker-month')]");
	By CalendarYearTitle = By.xpath("//span[contains(@class, 'ui-datepicker-year')]");
	By ActiveDays = By.xpath("//a[@draggable='false']");
	By CalendarLeftArrow = By.xpath("//span[@class='ui-datepicker-prev-icon pi pi-chevron-left']");
	By CalendarRightArrow = By.xpath("//span[@class='ui-datepicker-next-icon pi pi-chevron-right']");
	
	//dropdown
	By BucketDropdown = By.xpath("//p-multiselect[@formcontrolname='bucket']");
	By PracticeAreaDropdown = By.xpath("//p-multiselect[@formcontrolname='practicearea']");
	By SkillDropdown = By.xpath("//p-multiselect[@formcontrolname='skill']");
	By ReasourceDropdown = By.xpath("//p-multiselect[@formcontrolname='resources']");
	By TaskStatusDropdown = By.xpath("//p-dropdown[@formcontrolname='status']");
	By ReasourceTypeDropdown = By.xpath("//p-dropdown[@formcontrolname='resourcetype']");
	
	By CommonCheckBox = By.xpath("//div[contains(@class, 'ui-chkbox-box ui-widget ui-corner-all ui-state-default')]");
	
//	By OutsideText = By.xpath("//div[text()='Selected User Capacity']");
	By OutsideText = By.xpath("//div[@class='ui-card ui-widget ui-widget-content ui-corner-all']");

	
	By SearchButton = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-search']");
	
	By AllocatedHrsCommon = By.xpath("//td[@class='allocated']"); //TotalAllocatedHrs; TitalSpent; UnableTolocate3rdElement
	By UnallocatedHrsCommon = By.xpath("//td[@class='unallocated']"); //TotalUnallocated; Bench; UnableTolocate3rdElement
	By ClosePopUp = By.xpath("//span[@class='pi pi-times']");
	By TotalChildCheckboxFieldsInDropdown = By.xpath("//li[contains(@class,'ui-multiselect-item ui-corner-all')]");
	By TotalNonCheckboxFieldsInDropdown = By.xpath("//li[contains(@class,'ui-dropdown-item ui-corner-all')]");
	By ClearButton = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-refresh']");
	By TotalSelectedItems = By.xpath("//li[@class='ui-multiselect-item ui-corner-all ui-state-highlight']");
	By SingleDropDownItem = By.xpath("//li[@class='ui-dropdown-item ui-corner-all ui-state-highlight']");
	By CapacityTableHeader = By.xpath("//thead[@class='tableHeader']/tr/th");
	By CapacityTasksTableHeader = By.xpath("//app-capacity-tasks//tr[@class='tableHeader ng-star-inserted']//td[5]");
	By CapacityTasksRow_ValPoint = By.xpath("//tr[@class='tableBody ng-star-inserted']//td[5]//span[contains(text(),'0:0')]");
	By BlockResourceRow_ValPoint = By.xpath("//tr[@class='tableBody ng-star-inserted']//td[6]//span[text()='Active']");

	
	By BlockResourceDropdown = By.xpath("//p-dropdown[@formcontrolname='Resource']");
	By TitleInput = By.xpath("//input[@formcontrolname='Title']");
	By ExpectedTime = By.xpath("//input[@formcontrolname='ExpectedTime']");
	By StartDatePicker = By.xpath("//input[@placeholder='Select Start Date']");
	By EndDatePicker = By.xpath("//input[@placeholder='Select End Date']");
	By SaveButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Save']");

	
	public void ValidateElements() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
		driver.findElement(BucketDropdown).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PracticeAreaDropdown));
		driver.findElement(PracticeAreaDropdown).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
		driver.findElement(SkillDropdown).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
		driver.findElement(ReasourceDropdown).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskStatusDropdown));
		driver.findElement(TaskStatusDropdown).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceTypeDropdown));
		driver.findElement(ReasourceTypeDropdown).click();
	}
	
	public void VerifyValueInFilters(String filter) throws InterruptedException{
		switch(filter) {
		case "Bucket" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
			driver.findElement(BucketDropdown).click();
			List<WebElement> BucketItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);
			System.out.println(BucketItemList.size());
			if(BucketItemList.size() > 0) {
				System.out.println("All Values Available In Bucket");
			}
		break;
		case "Practice Area" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(PracticeAreaDropdown));
			driver.findElement(PracticeAreaDropdown).click();
			List<WebElement> PracticeAreaItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);
			System.out.println(PracticeAreaItemList.size());
			if(PracticeAreaItemList.size() > 0) {
				System.out.println("All Values Available In Practice Area");
			}
		break;
		case "Skill" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
			driver.findElement(SkillDropdown).click();
			List<WebElement> SkillItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);
			System.out.println(SkillItemList.size());
			if(SkillItemList.size() > 0) {
				System.out.println("All Values Available In Skill");
			}
		break;
		case "Resources" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
			driver.findElement(ReasourceDropdown).click();
			List<WebElement> ResourcesItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);
			System.out.println(ResourcesItemList.size());
			if(ResourcesItemList.size() > 0) {
				System.out.println("All Values Available In Resources");
			}
		break;
		case "Task Status" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(TaskStatusDropdown));
			driver.findElement(TaskStatusDropdown).click();
			List<WebElement> TaskStatusItemList = driver.findElements(TotalNonCheckboxFieldsInDropdown);
			System.out.println(TaskStatusItemList.size());
			if(TaskStatusItemList.size() > 0) {
				System.out.println("All Values Available In Task Status");
			}
		break;
		case "Resources Type" :
			wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceTypeDropdown));
			driver.findElement(ReasourceTypeDropdown).click();
			List<WebElement> ResourceTypeItemList = driver.findElements(TotalNonCheckboxFieldsInDropdown);
			System.out.println(ResourceTypeItemList.size());
			if(ResourceTypeItemList.size() > 0) {
				System.out.println("All Values Available In Reasource Type");
			}
		break;
		}
		
	}
	
	public void ResetFilter() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClearButton));
		driver.findElement(ClearButton).click();
	}
	
	public void ValidationPointAfterResetFilter() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
		driver.findElement(BucketDropdown).click();
		List<WebElement> BucketItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(BucketItemList.size()==0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(PracticeAreaDropdown));
		driver.findElement(PracticeAreaDropdown).click();
		List<WebElement> PracticeAreaItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(PracticeAreaItemList.size()==0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
		driver.findElement(SkillDropdown).click();
		List<WebElement> SkillItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(SkillItemList.size()==0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
		driver.findElement(ReasourceDropdown).click();
		List<WebElement> ResourcesItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(ResourcesItemList.size()==0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskStatusDropdown));
		driver.findElement(TaskStatusDropdown).click();
		WebElement TaskStatusItem = driver.findElement(SingleDropDownItem);
		System.out.println(TaskStatusItem.getText());
		Assert.assertTrue(TaskStatusItem.getText().equals("All"));
		driver.findElement(TaskStatusDropdown).click();
		TimeUnit.SECONDS.sleep(5);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceTypeDropdown));
		driver.findElement(ReasourceTypeDropdown).click();
		WebElement ResourceTypeItem = driver.findElement(SingleDropDownItem);
		System.out.println(ResourceTypeItem.getText());
		Assert.assertTrue(ResourceTypeItem.getText().equals("On Job"));
	}
	
	public void defaultFilters() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
		driver.findElement(SkillDropdown).click();
		List<WebElement> SkillItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(SkillItemList.size()>0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
		driver.findElement(ReasourceDropdown).click();
		List<WebElement> ResourcesItemList = driver.findElements(TotalSelectedItems);
		Assert.assertTrue(ResourcesItemList.size()>0);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskStatusDropdown));
		driver.findElement(TaskStatusDropdown).click();
		WebElement TaskStatusItem = driver.findElement(SingleDropDownItem);
		System.out.println(TaskStatusItem.getText());
		Assert.assertTrue(TaskStatusItem.getText().equals("All"));
		driver.findElement(TaskStatusDropdown).click();
		TimeUnit.SECONDS.sleep(5);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceTypeDropdown));
		driver.findElement(ReasourceTypeDropdown).click();
		WebElement ResourceTypeItem = driver.findElement(SingleDropDownItem);
		System.out.println(ResourceTypeItem.getText());
		Assert.assertTrue(ResourceTypeItem.getText().equals("On Job"));
	}
	
	public void BucketFilterSelection(String Bucket) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
		driver.findElement(BucketDropdown).click();
		SelectBucket(Bucket);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(BucketDropdown).click();
		List<WebElement> BucketItemList = driver.findElements(TotalSelectedItems);
		System.out.println(BucketItemList.size());
		for(int i=0;i<BucketItemList.size();i++) {
			Assert.assertTrue(BucketItemList.get(i).getText().equals(Bucket));
		}
	}
	
	public void PracticeAreaFilterSelection(String PracticeArea) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(PracticeAreaDropdown));
		driver.findElement(PracticeAreaDropdown).click();
		SelectPracticeArea(PracticeArea);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(PracticeAreaDropdown).click();
		List<WebElement> PracticeAreaItemList = driver.findElements(TotalSelectedItems);
		System.out.println(PracticeAreaItemList.size());
		for(int i=0;i<PracticeAreaItemList.size();i++) {
			Assert.assertTrue(PracticeAreaItemList.get(i).getText().equals(PracticeArea));
		}
	}
	
	public void SkillFilterSelection(String Skill) throws InterruptedException {
		ClearSkillDropdown();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
		driver.findElement(SkillDropdown).click();
		SelectSkill(Skill);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(SkillDropdown).click();
		List<WebElement> SkillItemList = driver.findElements(TotalSelectedItems);
		System.out.println(SkillItemList.size());
		for(int i=0;i<SkillItemList.size();i++) {
			Assert.assertTrue(SkillItemList.get(i).getText().equals(Skill));
		}
	}
	
	public void ResourcesFilterSelection(String Resources) throws InterruptedException {
		ClearResourceDropdown();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
		driver.findElement(ReasourceDropdown).click();
		SelectReasource(Resources);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ReasourceDropdown).click();
		List<WebElement> ResourcesItemList = driver.findElements(TotalSelectedItems);
		System.out.println(ResourcesItemList.size());
		for(int i=0;i<ResourcesItemList.size();i++) {
			Assert.assertTrue(ResourcesItemList.get(i).getText().equals(Resources));
		}
	}
	
	public void UserAssignedDefaultTask(String date) throws InterruptedException ,ElementClickInterceptedException {
		String dateArr[] = date.split(",");
		String date1 = dateArr[0];
		List<WebElement> tableHeader = driver.findElements(CapacityTableHeader);
		for(int i=0;i<tableHeader.size();i++) {
			if(tableHeader.get(i).getText().contentEquals(date1)) {
				By CapacityTableRow = By.xpath("//tr[@id='UserRowDetails']/td["+i+"]");
				WebElement row = driver.findElement(CapacityTableRow);
				System.out.println(row);
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click()", row);
			}
		}
	}
	
	public void UserAssignedDefaultTaskForMultipleLeave(String fromDate ,String toDate) throws InterruptedException , ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("d MMM,yyyy");
        Date date1 = sdf.parse(fromDate);
        Date date2 = sdf.parse(toDate);
        LinkedList list = new java.util.LinkedList();
        list.add(new Date(date1.getTime()));
 
        while(date1.compareTo(date2) < 0)
        {
            date1 = new Date(date1.getTime() + 86400000);
            list.add(new Date(date1.getTime()));
        }
        
        System.out.println("Dates:-"+list);
        
        List<WebElement> tableHeader = driver.findElements(CapacityTableHeader);
        for(int i=0; i<list.size(); i++) {
            System.out.print(sdf.format((Date)list.get(i)));
            String dateArr[] = sdf.format((Date)list.get(i)).split(",");
    		String date = dateArr[0];
    		for(int j=0;j<tableHeader.size();j++) {
    			if(tableHeader.get(j).getText().contentEquals(date)) {
    				By CapacityTableRow = By.xpath("//tr[@id='UserRowDetails']/td["+j+"]");
    				WebElement row = driver.findElement(CapacityTableRow);
    				System.out.println(row);
    				JavascriptExecutor jse = (JavascriptExecutor)driver;
    				jse.executeScript("arguments[0].click()", row);
    				TimeUnit.SECONDS.sleep(5);
    			}
    		}
        }
		
	}
	
	public void ValidateAppliedBlockResourceForMultipleLeave(String fromDate ,String toDate) throws InterruptedException , ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("d MMM,yyyy");
        Date date1 = sdf.parse(fromDate);
        Date date2 = sdf.parse(toDate);
        LinkedList list = new java.util.LinkedList();
        list.add(new Date(date1.getTime()));
 
        while(date1.compareTo(date2) < 0)
        {
            date1 = new Date(date1.getTime() + 86400000);
            list.add(new Date(date1.getTime()));
        }
        
        System.out.println("Dates:-"+list);
        
        List<WebElement> tableHeader = driver.findElements(CapacityTableHeader);
        for(int i=0; i<list.size(); i++) {
            System.out.print(sdf.format((Date)list.get(i)));
            String dateArr[] = sdf.format((Date)list.get(i)).split(",");
    		String date = dateArr[0];
    		for(int j=0;j<tableHeader.size();j++) {
    			if(tableHeader.get(j).getText().contentEquals(date)) {
    				By CapacityTableRow = By.xpath("//tr[@id='UserRowDetails']/td["+j+"]");
    				WebElement row = driver.findElement(CapacityTableRow);
    				System.out.println(row);
    				JavascriptExecutor jse = (JavascriptExecutor)driver;
    				jse.executeScript("arguments[0].click()", row);
    				TimeUnit.SECONDS.sleep(5);
    				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BlockResourceRow_ValPoint));
    			}
    		}
        }
		
	}
	
	public void ApplyBlockResource(String fromDate, String toDate) throws InterruptedException{
		selectResource("Test SP");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(TitleInput).sendKeys("Test_Block_Resource");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(StartDatePicker).click();
		ObjectsOfBaseClass.Datepicker(fromDate);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(EndDatePicker).click();
		ObjectsOfBaseClass.Datepicker(toDate);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ExpectedTime).sendKeys("5");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(SaveButton).click();
	}
	
	public void selectResource(String Resource) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(BlockResourceDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(BlockResourceDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown(Resource);	
	}
		
		
	public void DatePicker2(String date) throws InterruptedException{  //12-March 2020		
	String Months[] = {"January 2020","February 2020","March 2020", "April 2020", "May 2020", "June 2020", "July 2020", "August 2020", "September 2020", "October 2020", "November 2020", "December 2020"};
	String splitter1[] = date.split("-"); //"13-April 2020"
	String SelectDate = splitter1[0];
	String month_year = splitter1[1];
	
	int i, j, k;
	System.out.println(Months.length);
	//default month year
		String DefaultMonth = driver.findElement(CalendarMonthTitle).getText();
		String DefaltYear = driver.findElement(CalendarYearTitle).getText();
		String DefaultMonthYear=DefaultMonth+" "+DefaltYear;	
		System.out.println("default: "+DefaultMonthYear);
		for(j=0; j<Months.length; j++){
			if(Months[j].equals(DefaultMonthYear)){
				System.out.println(j);	
				break;
			}
			
		}
		//default month year
	
	
	//userenetered month year
	System.out.println(month_year);
	for(i=0; i<Months.length; i++){
		if(Months[i].equals(month_year)){			
			System.out.println(i);	
			break;
		}							
		
	}
	//userenetered month year
	
	
	
	
	System.out.println("Value of i: "+i+"\n");
	System.out.println("Value of j: "+j+"\n");
	
	if(i==j){		
		System.out.println("No need to click on < >");			
		}
	
	else if(i<j){		
		for(k=0; k<j-i; k++){
		//System.out.println("hit the < button");
		driver.findElement(CalendarLeftArrow).click();
		TimeUnit.SECONDS.sleep(2);
		}
		
		}
	
	else if(i>j){
		for(k=0; k<i-j; k++){
			//System.out.println("hit the > button");
			driver.findElement(CalendarRightArrow).click();
			TimeUnit.SECONDS.sleep(2);
			}
	}
	
	
	//select date from user entered string	
	try{
		List<WebElement> SelectableDates = driver.findElements(ActiveDays);

		for(WebElement s:SelectableDates ){			
			if(s.getText().equals(SelectDate)){
				s.click();

			}					
		}
	}

	catch(org.openqa.selenium.StaleElementReferenceException e){
		List<WebElement> SelectableDates_New = driver.findElements(ActiveDays);	
		for(WebElement t:SelectableDates_New){			
			if(t.getText().equals(SelectDate)){
				t.click();

			}					//using try catch due to stale element exception 
		}
	}

}		
	//select date from user entered string
	
	
	
	//capture the index of already selected month(current month from application
	//capture the index of user enteredd month 
	//compare these 2
	//if equal===>don't click < or >
	//if enteredmonthindex<currentmonthindex ===>click < as many number of difference value
	//if enteredmonthindex>currentmonthindex ===>click > as many number of difference value
	//System.out.println(Months[0]);
	
	
	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ClosePopUp).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CapacityDashboardLink).click();
		
	}
	
	
	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}
	
	
	
	public void SelectStartEndDates(String StartDate, String EndDate) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DatePickerButton));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DatePickerButton).click();
		DatePicker2(StartDate);
		TimeUnit.SECONDS.sleep(3);
		DatePicker2(EndDate);
		
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(OutsideText).click();
		TimeUnit.SECONDS.sleep(3);
	}
	
	public void ClearBuckerDropdown() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(BucketDropdown).click();
		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(BucketDropdown).click();
	}
	
	public void SelectBucket(String Bucket) throws InterruptedException{
		driver.findElement(BucketDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Bucket);				
	}
	
	
	public void ClearPracticeAreaDropdown() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(BucketDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PracticeAreaDropdown).click();
		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PracticeAreaDropdown).click();
	}
	
	public void SelectPracticeArea(String PracticeAre) throws InterruptedException{		
		driver.findElement(PracticeAreaDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(PracticeAre);		
	}
	
	
	public void ClearSkillDropdown() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(SkillDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SkillDropdown).click();
		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SkillDropdown).click();
	}
	
	
	public void SelectSkill(String Skill) throws InterruptedException{		
		driver.findElement(SkillDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Skill);		
	}
	
	
	public void ClearResourceDropdown() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ReasourceDropdown).click();
		
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommonCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ReasourceDropdown).click();
	}
	
	public void SelectReasource(String Resource) throws InterruptedException{	
		driver.findElement(ReasourceDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Resource);		
	}
	
	
	public void SelectTaskStatus(String TaskStatus) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskStatusDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(TaskStatusDropdown).click();				
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown(TaskStatus);		
	}	
	

	public void SelectReasourceType(String ResourceType) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ReasourceTypeDropdown));
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ReasourceTypeDropdown).click();				
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown(ResourceType);		
	}
	
	
	public void SearchAction() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SearchButton).click();		
	}
	
	
	public void TotalAllocatedHrs() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllocatedHrsCommon));
		TimeUnit.SECONDS.sleep(1);
		List<WebElement> CommonElements = driver.findElements(AllocatedHrsCommon);
		String TotalAllocatedHrs = CommonElements.get(0).getText();
		System.out.println("TotalAllocatedHrs: "+TotalAllocatedHrs);
	}
	
	public void TotalSpent() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllocatedHrsCommon));
		TimeUnit.SECONDS.sleep(1);
		List<WebElement> CommonElements = driver.findElements(AllocatedHrsCommon);
		String TotalSpent = CommonElements.get(1).getText();
		System.out.println("TotalSpentHrs: "+TotalSpent);
	}
	
	public void TotalUnallocatedHrs() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllocatedHrsCommon));
		TimeUnit.SECONDS.sleep(1);
		List<WebElement> CommonElements = driver.findElements(UnallocatedHrsCommon);
		String TotalUnAllocatedHrs = CommonElements.get(0).getText();
		System.out.println("TotalUnallocatedHrs: "+TotalUnAllocatedHrs);
	}
	
	public void TotalBenchHrs() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllocatedHrsCommon));
		TimeUnit.SECONDS.sleep(1);
		List<WebElement> CommonElements = driver.findElements(UnallocatedHrsCommon);
		String TotalBenchHrs = CommonElements.get(1).getText();
		System.out.println("TotalBenchHrs: "+TotalBenchHrs);
	}
	
	
	
	
	
}
