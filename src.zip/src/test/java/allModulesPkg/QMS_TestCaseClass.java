package allModulesPkg;

import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.internal.runners.statements.Fail;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
public class QMS_TestCaseClass extends Login {	
	QMS_TestClass ObjectsOfTestActionsClass = new QMS_TestClass();
	QMS_ObjectClass ObjectsOfQMSObjectClass = new QMS_ObjectClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	Login OjectsOfLoginClass = new Login();
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By QMSLink = By.xpath("//a[text()='QMS']");
	//All Tabs
	By RateWork = By.xpath("//span[@class='ui-dialog-title' and text()='Rate Work']");
	By AverageRating = By.xpath("//td[@class='_ngcontent-khj-c21' and text()='Average rating']");
	By RateTemplateDropdown = By.xpath("//span[@class='ui-dropdown-trigger-icon ui-clickable pi pi-chevron-down']");
	By RatingStar = By.xpath("//span[@class='ui-rating-icon']");
	By RateStar = By.xpath("//span[@class='ui-rating-icon pi pi-star-o']");	
	By RatingStarChanged = By.xpath("//p-rating[@class='ng-valid ng-touched ng-dirty']");
	By RatingStarUnChanged = By.xpath("//p-rating[@class='ng-untouched ng-pristine ng-valid']");
	By RateParameter = By.xpath("//title[@text()='Understanding of project scope']");
	By RatePopupcomments = By.xpath("//textarea[@class='ng-pristine ng-valid ui-inputtext ui-corner-all ui-state-default ui-widget ng-touched']");
	By PersonalTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Personal Feedback']");
	By ManagerViewTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Manager View']");
	By AdminViewTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Admin View']");
	By PendingFeedbackTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Pending Feedback']");
	By ClientFeedbackTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Client Feedback']");
	By CDTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Dissatisfaction']");
	By PFTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Positive']");
	By PositiveTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Positive ']");
	By DissatisfactionTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Dissatisfaction ']");
	By FeedbackForMe = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Feedback For Me ']");
	By PersonalFeedback = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Personal Feedback ']");
	By ScorecardsTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Scorecards ']");
	By SuccessMessage = By.xpath("//div[@class='ui-toast-detail' and text()='Rating updated!']");
	By AlertMessage = By.xpath("//div[@class='ui-toast-detail' and text()='alert']");
	By AverageRatingText = By.xpath("//div[@class='cd-rating']");
	By SentByColumn = By.xpath("//th[@class='ui-sortable-column ng-star-inserted' and text()='Sent By']");
	By BusinessImpactColumn = By.xpath("//th[@class='ui-sortable-column ng-star-inserted' and text()='Business Impact']");
	By AccountableColumn = By.xpath("//th[@class='ui-sortable-column ng-star-inserted' and text()='Accountable']");
	By RejectedEntry = By.xpath("//td[@class='ng-star-inserted' and text()='Rejected']");
	By ManagerViewAvgRatingQC = By.xpath("//td[@class='avgrating' and @id='QC']");
	By ManagerViewResource = By.xpath("//td[@class='hoverClick ng-star-inserted']");
	By PersonalFeedbackTable = By.xpath("//p-table[@id='scorecardTable']");
	
	//Dropdowns
	By FilterByDropdown = By.xpath("//p-dropdown[@placeholder='Select filter']");
	By YearDropdown = By.xpath("//p-dropdown[@placeholder='Select Year']");
	By QuarterDropdown = By.xpath("//p-dropdown[@placeholder='Select Quarter']");
	By TaskTypeDropdown = By.xpath("//p-dropdown[@placeholder='Select Task Type']");
	By ResourcesDropdown = By.xpath("//p-dropdown[@placeholder='Select Resource']");
	By TaskTitleDropdown = By.xpath("//p-multiselect[@defaultlabel='Task Title']");
	By TemplateDropdown = By.xpath("//p-dropdown[@placeholder='Select Template']");
	By ProjectCodeDropdown = By.xpath("//p-multiselect[@defaultlabel='Title']");
	By FilterByCDstatusDropdown = By.xpath("//p-dropdown[@placeholder='Filter by CD Status']");
	By SelectAccountableDropdown = By.xpath("//p-dropdown[@placeholder='Select Accountable']");
	By SelectSegregationDropdown = By.xpath("//p-dropdown[@placeholder='Select Segregation']");
	By SelectBusinessImpactDropdown = By.xpath("//p-dropdown[@placeholder='Select Business Impact']");
	By SelectCDCategoryDropdown = By.xpath("//p-dropdown[@placeholder='Select CD Category']");
	By SelectDeletionReasonDropdown = By.xpath("//p-dropdown[@placeholder='Select deletion reason']");
	By FilterByDateRange = By.xpath("//input[@placeholder='Filter by date range']");
	
	By pMenuOption = By.xpath("//i[@class='pi pi-ellipsis-v ng-star-inserted']");
	By AcceptOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Accept']");
	By RejectOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Reject']");
	By UpdateAndCloseCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Update and close CD']");
	By DeleteCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Delete CD']");
	By MarkAsValidCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Mark as valid CD']");
	By MarkAsInvalidCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Mark as invalid CD']");
	By RejectAndSendForCorrectionOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Reject and send for correction']");
	By ViewCommentsOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='View Comments']");
	By ManagerTreeTable = By.xpath("//tbody[@class='ui-treetable-tbody']");
	
	By DialogueSubmitButton = By.xpath("//button[@class='btn btn-light button save-rating' and text()=' Submit ']");
	By RatingStarts = By.xpath("//span[@class='star ng-star-inserted']");
	By ProvideFeebBackLink = By.xpath("//a[@class='download-worksheet td-none button']");
	By ProvideRatingLinik = By.xpath("//a[@class='hoverClick']");// By.xpath("//a[@class='download-worksheet mat-button mat-button-base']");
	By DownloadIcon = By.xpath("//i[@class='fa fa-download']");
	
	By CommentsTextBox = By.xpath("//textarea[@id='float-input' or @class='commentsText ng-untouched ng-pristine ng-valid ui-inputtext ui-corner-all ui-state-default ui-widget' or @placeholder='Comments' or @placeholder='Please enter comments']");
	By RCATextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-valid ng-touched' and @placeholder='Please enter root cause analysis details']");
	By CorrectiveActionsTextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-valid ng-touched' and @placeholder='Please enter corrective action details']");
	By PreventiveActionsTextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-untouched ng-pristine ng-valid' and @placeholder='Please enter preventive action details']");
		
	By SaveButton = By.xpath("//button[@class='button save-feedback' and text()='Save']|//button[@id='saveBtn' and text()=' Save ']");
	By SubmitButton = By.xpath("//button[@class='btn btn-light button save-rating' and text()=' Submit ']|//button[@id='closeBtn' and text()=' Submit ']");
	By DeleteCDSubmitButton = By.xpath("//button[@id='deleteBtn' and text()=' Submit ']");
	By ConfirmButton = By.xpath("//button[@id='rejectBtn' and text()='Confirm']");
	By CancelButton = By.xpath("//button[@class='btn btn-light button cancel-rating ng-star-inserted' and text()='Cancel']");
	By FeedbackCancelButton = By.xpath("//button[@class='button default-txt' and text()='Cancel']");
	@Test(enabled = false)
	public void QMS_UI_TC01() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		TimeUnit.SECONDS.sleep(10);			
		wait.until(ExpectedConditions.visibilityOfElementLocated(QMSLink));
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC02() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(4, 0, 4, 1);
//		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ExpectedConditions.visibilityOfElementLocated(RateParameter);
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC03() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
//		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ExpectedConditions.visibilityOfElementLocated(PersonalTab);
//		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC04() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(5, 0, 5, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ExpectedConditions.visibilityOfElementLocated(PersonalTab);
//		TimeUnit.SECONDS.sleep(10);		
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC05() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
//		ObjectsOfTestActionsClass.QMSNavigation();
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.AdminViewProvideFeedbackPOSTER_NW();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateWork));
		wait.until(ExpectedConditions.visibilityOfElementLocated(AverageRating));
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateTemplateDropdown));
		wait.until(ExpectedConditions.visibilityOfElementLocated(RatingStar));
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateParameter));
		wait.until(ExpectedConditions.visibilityOfElementLocated(RatePopupcomments));
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
//		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC06() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideRatingLinik));
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC07() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC08() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateTemplateDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC09() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(TemplateDropdown));
		boolean flag = false;
		String[] arrTemplates = new String[]{"CER", "PUBS", "MEDCOM"};
        List<String> list = Arrays.asList(arrTemplates);
		Select se = new Select(driver.findElement(FilterByDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
	    for(int i = 0; i < itemSize ; i++){
	            if(list.contains(l.get(i).getText())) {
	            	flag = true;
	            } else {
	            	flag = false;
	            	break;
	            }
	    }	
		if(flag == false) {
			Assert.fail(); 
		}
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(enabled = false)
	public void QMS_UI_TC10() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateParameter));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC11() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RatingStar));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC12() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.elementToBeClickable(RatingStarUnChanged));
		ObjectsOfBaseClass.CloseBrowser();
	}

	@Test(enabled = false)
	public void QMS_UI_TC13() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RatingStarUnChanged));
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC14() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateStar));
		driver.findElement(RateStar).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RatingStarChanged));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC15() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateStar));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC16() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(CommentsTextBox));		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC17() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.attributeContains(CommentsTextBox, "ng-reflect-model", "Test_Comments"));	
		TimeUnit.SECONDS.sleep(10);					
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC18() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC19() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateStar));
		driver.findElement(RateStar).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
		driver.findElement(SubmitButton).click();
		TimeUnit.SECONDS.sleep(10);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC20() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(CancelButton));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC21() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateWork));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC22() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		ExpectedConditions.visibilityOfElementLocated(AverageRating);
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC23() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		wait.until(ExpectedConditions.visibilityOfElementLocated(RateStar));
		driver.findElement(RateStar).click();
		wait.until(ExpectedConditions.textToBePresentInElementLocated(AverageRating, "1"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC24() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC25() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "Basic Template") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC26() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "Abstract Template") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC27() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "POSTER_NW") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC28() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "MANUSCRIPT_NW") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC29() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "SLIDE DECK_NW") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC30() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "EDITING") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC31() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "QC") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC32() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "REGULATORY_QC") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC33() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "MIL") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC34() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getAttribute("title") == "Abstract Template") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC35() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "MEDCOMM") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC36() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getAttribute("title") == "MEDCOMM") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC37() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "CER") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC38() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");
		Select se = new Select(driver.findElement(TemplateDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		boolean flag = false;
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getAttribute("title") == "CER") {
	            	flag = true;
	            };
	    }	
	    if(flag == true) {
	    	Assert.fail();
	    }
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC39() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ManagerViewTab));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC40() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Date Range");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 10");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 20");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 30");
		wait.until(ExpectedConditions.visibilityOfElementLocated(DownloadIcon));
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC41() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 10");
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC42() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Date Range");
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 10");
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC43() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Date Range");
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC44() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC45() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByYear1();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC46() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC47() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		driver.findElement(YearDropdown).click();
		Select select = new Select(driver.findElement(YearDropdown));
		WebElement option = select.getFirstSelectedOption();
		String SelectedText = option.getText();
		if(SelectedText != "2018") {
			Assert.fail();
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC48() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		wait.until(ExpectedConditions.elementToBeClickable(YearDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC49() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.textToBePresentInElementValue(ManagerTreeTable, "Rahul Chamle"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC50() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		Select se = new Select(driver.findElement(YearDropdown));
		List<WebElement> l = se.getOptions();
		if(l.size() != 2 ) {
			Assert.fail();
		}		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC51() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		Select se = new Select(driver.findElement(YearDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "2017") {
	            	Assert.fail();
	            };
	    }	
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC52() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		wait.until(ExpectedConditions.visibilityOfElementLocated(YearDropdown));
		driver.findElement(YearDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(QuarterDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC53() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		wait.until(ExpectedConditions.visibilityOfElementLocated(YearDropdown));
		driver.findElement(YearDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("2020");
		wait.until(ExpectedConditions.elementToBeClickable(QuarterDropdown));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC54() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Year");
		wait.until(ExpectedConditions.visibilityOfElementLocated(YearDropdown));
		driver.findElement(YearDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(QuarterDropdown));
		Select se = new Select(driver.findElement(QuarterDropdown));
		List<WebElement> l = se.getOptions();
		if(l.size() != 4 ) {
			Assert.fail();
		}		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC55() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByYear3();
		wait.until(ExpectedConditions.textToBe(ManagerViewAvgRatingQC, "3"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC56() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		boolean flag = false;
		Select se = new Select(driver.findElement(FilterByDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "Date Range") {
	            	flag = true;
	            	break;
	            };
	    }	
		if(flag == false) {
			Assert.fail(); 
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC57() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		driver.findElement(FilterByDropdown).click();
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Date Range");
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC58() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		Select select = new Select(driver.findElement(FilterByDropdown));
		WebElement option = select.getFirstSelectedOption();
		String SelectedText = option.getText();
		if(SelectedText != "Last 10") {
			Assert.fail();
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC59() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.elementToBeClickable(FilterByDropdown));
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 10");
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC60() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.elementToBeClickable(FilterByDropdown));
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Last 10");
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC61() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		Select select = new Select(driver.findElement(YearDropdown));
		WebElement option = select.getFirstSelectedOption();
		String SelectedText = option.getText();
		if(SelectedText != "Last 10") {
			Assert.fail();
		}
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC62() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC63() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByYear3();
		wait.until(ExpectedConditions.textToBe(ManagerViewResource, "Sneha Danduk"));
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC64() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByYear3();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ManagerViewAvgRatingQC));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ManagerViewAvgRatingQC).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PersonalFeedbackTable));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC65() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC66() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.FeedbackForMeDataByYear();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PersonalFeedbackTable));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC67() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.FeedbackForMeDataByQuarter();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PersonalFeedbackTable));
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC68() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.FeedbackForMeDataByDateRange();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PersonalFeedbackTable));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC69() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TemplateDropdown));
		Select se = new Select(driver.findElement(FilterByDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		if(itemSize < 1) {
			Assert.fail(); 
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC70() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ManagerViewAvgRatingQC));
		wait.until(ExpectedConditions.attributeToBe(ManagerViewAvgRatingQC, "ng-reflect-text", "Based out of 1 ratings"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	@Test(enabled = false)
	public void QMS_UI_TC71() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		driver.findElement(ProvideFeebBackLink).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CommentsTextBox));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC72() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		driver.findElement(ProvideFeebBackLink).click();
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		wait.until(ExpectedConditions.textToBe(CommentsTextBox, "Test_Comments"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC73() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		driver.findElement(ProvideFeebBackLink).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FeedbackCancelButton));
		driver.findElement(FeedbackCancelButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CommentsTextBox));
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC74() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC75() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC76() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC77() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC78() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC79() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC80() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC81() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC82() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC83() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC84() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC85() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC86() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC87() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC88() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC89() throws InterruptedException, IOException {
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	@Test(enabled = false)
	public void QMS_UI_TC98() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(5, 0, 5, 1);
		
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		driver.findElement(ProvideFeebBackLink).click();
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
		driver.findElement(SubmitButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC99() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(5, 0, 5, 1);
		
		ObjectsOfTestActionsClass.ManagerViewDataByLast10Days();
		ObjectsOfTestActionsClass.ManagerViewEnterFeedBack();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));
		driver.findElement(ProvideFeebBackLink).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitButton));
		driver.findElement(SubmitButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC100() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		ObjectsOfTestActionsClass.SwitchToQMSPage();
//		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		ObjectsOfTestActionsClass.AdminViewProvideFeedbackWrite();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC101() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.AdminViewProvideFeedbackMIL();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC102() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.AdminViewProvideFeedbackMIL();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC103() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.AdminViewProvideFeedbackMIL();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC104() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");	
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC105() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		ObjectsOfQMSObjectClass.ProvideRatingPendingFeedback("MIL");	
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC106() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfQMSObjectClass.ClientFeedbackPositiveAccept("JUN24-ANT-200151");
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC107() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfQMSObjectClass.ClientFeedbackPositiveAccept("JUN24-ANT-200151");
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC108() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.UpdateAndCloseCDwithSS();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC109() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.UpdateAndCloseCDwithSS();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AlertMessage));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC110() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackCDTab();
		wait.until(ExpectedConditions.textToBe(SentByColumn, "Sent By"));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC111() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackCDTab();
		wait.until(ExpectedConditions.textToBe(AccountableColumn, "Accountable"));
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = true)
	public void QMS_UI_TC112() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackCDTab();
		wait.until(ExpectedConditions.textToBe(BusinessImpactColumn, "Business Impact"));
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC113() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-ABS-200329");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(UpdateAndCloseCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectBusinessImpactDropdown));
		Select se = new Select(driver.findElement(SelectBusinessImpactDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		if(itemSize != 2) {
			Assert.fail(); 
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC114() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-ABS-200329");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(UpdateAndCloseCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SelectCDCategoryDropdown));
		Select se = new Select(driver.findElement(SelectCDCategoryDropdown));
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
		if(itemSize != 4) {
			Assert.fail(); 
		}
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC115() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-ABS-200329");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateAndCloseCDOption));
		wait.until(ExpectedConditions.visibilityOfElementLocated(DeleteCDOption));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC116() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOfBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-ABS-200329");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		Select se = new Select(driver.findElement(SelectDeletionReasonDropdown));
		boolean flag1 = false;
		boolean flag2 = false;
		List<WebElement> l = se.getOptions();
		int itemSize = l.size();
	    for(int i = 0; i < itemSize ; i++){
	            if(l.get(i).getText() == "Duplicate Entry") {
	            	flag1 = true;
	            	break;
	            };
	            if(l.get(i).getText() == "Incorrect CD") {
	            	flag2 = true;
	            	break;
	            };
	    }	
		if(flag1 == false || flag2 == false) {
			Assert.fail(); 
		}
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC117() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.DeleteCDReason2();
			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC118() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.DeleteCDReason2();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));	
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC119() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PositiveTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PositiveTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-COM-200255");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(pMenuOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RejectOption));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC120() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(8, 0, 8, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackPFTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC121() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(8, 0, 8, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfQMSObjectClass.ClientFeedbackPositiveReject("CLE22-COM-200255");
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));	
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC122() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(8, 0, 8, 1);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PositiveTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PositiveTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown("CLE22-COM-200255");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(pMenuOption);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(RejectOption));	
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	@Test(enabled = false)
	public void QMS_UI_TC123() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackPFTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC124() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(9, 0, 9, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AdminViewTab));
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC125() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC126() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC127() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC128() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC129() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC130() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC131() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC132() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToAdminScorecardTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC133() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToClientFeedbackCDTab();
		wait.until(ExpectedConditions.visibilityOfElementLocated(RejectedEntry));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC134() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(10, 0, 10, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.DeleteCDReason1();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMessage));
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC135() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC136() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC137() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC138() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC139() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC140() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC141() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC142() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC143() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC144() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC145() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC146() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC147() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	@Test(enabled = false)
	public void QMS_UI_TC148() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(6, 0, 6, 1);
		
		ObjectsOfTestActionsClass.SwitchToQMSPage();
		ObjectsOfTestActionsClass.SwitchToReviewerTab();
		TimeUnit.SECONDS.sleep(10);			
		
		
		
		ObjectsOfBaseClass.CloseBrowser();
	}
}