package allModulesPkg;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class QMS_ObjectClass extends Login{

	BaseClass ObjectsOgBaseClass = new BaseClass();		
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By QMSLink = By.xpath("//a[text()='QMS']");
	By ClosePopup = By.xpath("//a[@class='ng-tns-c10-5 ui-dialog-titlebar-icon ui-dialog-titlebar-close ui-corner-all ng-star-inserted']");
	
	//All Tabs
	By ManagerViewTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Manager View']");
	By AdminViewTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Admin View']");
	By PendingFeedbackTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Pending Feedback']");
	By ClientFeedbackTab = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Client Feedback']");
	By CDTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Dissatisfaction ']");
	By PFTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Positive ']");
	By PositiveTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Positive ']");
	By DissatisfactionTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Dissatisfaction ']");
	By FeedbackForMe = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Feedback For Me ']");
	By PersonalFeedback = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Personal Feedback ']");
	By ScorecardsTab = By.xpath("//div[@class='ui-menuitem-text ng-star-inserted' and text()=' Scorecards ']");
	By TotalNonCheckFieldsInDropdown = By.xpath("//li[@class='ui-dropdown-item ui-corner-all']|//li[@class='ui-dropdown-item ui-corner-all ui-state-highlight']");
	By NonSelectableDropdownInputBox = By.xpath("//input[@class='ui-dropdown-filter ui-inputtext ui-widget ui-state-default ui-corner-all']");
	//Dropdowns
	By FilterByDropdown = By.xpath("//p-dropdown[@placeholder='Select filter']");
	By YearDropdown = By.xpath("//p-dropdown[@placeholder='Select Year']");
	By QuarterDropdown = By.xpath("//p-dropdown[@placeholder='Select Quarter']");
	By TaskTypeDropdown = By.xpath("//p-dropdown[@placeholder='Select Task Type']");
	By ResourcesDropdown = By.xpath("//p-dropdown[@placeholder='Select Resource']");
	By TaskTitleDropdown = By.xpath("//p-multiselect[@defaultlabel='Task Title']");
	By TemplateDropdown = By.xpath("//p-dropdown[@placeholder='Select Template']");
	By ProjectCodeDropdown = By.xpath("//p-multiselect[@defaultlabel='Title']");
	By FilterByCDstatusDropdown = By.xpath("//p-dropdown[@placeholder='Filter by CD Status']");
	By SelectAccountableDropdown = By.xpath("//p-dropdown[@placeholder='Select Accountable']");
	By SelectSegregationDropdown = By.xpath("//p-dropdown[@placeholder='Select Segregation']");
	By SelectBusinessImpactDropdown = By.xpath("//p-dropdown[@placeholder='Select Business Impact']");
	By SelectCDCategoryDropdown = By.xpath("//p-dropdown[@placeholder='Select CD Category']");
	By SelectDeletionReasonDropdown = By.xpath("//p-dropdown[@placeholder='Select deletion reason']");
	By FilterByDateRange = By.xpath("//input[@placeholder='Filter by date range']");
	
	By pMenuOption = By.xpath("//i[@class='pi pi-ellipsis-v ng-star-inserted']");
	By AcceptOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Accept']");
	By RejectOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Reject']");
	By UpdateAndCloseCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Update and close CD']");
	By DeleteCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Delete CD']");
	By MarkAsValidCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Mark as valid CD']");
	By MarkAsInvalidCDOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Mark as invalid CD']");
	By RejectAndSendForCorrectionOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='Reject and send for correction']");
	By ViewCommentsOption = By.xpath("//a[@class='ui-menuitem-link ui-corner-all ng-star-inserted' and @title='View Comments']");
	
	By DialogueSubmitButton = By.xpath("//button[@class='btn btn-light button save-rating' and text()=' Submit ']");
	By RatingStarts = By.xpath("//span[@class='star ng-star-inserted']");
	By ProvideFeebBackLink = By.xpath("//a[@class='download-worksheet td-none button']");
	By ProvideRatingLinik = By.xpath("//a[@class='hoverClick']");// By.xpath("//a[@class='download-worksheet mat-button mat-button-base']");

	By CommentsTextBox = By.xpath("//textarea[@id='float-input' or @class='commentsText ng-untouched ng-pristine ng-valid ui-inputtext ui-corner-all ui-state-default ui-widget' or @placeholder='Comments' or @placeholder='Please enter comments']");
	By RCATextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-valid ng-touched' and @placeholder='Please enter root cause analysis details']");
	By CorrectiveActionsTextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-valid ng-touched' and @placeholder='Please enter corrective action details']");
	By PreventiveActionsTextBox = By.xpath("//textarea[@class='mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-untouched ng-pristine ng-valid' and @placeholder='Please enter preventive action details']");
		
	By SaveButton = By.xpath("//button[@class='button save-feedback' and text()='Save']|//button[@id='saveBtn' and text()=' Save ']");
	By SubmitButton = By.xpath("//button[@class='btn btn-light button save-rating' and text()=' Submit ']|//button[@id='closeBtn' and text()=' Submit ']");
	By DeleteCDSubmitButton = By.xpath("//button[@id='deleteBtn' and text()=' Submit ']");
	By ConfirmButton = By.xpath("//button[@id='rejectBtn' and text()='Confirm']");
	
	
	
	public void Navigation() throws InterruptedException{
//		TimeUnit.SECONDS.sleep(2);
//		driver.findElement(ClosePopup).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(QMSLink).click();		
	}
	
	public void SwitchTab(){
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	public void ManagerViewData(String DataRange) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ManagerViewTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ManagerViewTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(DataRange);	
		TimeUnit.SECONDS.sleep(3);	
	}

	public void FeedbackForMeData(String DataRange) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(FeedbackForMe));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(FeedbackForMe).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(DataRange);	
		TimeUnit.SECONDS.sleep(3);	
	}

	public void FeedbackForMeDateRange(String DataRange, String fromDate, String toDate) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(FeedbackForMe));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(FeedbackForMe).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(DataRange);	
		TimeUnit.SECONDS.sleep(3);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByDateRange));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByDateRange).click();
		ObjectsOgBaseClass.Datepicker(fromDate);
		ObjectsOgBaseClass.Datepicker(toDate);
		driver.findElement(FilterByDropdown).click();
	}

	
	public void SelectYear(String Year) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(YearDropdown));
		driver.findElement(YearDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Year);	
		TimeUnit.SECONDS.sleep(3);		
	}

	public void SelectQuarter(String Quarter) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(QuarterDropdown));
		driver.findElement(QuarterDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Quarter);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(QuarterDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Quarter);
		TimeUnit.SECONDS.sleep(3);
	}

	public void ManagerViewProvideFeedback() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProvideFeebBackLink));		
		List<WebElement> TotalFeebbacklinks = driver.findElements(ProvideFeebBackLink);
		List<WebElement> TotalComentBoxes = driver.findElements(CommentsTextBox);
		List<WebElement> TotalSaveButtons = driver.findElements(SaveButton);						
		for(int i=0; i<TotalFeebbacklinks.size(); i++){			
			TotalFeebbacklinks.get(i).click();
			TotalComentBoxes.get(i).sendKeys("Test_Comments");
			TotalSaveButtons.get(i).click();
			TimeUnit.SECONDS.sleep(2);	
		}

	}


	public void AdminViewProvideRatingWrite(){

	}

	public void AdminViewProvideRatingEdit(){

	}

	public void SwitchToReviewerTab() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PendingFeedbackTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PendingFeedbackTab).click();
	}
	
	
	public void SwitchToFeedbackForMeTab() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PersonalFeedback));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PersonalFeedback).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FeedbackForMe));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(FeedbackForMe).click();
	}
	
	public void SwitchToAdminScorecardsTab() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AdminViewTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(AdminViewTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ScorecardsTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ScorecardsTab).click();
	}
	
	public void SwitchToClientFeedbackCDTab() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CDTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(CDTab).click();
	}
	
	public void SwitchToClientFeedbackPFTab() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PFTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PFTab).click();
	}
	
	public void AdminViewProvideScorecardRating(String TaskType, String TaskTitle, String Template) throws InterruptedException{
		this.SwitchToAdminScorecardsTab();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskTypeDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(TaskTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(TaskType);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ResourcesDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Praveen Amancha");		
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskTitleDropdown));
		TimeUnit.SECONDS.sleep(2);		
		driver.findElement(TaskTitleDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(TaskTitle);
		TimeUnit.SECONDS.sleep(3);

		driver.findElement(ProvideRatingLinik).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TemplateDropdown));
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(TemplateDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Template);
		TimeUnit.SECONDS.sleep(2);	
		//rating as 5 star
		List<WebElement> TotalStars = driver.findElements(RatingStarts);
		for(int i=4; i<TotalStars.size(); i=i+5){
			TotalStars.get(i).click();
		}
		//rating as 5 star
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		//driver.findElement(SubmitButton).click();

	}
	
	public void AdminViewProvideRatingQC(String TaskType, String TaskTitle, String Template) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AdminViewTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(AdminViewTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskTypeDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(TaskTypeDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(TaskType);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ResourcesDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Praveen Amancha");		
		wait.until(ExpectedConditions.visibilityOfElementLocated(TaskTitleDropdown));
		TimeUnit.SECONDS.sleep(2);		
		driver.findElement(TaskTitleDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(TaskTitle);
		TimeUnit.SECONDS.sleep(3);

		driver.findElement(ProvideRatingLinik).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TemplateDropdown));
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(TemplateDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Template);
		TimeUnit.SECONDS.sleep(2);	
		//rating as 5 star
		List<WebElement> TotalStars = driver.findElements(RatingStarts);
		for(int i=4; i<TotalStars.size(); i=i+5){
			TotalStars.get(i).click();
		}
		//rating as 5 star
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		//driver.findElement(SubmitButton).click();

	}

	public void AdminViewProvideRatingGraphics(){

	}

	public void AdminViewProvideRatingReviewWrite(){

	}

	public void AdminViewProvideRatingReviewEdit(){

	}

	public void AdminViewProvideRatingReviewQC(){

	}

	public void AdminViewProvideRatingReviewGraphics(){

	}

	public void ProvideRatingPendingFeedback(String Template) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(PendingFeedbackTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PendingFeedbackTab).click();
		driver.findElement(ProvideRatingLinik).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(TemplateDropdown));
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(TemplateDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Template);
		TimeUnit.SECONDS.sleep(2);	
		//rating as 5 star
		List<WebElement> TotalStars = driver.findElements(RatingStarts);
		for(int i=4; i<TotalStars.size(); i=i+5){
			TotalStars.get(i).click();
		}
		//rating as 5 star
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		//driver.findElement(SubmitButton).click();
	}

	public void ClientFeedbackPositiveAccept(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PositiveTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PositiveTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AcceptOption).click();				
	}

	public void ClientFeedbackPositiveReject(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PositiveTab));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(PositiveTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeDropdown));
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(RejectOption).click();	
	}

	//On Created
	public void ClientFeedbackCDUpdateAndClose(String ProjectCode, String Accountable, String Segregation, String BusinessImpact, String CDCategory) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(UpdateAndCloseCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectAccountableDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Accountable);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectSegregationDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(Segregation);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectBusinessImpactDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(BusinessImpact);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectCDCategoryDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(CDCategory);
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(RCATextBox).sendKeys("Test_RCA");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CorrectiveActionsTextBox).sendKeys("Test_CorrectiveActions");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PreventiveActionsTextBox).sendKeys("Test_Preventive Actions");
		//driver.findElement(SaveButton).click();
		TimeUnit.SECONDS.sleep(5);
		//driver.findElement(SubmitButton).click();						
	}

	public void ClientFeedbackCDDelete(String ProjectCode, String DeleteCDReason) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Created");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DeleteCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectDeletionReasonDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown(DeleteCDReason);
		//driver.findElement(DeleteCDSubmitButton).click();
	}

	public void ClientFeedbackCDMarkAsValidCD(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Validation Pending");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(MarkAsValidCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ConfirmButton).click();
	}

	public void ClientFeedbackCDMarkAsInValidCD(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Validation Pending");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(MarkAsInvalidCDOption).click();
		TimeUnit.SECONDS.sleep(2);
		//driver.findElement(ConfirmButton).click();
	}

	public void ClientFeedbackCDRejectAndSendForCorrection(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Validation Pending");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(RejectAndSendForCorrectionOption).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		//driver.findElement(ConfirmButton).click();
	}

	public void ClientFeedbackCDViewComments(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(ClientFeedbackTab));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ClientFeedbackTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(DissatisfactionTab));		
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DissatisfactionTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FilterByCDstatusDropdown));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(FilterByCDstatusDropdown).click();
		ObjectsOgBaseClass.SelectItemFromDropdown("Validation Pending");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ProjectCodeDropdown).click();
		ObjectsOgBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenuOption).click();
		TimeUnit.SECONDS.sleep(2);
	}

	
}
