package allModulesPkg;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;


public class LeaveCalendar_TestCaseClass extends Login{
	LeaveCalendar_TestClass ObjectsOfTestActionsClass = new LeaveCalendar_TestClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	Login ObjectsOfLoginClass = new Login();

	By LeaveCalendar_ValPoint1 = By.xpath("//*[@class='title']/h6[text()='Leave Calendar']");
	By InvalidCredentials_ValPoint = By.xpath("//span[@id='errorText' and contains(text(), 'Incorrect user ID or password')]"); 
	By ApplyLeave_ValPoint1 = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'Leave created')]");
	By LeaveDelete_ValPoint = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'deleted')]");
	By MyTimelineTab = By.xpath("//span[text()='My Timeline']");

	//	To validate whether user is able to navigate to Leave Calendar module from other module
	@Test(enabled = false)
	public void TC1_NavigateToLC() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveCalendar_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	// To validate whether user is able to login to Leave Calengar module with valid userID and password
	@Test(enabled = false)
	public void TC2_ValidLoginCredentials() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveCalendar_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to login to Leave Calendar module with invalid userID and password
	@Test(enabled = false)
	public void TC3_InvalidCredentials() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.ForInvalidLoginFunctionDataDriven(4, 0, 4, 1);
		TimeUnit.SECONDS.sleep(10);			
		wait.until(ExpectedConditions.visibilityOfElementLocated(InvalidCredentials_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	// To validate landing page of Leave Calendar module
	@Test(enabled = false)
	public void TC4_ValidateLandingPage() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveCalendar_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate page view when there is no leave , half day and full day leave applied
	@Test(enabled = false)
	public void TC5_ValidateNoLeaves() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.GetTotalLeaves();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate page view when there is no leave , half day and full day leave applied 
	@Test(enabled = false)
	public void TC6_ValidateHalfDayLeaves() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.GetTotalHalfDayLeaves();
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//To validate page view when there is no leave , half day and full day leave applied
	@Test(enabled = false)
	public void TC7_ValidateFullDayLeaves() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.GetTotalFullDayLeaves();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	// To validate all the components available on Leave Calendar page
	@Test(enabled = false)
	public void TC8_ValidateElements() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.validateLeaveCalendarPageElements();
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to apply for a half day leave from MyDashboard module
	@Test(enabled = false)
	public void TC9_ApplyHalfDayLeave() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfTestActionsClass.ApplyLeaveThroughMyDashboard("Half Day","24-November 2020","24-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether applied half day leave is showing up in Leave Calendar page
	@Test(enabled = false)
	public void TC10_ShowAppliedHalfDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.MyDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
		ObjectsOfTestActionsClass.ShowAppliedLeave("Half Day","Nov 24, 2020");
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to apply for a Full day leave from MyDashboard module
	@Test(enabled = false)
	public void TC11_ApplyFullDayLeave() throws InterruptedException, IOException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);			
		ObjectsOfTestActionsClass.ApplyLeaveThroughMyDashboard("Full Day","24-November 2020","24-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	
	//	To validate whether applied Full day leave is showing up in Leave Calendar page
	@Test(enabled = false)
	public void TC12_ShowAppliedFullDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(5);			
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfTestActionsClass.MyDashboardNavigation();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(MyTimelineTab).click();
		TimeUnit.SECONDS.sleep(20);
		ObjectsOfTestActionsClass.ShowAppliedLeave("Full Day","Nov 25, 2020");
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to delete applied half day leave from My Dashboard
	@Test(enabled = false)
	public void TC13_DeleteHalfDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.DeleteLeaveThroughMyDashboard("Half Day","Nov 26, 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveDelete_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to delete applied full day leave from My Dashboard
	@Test(enabled = false)
	public void TC14_DeleteFullDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.DeleteLeaveThroughMyDashboard("Full Day","Nov 25, 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(LeaveDelete_ValPoint));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	// To validate whether deleted half day leave is showing up in Leave Calendar page
	@Test(enabled = true)
	public void TC15_DeletedHalfDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();	
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.ValidateDeletedLeave("Nov 25, 2020");
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether deleted Full day leave is showing up in Leave Calendar page
	@Test(enabled = false)
	public void TC16_DeletedFullDayLeave() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.LeaveCalendarNavigation();	
		TimeUnit.SECONDS.sleep(5);			
		ObjectsOfTestActionsClass.SwitchToLeaveCalendarPage();
		ObjectsOfTestActionsClass.ValidateDeletedLeave("Nov 25, 2020");
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to apply for a half day leave on Friday //TC-17,TC-19
	@Test(enabled = false)
	public void TC17_ValidateHalfDayOnFriday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.ApplyLeaveOnFriday("Half Day","27-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to apply for a half day leave on Monday // TC-18,TC-19
	@Test(enabled = false)
	public void TC18_ValidateHalfDayOnMonday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
    	ObjectsOfTestActionsClass.ApplyLeaveOnMonday("Half Day","23-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to apply for a half day leave on Monday // TC-18,TC-19
	@Test(enabled = false)
	public void TC19_ValidateHalfDayOnMondayAndFriday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
    	ObjectsOfTestActionsClass.ApplyLeaveOnMonday("Half Day","23-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfTestActionsClass.ApplyLeaveOnFriday("Half Day","27-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to apply for a full day leave on Friday//TC-20,TC-22
	@Test(enabled = false)
	public void TC20_ValidateFullDayOnFriday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
    	ObjectsOfTestActionsClass.ApplyLeaveOnFriday("Full Day","27-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//	To validate whether user is able to apply for a full day leave on Monday/TC-21,TC-22
	@Test(enabled = false)
	public void TC21_ValidateFullDayOnMonday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
    	ObjectsOfTestActionsClass.ApplyLeaveOnMonday("Full Day","23-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
	
//	To validate whether user is able to apply for a full day leave on Monday/TC-21,TC-22
	@Test(enabled = false)
	public void TC22_ValidateFullDayOnMondayAndFriday() throws InterruptedException, IOException, ParseException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		TimeUnit.SECONDS.sleep(10);
		ObjectsOfTestActionsClass.ApplyLeaveOnMonday("Full Day","23-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfTestActionsClass.ApplyLeaveOnFriday("Full Day","27-November 2020");
		wait.until(ExpectedConditions.visibilityOfElementLocated(ApplyLeave_ValPoint1));
		ObjectsOfBaseClass.CloseBrowser();
	}
}
