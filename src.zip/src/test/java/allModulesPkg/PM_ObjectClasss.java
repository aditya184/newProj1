package allModulesPkg;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PM_ObjectClasss extends Login{

	BaseClass ObjectsOfBaseClass = new BaseClass();		
	//PM_TestClass ObjectsOfPMTestClass = new PM_TestClass();


	int i;

	/*
	WebDriver driver=null;
	WebDriverWait wait=null;
	Actions act = null;
	 */





	By Username = By.xpath("//input[@name='loginfmt']");
	By NextButton = By.xpath("//input[@id='idSIButton9']");
	By Password = By.xpath("//input[@id='passwordInput']");
	By SignIn = By.xpath("//span[@id='submitButton']");
	By SigninPopup = By.xpath("//input[@id='idSIButton9']");


	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By PMLink = By.xpath("//a[text()='Project Management']");
	By OpenClosedCancelledNotStartedDropdown = By.xpath("//div[@class='ui-dropdown-label-container']");
	By ExportToExcelWithBudgetAndCurrencyIcon = By.xpath("//mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color']");
	By ExportToExcelIcon = By.xpath("//i[@class='fa fa-fw fa-file-excel-o']");
	By TodaysDeliveryRadioButton = By.xpath("//div[@class='floatLeft legendColor smalldot blueColor']");
	By Next5DaysRadioButton = By.xpath("//div[@class='floatLeft legendColor smalldot greenColor']");
	By OverDueRadioButton = By.xpath("//div[@class='floatLeft legendColor smalldot redColor']");

	By DownArrowButton = By.xpath("//button[@class='ui-splitbutton-menubutton ui-button ui-widget ui-state-default ui-corner-right ui-button-icon-only']");
	By AddSOWButton = By.xpath("//span[@class='ui-menuitem-text' or text()='Add SOW']");
	By UpdateSOWButton = By.xpath("//span[@class='ui-menuitem-text' or text()='Update SOW']");
	By AddProjectButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Project']");
	By CLEDropdown = By.xpath("//p-dropdown[@formcontrolname='clientLegalEntity']");
	By PracticeAreaDropdown = By.xpath("//p-multiselect[@ng-reflect-name='practiceArea']|//p-dropdown[@ng-reflect-name='practiceArea']");
	By AdditionalPOCDropdown =  By.xpath("//p-multiselect[@ng-reflect-name='pocOptional' or @ng-reflect-name='poc2']");
	By CurrencyDropdown = By.xpath("//p-dropdown[@ng-reflect-name='currency']");
	By PrimaryPOCDropdown = By.xpath("//p-dropdown[@formcontrolname='poc' or placeholder='Please Select' or @formcontrolname='primarypoc' or @placeholder='Select POC']");
	By AddressDopdown = By.xpath("//p-dropdown[@formcontrolname='address' or @placeholder='Select Address']");
	By Column_ProjectCode = By.xpath("//th[text()=' Project Code ']");
	By NonSelectableDropdownInputBox = By.xpath("//input[@class='ui-dropdown-filter ui-inputtext ui-widget ui-state-default ui-corner-all']");	
	By TotalNonCheckFieldsInDropdown = By.xpath("//li[@class='ui-dropdown-item ui-corner-all']");
	//By POCList = By.xpath("//span[@class='ng-star-inserted']");
	//CommonList== //li[@class='ui-multiselect-item ui-corner-all']
	By NoResultsFound = By.xpath("//li[text()='No results found']");
	By SOWCodeField = By.xpath("//input[@formcontrolname='sowCode']");

	By TotalChildCheckboxFieldsInDropdown = By.xpath("//li[@class='ui-multiselect-item ui-corner-all']");
	By SelectableDropdownInputBox = By.xpath("//input[@class='ui-inputtext ui-widget ui-state-default ui-corner-all' and @role='textbox']");
	By DropdownClose = By.xpath("//a[@class='ui-multiselect-close ui-corner-all']");
	By CloseIcon = By.xpath("//a[@ng-reflect-ng-class='ui-dialog-titlebar-icon ui-dia']");
	By SOWTitle = By.xpath("//textarea[@ng-reflect-name='sowTitle']");
	By SingleDatePickerButton = By.xpath("//span[@class='ui-button-icon-left ui-clickable pi pi-calendar']");
	By SOWDateButtons = By.xpath("//button[@ng-reflect-icon='pi pi-calendar' and @tabindex='-1']");	
	By ActiveDays = By.xpath("//a[@draggable='false']");
	By MonthDropdown = By.xpath("/html/body/div[3]/div/div[1]/div/select[1]|/html/body/div[6]/div/div[1]/div/select[1]");
	By YearDropdown = By.xpath("/html/body/div[3]/div/div[1]/div/select[2]|/html/body/div[6]/div/div[1]/div/select[2]");
	By ChooseFileButton = By.xpath("//input[@class='form-control ng-pristine ng-valid ng-touched']"); // not working
	By CommonFields_SOW = By.xpath("//div[@class='ui-g-4']");
	By CommentsTextBox = By.xpath("//textarea[@ng-reflect-name='comments']");
	By SOWNetBudget = By.xpath("//input[@placeholder='Net']");
	By SOWOOPBudget = By.xpath("//input[@placeholder='OOP']");
	By SOWTaxBudget = By.xpath("//input[@placeholder='Tax']");
	By CML1Dropdown = By.xpath("//p-multiselect[@formcontrolname='cm']");
	By CML2Dropdown = By.xpath("//p-dropdown[@formcontrolname='cm2']");
	By DelL1Dropdown = By.xpath("//p-multiselect[@formcontrolname='delivery']");
	By DelL2Dropdown = By.xpath("//p-dropdown[@formcontrolname='deliveryOptional']");
	By SOWOwnerDropdown = By.xpath("//p-dropdown[@formcontrolname='sowOwner']");
	By SearchField = By.xpath("//input[@placeholder='search']");
	By RadioButton = By.xpath("//div[@class='ui-radiobutton ui-widget']");
	By SelectSOWAndContinueButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Select SOW And Continue']");
	By ChooseFile_ProjectSOW = By.xpath("//input[@class='form-control']");//not working
	By CommonFields_Project = By.xpath("//div[@class='ui-grid-col-4']");
	By BilledByDropdown = By.xpath("//div[@class='ui-dropdown-label-container']");
	By ManageFinanceButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Manage Finances']");
	By AddBudgetButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Budget']");
	By AddRateButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Rate to Project']");
	//By AddBudgetButton = By.xpath("//p-button[@label='Add Budget']");
	By ProjectRevenue = By.xpath("//input[@class='ui-inputtext ui-corner-all ui-state-default ui-widget ng-untouched ng-pristine ng-valid ui-state-filled' or @ng-reflect-is-disabled='false']");
	By RateTextBox = By.xpath("//input[@ng-reflect-is-disabled='false']");
	//By POtab = By.xpath("//a[@id='ui-accordiontab-7']"); not worked
	By ProjectFinancePopupTabs = By.xpath("//a[@role='tab' and @tabindex='0']");
	By SelectPOdropdown = By.xpath("//p-dropdown[@placeholder='Select Po']");
	By AddPObutton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Po']");
	By ReserveBudgetButton = By.xpath("//i[@class='pi pi-plus-circle']");
	By ScheduleInvoiceButton = By.xpath("//i[@class='pi pi-file']");
	By InvoiceAmountInputbox = By.xpath("//input[@placeholder='Amount']");
	By SaveButton = By.xpath("//p-button[@label='Save']|//button[@label='Save']|//button[text()='Save Project']");
	By CancelButton = By.xpath("//button[@label='Cancel']"); // //span[@class='ui-button-text ui-clickable' and text()='Cancel']
	By ContinueButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Continue']");
	By SubDivisionDropdown = By.xpath("//p-dropdown[@formcontrolname='subDivision']");
	By PriorityDropdown = By.xpath("//p-dropdown[@formcontrolname='priority']");
	By MolleculeDropdown = By.xpath("//p-dropdown[@formcontrolname='molecule']//label[text()='Please Select']");
	By TADropdown = By.xpath("//p-dropdown[@formcontrolname='therapeuticArea']");
	By IndicationTextBox = By.xpath("//input[@formcontrolname='indication']");
	By PubSupportRequiredSimpleCheckBox = By.xpath("//div[@class='ui-chkbox ui-widget']");
	By ProjectTitleTextBox = By.xpath("//textarea[@formcontrolname='projectTitle']");
	By ProjectShortTitleTextBox = By.xpath("//input[@formcontrolname='shortTitle']");
	By EndUseDeliverableTextBox = By.xpath("//input[@formcontrolname='endUseDeliverable']");
	By SOWLinkTextBox = By.xpath("//input[@formcontrolname='sowBoxLink']");
	By ConJournalTextBox = By.xpath("//textarea[@formcontrolname='conference']");
	By AuthorsTextBox = By.xpath("//textarea[@formcontrolname='authors']");
	By ContinueToTimelineButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Continue To Timeline']");
	By NonStandardRadioButton = By.xpath("//input[@id='nonStandardTimeline' and (@name='timelineradio' or @type='radio')]");
	By StandardRadioButton = By.xpath("//input[@id='standardTimeline' and (@name='timelineradio' or @type='radio')]");
	By ServiceDropdown = By.xpath("//p-dropdown[@placeholder='Select Service']");
	By ResourceDropdown = By.xpath("//p-dropdown[@placeholder='Select Skill' or @placeholder='Select ResourceName']");
	By ReviewerDropdown = By.xpath("//p-dropdown[@placeholder='Select Reviewer']");
	By ProposedStartDate = By.xpath("//div[@class='col-md-4 col-xs-3 col-lg-4']//button[@ng-reflect-icon='pi pi-calendar' and @tabindex='-1']|//div[@class='col-md-2 col-xs-2 col-lg-2']//button[@ng-reflect-icon='pi pi-calendar' and @tabindex='-1']");
	By ProposedEndDate = By.xpath("//div[@class='col-md-4 col-xs-4 col-lg-4']//button[@ng-reflect-icon='pi pi-calendar' and @tabindex='-1']");
	By CapacityButton = By.xpath("//button[@id='standardTimelineCapacity']");
	By GenerateButton = By.xpath("//button[@id='standardTimelineGenerate']");
	By DeliverableTypeDropdown = By.xpath("//p-dropdown[@placeholder='Select Deliverable Type']");
	By SubTypeDropdown = By.xpath("//p-dropdown[@placeholder='Select SubType']");
	By ProjectBudgetHrTextBox = By.xpath("//input[@id='nonstandardProjectBudgetHrs']");

	By AllProjectsTab = By.xpath("//a[@ng-reflect-router-link='allProjects']");
	By AllSOWtab = By.xpath("//a[@ng-reflect-router-link='allSOW']");
	By SendToClientTab = By.xpath("//a[@ng-reflect-router-link='sendToClient']");
	By ClientReviewTab = By.xpath("//a[@ng-reflect-router-link='clientReview']");
	By PendingAllocationTab = By.xpath("//a[@ng-reflect-router-link='pendingAllocation']");
	By InActiveProjectsTab = By.xpath("//a[@ng-reflect-router-link='inActive']");
	By SOWCodeColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='SOWCode']");
	By ProjectCodeColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='ProjectCode']");
	By ShortTitleColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='ShortTitle']");
	By CLEColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='ClientLegalEntity']");
	By ProjectTypeColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='ProjectType']");
	By PrimaryResourceColumnTextBox = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='PrimaryResources']");
	By POCColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='POC']");
	By TAColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='TA']");
	By MoleculeColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='Molecule']");
	By StatusColumnDropdown = By.xpath("//th[@class='ui-fluid ng-star-inserted' and @ng-reflect-ng-switch='Status']");
	By ConfirmLineitemIcon = By.xpath("//i[@class='pi pi-check ng-star-inserted']");
	By ProjectCreationSuccessMessage = By.xpath("//div[@class='ui-toast-detail']");

	//Dialogue Buttons
	By DialogueUpdateButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Update']");
	By DialogueNetTextField = By.xpath("//input[@formcontrolname='net']");
	By DialogueOOPTextField = By.xpath("//input[@formcontrolname='oop']");
	By DialogueTaxTextField = By.xpath("//input[@formcontrolname='tax']");
	By DialogueMoveButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Move']");
	By DialogueScheduleNewINvoiceButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Schedule New Invoice']");
	
	//Dialogue Buttons

	//Project options
	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By ProjectStatusOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Status']");	
	By ProjectMiscOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Misc']");
	By ProjectFinanceOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Finance']");
	By ProjectShowHistoryOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Show History']");
	By SubOptions = By.xpath("//li[@class='ng-star-inserted ui-menuitem ui-widget ui-corner-all ui-menuitem-active']//ul[@class='ui-widget-content ui-corner-all ui-shadow ui-submenu-list']");
	By ConfirmProjectOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Confirm Project']");
	By CancelProjectOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Cancel Project']");
	By ProjectOnHoldOption = By.xpath("//span[@class='ui-menuitem-text' and text()='On Hold']");
	By ProjectOffHoldOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Off Hold']");
	By ViewProjectDetailsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View Project Details']");
	By EditProjectOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Edit Project']");
	By CommunicationsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Communications']");
	By TimelineOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Timeline']");
	By GoToAllocationOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Go to Allocation']");
	By ProjectScopeOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Project Scope']");
	By ViewCDsPFsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View CDs/PFs']");
	By ViewPubSupportOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View PubSupport']");
	By ManageFinanceOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Manage Finance']");
	By ChangeSOWOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Change SOW']");
	By ExpenseOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Expense']");
	By ProposeClosureOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Propose Closure']");

	//Project options

	//SOW options
	By ViewSOWOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View SOW']");
	By EditSOWOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Edit SOW']");
	By UpdateBudgetOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Update Budget']");
	By ViewProjectsOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View Projects']");
	By AddProjectOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Add Project']");
	By CloseSOWOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Close SOW']");
	By SOWShowHistoryOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Show History']");	
	//SOW options

	By DialogYesButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Yes']");
	By DialogNoButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='No']");

	By CSAuditButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='CS Audit']");	
	By FinanceAuditButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Finance Audit']");
	By AuditButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Audit']");	
	By AuditProjectListParentCheckBox = By.xpath("//thead[@class='ui-table-thead']//div[@class='ui-chkbox ui-widget']");
	By AuditProjectDialogParentCheckBox = By.xpath("//thead[@class='ui-table-thead']//tr[@class='ng-star-inserted']//div[@class='ui-chkbox ui-widget']");
	By AuditcommentsTextBoxes = By.xpath("//textarea[@class='ng-untouched ng-pristine ng-valid']");
	By CSAuditDropdowns = By.xpath("//select[@ng-reflect-model='Select One']");
	By ConfirmButton = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Confirm']");

	By PCancelReasonTypeDropdown = By.xpath("//div[@class='ui-dropdown-label-container']//label[text()='Please Select']");
	By PCancelReasonCommentBox = By.xpath("//*[@id='WebPartWPQ1']/div[1]/app-root/div[3]/app-projectmanagement/div[2]/div/app-all-projects/div[6]/div[2]/p-dialog/div/div[2]/div[2]/div[2]/div/textarea");

	//Radio button
	By AllRadioButton = By.xpath("//div[@class='ui-radiobutton ui-widget']");

	//Toast Messages
	By SOWorProjectToast = By.xpath("//div[@class='ui-toast-detail']");

	//Upload Buttons
	By UpdateSOWBudgetCommon = By.xpath("//div[@class='p-col-8']");
	//Upload Buttons


	/*
	//Constructor
	public PMObjectClasss(WebDriver driver, WebDriverWait wait, Actions act){
		this.driver=driver;			
		this.wait=wait;
		this.act=act;
	}
	//Constructor
	 * */

	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PMLink).click();				
	}

	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}

	//Function to select an element from dropdown having checkbox
	public void SelectCheckboxItemsFromDropdown(String text) throws InterruptedException{
		List<WebElement> CheckboxItemList = driver.findElements(TotalChildCheckboxFieldsInDropdown);						
		driver.findElement(SelectableDropdownInputBox).sendKeys(text);
		for(i=0; i<CheckboxItemList.size(); i++)
		{

			if(CheckboxItemList.get(i).getText().equals(text))
			{		

				break;
			}

		}

		try{			
			if(CheckboxItemList.get(i).getText().equals(text)){
				System.out.println("item is available in dropdown");
			}

			CheckboxItemList.get(i).click();
			driver.findElement(DropdownClose).click();	

		}
		catch(IndexOutOfBoundsException e){
			System.out.println("item is not available in dropdown or already selected");
			driver.findElement(DropdownClose).click();
			TimeUnit.SECONDS.sleep(2);			
		}
	}
	//Function to select an element from dropdown having checkbox


	//Function to select an element from dropdown having no checkbox
	public void SelectItemFromDropdown(String text) throws InterruptedException{
		driver.findElement(NonSelectableDropdownInputBox).sendKeys(text);
		try{		
			String NonCheckItemlist = driver.findElement(TotalNonCheckFieldsInDropdown).getText();
			if(NonCheckItemlist.equals(text)){
				System.out.println("Entedred element is avaialble");
			}
			driver.findElement(TotalNonCheckFieldsInDropdown).click();						
		}
		catch(Exception e){	
			System.out.println("Entered element is not available");
			driver.findElement(NoResultsFound).click();
			TimeUnit.SECONDS.sleep(2);				
		}
	}
	//Function to select an element from dropdown having no checkbox	


	//Function to select an element from dropdown having no checkbox and no search box
	public void SelectItemFromSimpleDropdown(String text) throws InterruptedException{
		List<WebElement> ItemList = driver.findElements(TotalNonCheckFieldsInDropdown);	
		for(i=0; i<ItemList.size(); i++)
		{

			if(ItemList.get(i).getText().equals(text))
			{		

				break;
			}

		}

		try{			
			if(ItemList.get(i).getText().equals(text)){
				System.out.println("item is available in dropdown");
			}						
			ItemList.get(i).click();		
		}
		catch(IndexOutOfBoundsException e){
			System.out.println("item is not available in dropdown");
			TimeUnit.SECONDS.sleep(2);			
		}

	}

	//Function to select an element from dropdown having no checkbox and no search box


	//Date picker function		
	public void Datepicker(String date) throws InterruptedException{			
		String splitter1[] = date.split("-");  //1-April 2020
		String SelectDate = splitter1[0];
		String month_year = splitter1[1];
		String splitter2[] = month_year.split(" ");
		String SelectMonth = splitter2[0];
		String SelectYear = splitter2[1];

		Select action_month = new Select(driver.findElement(MonthDropdown));
		action_month.selectByVisibleText(SelectMonth);

		Select action_year = new Select(driver.findElement(YearDropdown));
		action_year.selectByVisibleText(SelectYear);

		//String Today = driver.findElement(TodaySelected).getText();
		//List<WebElement> AllDates = driver.findElements(TotalDays);
		try{
			List<WebElement> SelectableDates = driver.findElements(ActiveDays);

			for(WebElement s:SelectableDates ){			
				if(s.getText().equals(SelectDate)){
					s.click();

				}					
			}
		}

		catch(org.openqa.selenium.StaleElementReferenceException e){
			List<WebElement> SelectableDates_New = driver.findElements(ActiveDays);	
			for(WebElement t:SelectableDates_New){			
				if(t.getText().equals(SelectDate)){
					t.click();

				}					//using try catch due to stale element exception 
			}
		}

	}		
	//Date picker function



	public void AddSOWButton() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DownArrowButton));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DownArrowButton).click();
		driver.findElement(AddSOWButton).click();
	}


	public void SOW(String SOWCode, String SOWTitleText) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DownArrowButton));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DownArrowButton).click();
		driver.findElement(AddSOWButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CLEDropdown));

		driver.findElement(CLEDropdown).click();
		//call SelectItemFromDropdown by passing CLE value		
		SelectItemFromDropdown("Test_CLE_DB");
		//call SelectItemFromDropdown by passing CLE value

		driver.findElement(SOWCodeField).sendKeys(SOWCode);	

		driver.findElement(PracticeAreaDropdown).click();
		//call SelectCheckboxtemsFromDropdown by passing Primary POC value
		SelectCheckboxItemsFromDropdown("eLearning");
		driver.findElement(PracticeAreaDropdown).click();
		SelectCheckboxItemsFromDropdown("Devices");
		//call SelectCheckboxItemsFromDropdown by passing Primary POC value				

		driver.findElement(PrimaryPOCDropdown).click();
		//call SelectItemFromDropdown by passing Primary POC value
		SelectItemFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		//call SelectItemFromDropdown by passing Primary POC value

		driver.findElement(AdditionalPOCDropdown).click();
		//call SelectCheckboxtemsFromDropdown by passing Primary POC value
		SelectCheckboxItemsFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		//call SelectCheckboxItemsFromDropdown by passing Primary POC value

		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SOWTitle).sendKeys(SOWTitleText);
		TimeUnit.SECONDS.sleep(1);

		List<WebElement> TotalDateButtons = driver.findElements(SOWDateButtons);
		TotalDateButtons.get(0).click();
		Datepicker("25-June 2020");	
		TimeUnit.SECONDS.sleep(1);		
		TotalDateButtons.get(1).click();
		Datepicker("31-August 2020");

		TimeUnit.SECONDS.sleep(2);

		//this is not working...tried with all possible ways
		//driver.findElement(ChooseFileButton).click();
		//this is not working...tried with all possible ways

		List<WebElement> AllFields_SOW = driver.findElements(CommonFields_SOW);
		AllFields_SOW.get(7).click();

		ObjectsOfBaseClass.UploadFile1();

		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		driver.findElement(CurrencyDropdown).click();
		SelectItemFromDropdown("USD");
		driver.findElement(SOWNetBudget).sendKeys("100");
		driver.findElement(SOWOOPBudget).sendKeys("50");
		driver.findElement(SOWTaxBudget).sendKeys("50");

		/*
		driver.findElement(CML1Dropdown).click();
		SelectCheckboxItemsFromDropdown("Praveen Amancha");
		 */

		/*
		driver.findElement(CML1Dropdown).click();
		SelectCheckboxItemsFromDropdown("Sneha Danduk");
		 */

		/*
		driver.findElement(CML2Dropdown).click();
		TimeUnit.SECONDS.sleep(1);
		SelectItemFromDropdown("Praveen Amancha");
		 */

		/*
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(DelL1Dropdown).click();
		TimeUnit.SECONDS.sleep(1);
		SelectCheckboxItemsFromDropdown("Maxwell Fargose");
		 */

		/*
		driver.findElement(DelL1Dropdown).click();
		SelectCheckboxItemsFromDropdown("Test SP2");
		 */
		/*
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(DelL2Dropdown).click();
		SelectItemFromDropdown("Test SP");
		 */	
		driver.findElement(SOWOwnerDropdown).click();
		SelectItemFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddSOWButton).click();


	}

	public void SOW_NegativeTitle(String SOWCode, String SOWTitleText) throws InterruptedException, IOException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(DownArrowButton));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(DownArrowButton).click();
		driver.findElement(AddSOWButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(CLEDropdown));

		driver.findElement(CLEDropdown).click();
		//call SelectItemFromDropdown by passing CLE value		
		SelectItemFromDropdown("Test_CLE_DB");
		//call SelectItemFromDropdown by passing CLE value

		driver.findElement(SOWCodeField).sendKeys(SOWCode);	

		driver.findElement(PracticeAreaDropdown).click();
		//call SelectCheckboxtemsFromDropdown by passing Primary POC value
		SelectCheckboxItemsFromDropdown("eLearning");
		driver.findElement(PracticeAreaDropdown).click();
		SelectCheckboxItemsFromDropdown("Devices");
		//call SelectCheckboxItemsFromDropdown by passing Primary POC value				

		driver.findElement(PrimaryPOCDropdown).click();
		//call SelectItemFromDropdown by passing Primary POC value
		SelectItemFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		//call SelectItemFromDropdown by passing Primary POC value

		driver.findElement(AdditionalPOCDropdown).click();
		//call SelectCheckboxtemsFromDropdown by passing Primary POC value
		SelectCheckboxItemsFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		//call SelectCheckboxItemsFromDropdown by passing Primary POC value

		/* negative scenario
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SOWTitle).sendKeys(SOWTitleText);
		TimeUnit.SECONDS.sleep(1);
		 */
		List<WebElement> TotalDateButtons = driver.findElements(SOWDateButtons);
		TotalDateButtons.get(0).click();
		Datepicker("25-June 2020");	
		TimeUnit.SECONDS.sleep(1);		
		TotalDateButtons.get(1).click();
		Datepicker("31-August 2020");

		TimeUnit.SECONDS.sleep(2);

		//this is not working...tried with all possible ways
		//driver.findElement(ChooseFileButton).click();
		//this is not working...tried with all possible ways

		List<WebElement> AllFields_SOW = driver.findElements(CommonFields_SOW);
		AllFields_SOW.get(7).click();

		ObjectsOfBaseClass.UploadFile1();

		driver.findElement(CommentsTextBox).sendKeys("Test_Comments");
		driver.findElement(CurrencyDropdown).click();
		SelectItemFromDropdown("USD");
		driver.findElement(SOWNetBudget).sendKeys("100");
		driver.findElement(SOWOOPBudget).sendKeys("50");
		driver.findElement(SOWTaxBudget).sendKeys("50");

		TimeUnit.SECONDS.sleep(3);
		driver.findElement(DelL2Dropdown).click();
		SelectItemFromDropdown("Test SP");

		driver.findElement(SOWOwnerDropdown).click();
		SelectItemFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(AddSOWButton).click();
	}


	public String GetProjectCode(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWorProjectToast));		
		String ToastMSG = driver.findElement(SOWorProjectToast).getText();
		String splitter1[]=ToastMSG.split(" - ");
		String ProjectCode=splitter1[1];
		//System.out.println(ProjectCode);
		return ProjectCode;
	}

	public void WriteProjectCodeToExcel(int row, int column) throws IOException{
		PM_ObjectClasss obj=new PM_ObjectClasss();
		//obj.GetSOWCodeAndWriteToExcel();
		FileInputStream fis=new FileInputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet ws=wb.getSheet("Sheet1");
		ws.getRow(row).getCell(column).setCellValue(obj.GetProjectCode());
		FileOutputStream fos=new FileOutputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		wb.write(fos);	
	}

	public String GetSOWCode(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWorProjectToast));		
		String ToastMSG = driver.findElement(SOWorProjectToast).getText();
		String splitter1[]=ToastMSG.split(" - ");
		String SOWMsg=splitter1[1];
		String splitter2[]=SOWMsg.split(" ");
		String SOWCode=splitter2[0];
		//System.out.println(SOWCode);
		return SOWCode;

		/*
		FileInputStream fis=new FileInputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet ws=wb.getSheet("Sheet1");
		ws.getRow(7).getCell(4).setCellValue(SOWCode);
		FileOutputStream fos=new FileOutputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		wb.write(fos);
		 */
	}

	public void WriteSOWCodeToExcel(int row, int column) throws IOException{
		PM_ObjectClasss obj=new PM_ObjectClasss();
		//obj.GetSOWCodeAndWriteToExcel();
		FileInputStream fis=new FileInputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet ws=wb.getSheet("Sheet1");
		ws.getRow(row).getCell(column).setCellValue(obj.GetSOWCode());
		FileOutputStream fos=new FileOutputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		wb.write(fos);		
	}


	public String ReadFromExcel(int row, int column) throws IOException{
		FileInputStream fis=new FileInputStream("C:\\Users\\praveen.amancha\\Desktop\\Automation\\Automation_ModuleWise_TC\\AutomationSuite_PM.xlsx");	
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet ws=wb.getSheet("Sheet1");
		String R_SOWCode=ws.getRow(row).getCell(column).getStringCellValue();
		return R_SOWCode;
	}


	public void AddProjectButtonMain(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddProjectButton));
		driver.findElement(AddProjectButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchField));
	}


	public void SelectSOWthroughAddProjectBUTTON(String SOWCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddProjectButton));
		driver.findElement(AddProjectButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchField));
		driver.findElement(SearchField).sendKeys(SOWCode);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(RadioButton).click();
		driver.findElement(SelectSOWAndContinueButton).click();
		TimeUnit.SECONDS.sleep(3);			
	}

	public void SelectSOWthroughAllSOWTAB(String SOWCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllSOWtab));
		driver.findElement(AllSOWtab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWCodeColumnDropdown));
		driver.findElement(SOWCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(SOWCode);
		TimeUnit.SECONDS.sleep(2);					
	}

	public void AddProjectSOWOption() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(AddProjectOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(BilledByDropdown));
		TimeUnit.SECONDS.sleep(3);
	}

	public void EditSOWTitle() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EditSOWOption).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(SOWTitle).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(SOWTitle).sendKeys("EditSOWTitle");
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(UpdateSOWButton).click();
	}

	public void EditSOWTitleByFileUpload() throws InterruptedException, IOException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EditSOWOption).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(SOWTitle).clear();
		driver.findElement(SOWTitle).sendKeys("EditSOWTitle");
		TimeUnit.SECONDS.sleep(3);

		//this is not working...tried with all possible ways
		//driver.findElement(ChooseFileButton).click();
		//this is not working...tried with all possible ways

		List<WebElement> AllFields_SOW = driver.findElements(CommonFields_SOW);
		AllFields_SOW.get(7).click();

		ObjectsOfBaseClass.UploadFile2();

		driver.findElement(UpdateSOWButton).click();
		TimeUnit.SECONDS.sleep(30);
	}				


	public void UpdateSOWBudgetAdd() throws InterruptedException, IOException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(UpdateBudgetOption).click();
		TimeUnit.SECONDS.sleep(3);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AllRadioButton);
		AllRadio.get(0).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNetTextField).clear();
		driver.findElement(DialogueNetTextField).sendKeys("100.5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("50.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("10.5");
		List<WebElement> AllFields_UpdateBudSOW = driver.findElements(UpdateSOWBudgetCommon);
		AllFields_UpdateBudSOW.get(4).click();

		ObjectsOfBaseClass.UploadFile1();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();				
	}

	public void UpdateSOWBudgetReduce() throws InterruptedException, IOException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(UpdateBudgetOption).click();
		TimeUnit.SECONDS.sleep(3);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AllRadioButton);
		AllRadio.get(1).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNetTextField).clear();
		driver.findElement(DialogueNetTextField).sendKeys("-10.5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("-2.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("-2.5");
		List<WebElement> AllFields_UpdateBudSOW = driver.findElements(UpdateSOWBudgetCommon);
		AllFields_UpdateBudSOW.get(4).click();
		ObjectsOfBaseClass.UploadFile2();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();				
	}

	public void UpdateSOWBUdgetRestructure() throws InterruptedException, IOException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(UpdateBudgetOption).click();
		TimeUnit.SECONDS.sleep(3);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogueUpdateButton));
		List<WebElement> AllRadio = driver.findElements(AllRadioButton);
		AllRadio.get(2).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueNetTextField).clear();
		driver.findElement(DialogueNetTextField).sendKeys("5");
		driver.findElement(DialogueOOPTextField).clear();
		driver.findElement(DialogueOOPTextField).sendKeys("-2.5");
		driver.findElement(DialogueTaxTextField).clear();
		driver.findElement(DialogueTaxTextField).sendKeys("-2.5");

		List<WebElement> AllFields_UpdateBudSOW = driver.findElements(UpdateSOWBudgetCommon);
		AllFields_UpdateBudSOW.get(4).click();

		ObjectsOfBaseClass.UploadFile1();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();
	}

	public void ViewProjectsOfSOW() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ViewProjectsOption).click();
		TimeUnit.SECONDS.sleep(3);
	}

	public void CloseSOW() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(CloseSOWOption).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(DialogYesButton).click();
		TimeUnit.SECONDS.sleep(3);
	}

	public void SOWShowHistory() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SOWShowHistoryOption).click();
		TimeUnit.SECONDS.sleep(3);		
	}

	public void ViewSOW() throws InterruptedException{
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ViewSOWOption).click();
		TimeUnit.SECONDS.sleep(3);
	}

	public void ProjectType(String ProjectType) throws InterruptedException, IOException{		
		wait.until(ExpectedConditions.visibilityOfElementLocated(CommonFields_Project));
		List<WebElement> AllFields_Project = driver.findElements(CommonFields_Project);
		AllFields_Project.get(1).click(); //Project SOW field

		ObjectsOfBaseClass.UploadFile1();

		driver.findElement(BilledByDropdown).click();
		SelectItemFromSimpleDropdown(ProjectType);								
	}

	public void ManageFinanceDel(String Revenue, String POName) throws InterruptedException{
		driver.findElement(ManageFinanceButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddBudgetButton));
		driver.findElement(ProjectRevenue).sendKeys(Revenue);	
		driver.findElement(AddBudgetButton).click();
		TimeUnit.SECONDS.sleep(2);		
		List<WebElement> TotalTabsFinance = driver.findElements(ProjectFinancePopupTabs);		
		TotalTabsFinance.get(1).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectPOdropdown).click();
		SelectItemFromDropdown(POName);
		driver.findElement(AddPObutton).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ReserveBudgetButton).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ScheduleInvoiceButton).click();
		TimeUnit.SECONDS.sleep(3);
		
		//If No Advance Invoice exists
		try{
		driver.findElement(SingleDatePickerButton).click();
		}
		
		//If Advance Invoice exists
		catch(org.openqa.selenium.NoSuchElementException e){
			driver.findElement(DialogueScheduleNewINvoiceButton).click();
			TimeUnit.SECONDS.sleep(3);
			driver.findElement(SingleDatePickerButton).click();
		}
		
		TimeUnit.SECONDS.sleep(5);		
		Datepicker("22-September 2020");
		driver.findElement(InvoiceAmountInputbox).sendKeys(Revenue);
		driver.findElement(PrimaryPOCDropdown).click();
		SelectItemFromDropdown("Test_Auto_FN1 Test_Auto_LN1");
		driver.findElement(AddressDopdown).click();
		SelectItemFromSimpleDropdown("POC");
		
		driver.findElement(SaveButton).click();
		TimeUnit.SECONDS.sleep(3);

		/*
		//Create action to confirm scheduled invoice afrer saving Finance dialoge
		driver.findElement(ConfirmLineitemIcon).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogYesButton).click();
		//Create action to confirm shceduled invoic afrer saving Finance dialoge
		 */
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SaveButton).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ContinueButton).click();
	}

	public void ManageFianceHourly(String Rate, String POName) throws InterruptedException{
		driver.findElement(ManageFinanceButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddRateButton));
		driver.findElement(RateTextBox).sendKeys(Rate);
		driver.findElement(AddRateButton).click();
		TimeUnit.SECONDS.sleep(2);
		List<WebElement> TotalTabsFinance = driver.findElements(ProjectFinancePopupTabs);		
		TotalTabsFinance.get(1).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(SelectPOdropdown).click();
		SelectItemFromDropdown(POName);
		driver.findElement(AddPObutton).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SaveButton).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ContinueButton).click();
	}

	public void ProjectAttributes(String SubDivision) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubDivisionDropdown));
		driver.findElement(SubDivisionDropdown).click();
		SelectItemFromSimpleDropdown(SubDivision);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(PracticeAreaDropdown).click();		
		SelectItemFromDropdown("Devices");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(PriorityDropdown).click();
		SelectItemFromSimpleDropdown("High-complexity");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(MolleculeDropdown).click();
		SelectItemFromDropdown("Mabthera (Rituximab )");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(TADropdown).click();
		SelectItemFromDropdown("Oncology");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(IndicationTextBox).sendKeys("Test_Indication");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProjectTitleTextBox).sendKeys("Test_ProjectTitle");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProjectShortTitleTextBox).sendKeys("Test_ShortTitle");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(EndUseDeliverableTextBox).sendKeys("Test_EndUseOfDeliverable");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SOWLinkTextBox).sendKeys("Test_SOWLink");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ConJournalTextBox).sendKeys("Test_Conference/Journal");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(AuthorsTextBox).sendKeys("Test_Authors");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(CommentsTextBox).sendKeys("Test_Project Comments");
		TimeUnit.SECONDS.sleep(2);

		WebElement PubSupportRequired = driver.findElement(PubSupportRequiredSimpleCheckBox);
		if(PubSupportRequired.isEnabled()){
			PubSupportRequired.click();
			//driver.findElement(PubSupportRequiredSimpleCheckBox).click();
		}

		TimeUnit.SECONDS.sleep(3);
		driver.findElement(ContinueToTimelineButton).click();	
		TimeUnit.SECONDS.sleep(3);
	}

	public void NonStanadardTimeline(String Deliverable) throws InterruptedException{
		TimeUnit.SECONDS.sleep(10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NonStandardRadioButton));
		driver.findElement(NonStandardRadioButton).click();
		TimeUnit.SECONDS.sleep(30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(NonStandardRadioButton)).isSelected();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(DeliverableTypeDropdown)).isSelected();
		driver.findElement(DeliverableTypeDropdown).click();
		SelectItemFromDropdown(Deliverable);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SubTypeDropdown).click();
		SelectItemFromDropdown("Creation");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ServiceDropdown).click();
		SelectItemFromDropdown("Primary review");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ResourceDropdown).click();
		SelectItemFromDropdown("Praveen Amancha");    ///Deliverable
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ResourceDropdown).click();
		SelectItemFromDropdown("Test SP");		//FTE
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProposedStartDate).click();
		Datepicker("27-August 2020");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProposedEndDate).click();
		Datepicker("28-September 2020");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProjectBudgetHrTextBox).sendKeys("120.5");
		driver.findElement(SaveButton).click();		
		TimeUnit.SECONDS.sleep(30);
	}

	public void StandardTimeline(String Service) throws InterruptedException{		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ServiceDropdown));
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(ServiceDropdown).click();		
		SelectItemFromDropdown(Service);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ResourceDropdown).click();
		SelectItemFromDropdown("Praveen Amancha");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ReviewerDropdown).click();
		SelectItemFromDropdown("Test SP");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(ProposedStartDate).click();
		Datepicker("1-September 2020");
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(CapacityButton).click();
		TimeUnit.SECONDS.sleep(15);
		driver.findElement(GenerateButton).click();
		TimeUnit.SECONDS.sleep(35);
		driver.findElement(SaveButton).click();	
		TimeUnit.SECONDS.sleep(30);
	}	

	public void SearchProjectAction(String ProjectCode) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		TimeUnit.SECONDS.sleep(5);		
	}

	public void ConfirmProject() throws InterruptedException{
		driver.findElement(pMenu).click();
		//act = new Actions(driver);   declared in Constructor
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		driver.findElement(ConfirmProjectOption).click();
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogYesButton));
		driver.findElement(DialogYesButton).click();
		TimeUnit.SECONDS.sleep(20);
	}	

	public void ConfirmLineitem() throws InterruptedException{
		driver.findElement(pMenu).click();
		//act = new Actions(driver);   declared in Constructor
		act.moveToElement(driver.findElement(ProjectFinanceOption)).build().perform();
		driver.findElement(ManageFinanceOption).click();
		TimeUnit.SECONDS.sleep(10);		
		List<WebElement> TotalTabsFinance = driver.findElements(ProjectFinancePopupTabs);		
		TotalTabsFinance.get(1).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ConfirmLineitemIcon).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(DialogYesButton).click();
		TimeUnit.SECONDS.sleep(5);		
		driver.findElement(CloseIcon).click();
		TimeUnit.SECONDS.sleep(5);
	}

	public void ViewProjectDetails() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(ViewProjectDetailsOption).click();
		TimeUnit.SECONDS.sleep(2);	

	}

	public void EditProject() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(EditProjectOption).click();
		TimeUnit.SECONDS.sleep(5);	
		driver.findElement(CommentsTextBox).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(CommentsTextBox).sendKeys("Test_Project Edit1 Comments");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(DialogueUpdateButton).click();
		TimeUnit.SECONDS.sleep(10);		
	}

	public void ProjectCommunications() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(CommunicationsOption).click();
		TimeUnit.SECONDS.sleep(5);
		//upload action nneds to be written later
	}

	public void ProjectTimeline() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(TimelineOption).click();
		TimeUnit.SECONDS.sleep(10);
	}

	public void ProjectGoToAllocation() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(GoToAllocationOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ProjectScope() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(ProjectScopeOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ViewProjectCDsPFs() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(ViewCDsPFsOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ViewPubSupport() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectMiscOption)).build().perform();
		driver.findElement(ViewPubSupportOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ProjectManageFinance() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectFinanceOption)).build().perform();
		driver.findElement(ManageFinanceOption).click();
		TimeUnit.SECONDS.sleep(10);	
	}

	public void ProjectChangeSOW() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectFinanceOption)).build().perform();
		driver.findElement(ChangeSOWOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ProjectExpense() throws InterruptedException{
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectFinanceOption)).build().perform();
		driver.findElement(ExpenseOption).click();
		TimeUnit.SECONDS.sleep(5);	
	}

	public void ProjectShowHistory() throws InterruptedException{
		driver.findElement(pMenu).click();
		driver.findElement(ProjectShowHistoryOption).click();
		TimeUnit.SECONDS.sleep(5);
	}	

	public void ProposeClosureAction() throws InterruptedException{	
		/*
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable
		 * Search Project Function
		 */

		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		driver.findElement(ProposeClosureOption).click();
		//TimeUnit.SECONDS.sleep(2);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(DialogYesButton));
		driver.findElement(DialogYesButton).click();
		TimeUnit.SECONDS.sleep(5);
	}

	public void ProposeClosureAction_Negative() throws InterruptedException{	
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		driver.findElement(ProposeClosureOption).click();
		//TimeUnit.SECONDS.sleep(2);	
	}









	public void CancelProjectAction(String ReasonType) throws InterruptedException{
		/*
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable
		 * Search Project Function
		 */

		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		driver.findElement(CancelProjectOption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PCancelReasonTypeDropdown));
		driver.findElement(PCancelReasonTypeDropdown).click();
		SelectItemFromDropdown(ReasonType);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(PCancelReasonCommentBox).sendKeys("Test_Comments for Project Cancel");
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ConfirmButton).click();	
		TimeUnit.SECONDS.sleep(5);
	}

	public void ProjectOnHoldAction() throws InterruptedException{
		/*
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable
		 * Search Project Function
		 */
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ProjectOnHoldOption).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(SaveButton).click();		
		TimeUnit.SECONDS.sleep(5);
	}

	public void ProjectOffHoldAction() throws InterruptedException{
		/*
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable
		 * Search Project Function
		 */
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(pMenu).click();
		act.moveToElement(driver.findElement(ProjectStatusOption)).build().perform();
		TimeUnit.SECONDS.sleep(2);		
		driver.findElement(ProjectOffHoldOption).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(SaveButton).click();	
		TimeUnit.SECONDS.sleep(5);

	}








	public void CSAuditAction() throws InterruptedException{
		/* Search Project FUnction
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable	
		 * Search Project Function
		 */
		TimeUnit.SECONDS.sleep(2);	
		driver.findElement(CSAuditButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditProjectListParentCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditProjectDialogParentCheckBox).click();
		List<WebElement> CSAuditComments = driver.findElements(AuditcommentsTextBoxes);
		for(int i=0; i<CSAuditComments.size()-2; i++){
			CSAuditComments.get(i).sendKeys("Test_Comments");
		}

		TimeUnit.SECONDS.sleep(2);
		List<WebElement> AuditMultiDropdowns = driver.findElements(CSAuditDropdowns);

		Select CDareOPEN = new Select(AuditMultiDropdowns.get(0));		
		CDareOPEN.selectByVisibleText("Yes");
		TimeUnit.SECONDS.sleep(2);
		Select ERaccured = new Select(AuditMultiDropdowns.get(1));
		ERaccured.selectByVisibleText("Yes");

		/*
		AuditMultiDropdowns.get(0).click();
		SelectItemFromSimpleDropdown("Yes");
		TimeUnit.SECONDS.sleep(2);
		AuditMultiDropdowns.get(1).click();
		SelectItemFromSimpleDropdown("Yes");
		 */

		driver.findElement(ConfirmButton).click();
		TimeUnit.SECONDS.sleep(10);
		driver.findElement(CancelButton).click();
		TimeUnit.SECONDS.sleep(5);

	}

	public void FinanceAuditAction() throws InterruptedException{
		/* Search Project Function
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		driver.findElement(AllProjectsTab).click();
		//repeatable
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCodeColumnDropdown));
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(ProjectCodeColumnDropdown).click();
		SelectCheckboxItemsFromDropdown(ProjectCode);
		//repeatable
		 * Search Project Function	
		 */
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(FinanceAuditButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditProjectListParentCheckBox).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(AuditProjectDialogParentCheckBox).click();
		List<WebElement> FinanceAuditComments = driver.findElements(AuditcommentsTextBoxes);
		for(int i=0; i<FinanceAuditComments.size(); i++){
			FinanceAuditComments.get(i).sendKeys("Test_Comments");
		}
		driver.findElement(ConfirmButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CancelButton).click();
		TimeUnit.SECONDS.sleep(10);
	}

	public void HomePageElements() throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOfElementLocated(AllProjectsTab));
		WebElement ExpTab1 = driver.findElement(AllProjectsTab);
		String Tabname1=ExpTab1.getText();
		if (Tabname1.contains("All Projects")) 
		{
			System.out.println("'All Projects' tab is present");
			driver.findElement(AllProjectsTab).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(CSAuditButton));
			WebElement ExpButton1_AllProject = driver.findElement(CSAuditButton);
			String Button1=ExpButton1_AllProject.getText();
			if(Button1.contains("CS Audit"))
			{
				System.out.println("'CS Audit' button is available");
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(FinanceAuditButton));
			WebElement ExpButton2_AllProject = driver.findElement(FinanceAuditButton);
			String Button2=ExpButton2_AllProject.getText();
			if(Button1.contains("Finance Audit"))
			{
				System.out.println("'Finance Audit' button is available");
			}
			WebElement ExpButton3_AllProject = driver.findElement(AddProjectButton);
			String Button3=ExpButton3_AllProject.getText();
			if(Button3.contains("Add Project"))
			{
				System.out.println("'Add Project' button is available");
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(OpenClosedCancelledNotStartedDropdown));
			WebElement ExpDropdown_AllProject = driver.findElement(OpenClosedCancelledNotStartedDropdown);
			if(ExpDropdown_AllProject.isDisplayed())
			{
				System.out.println("'OpenClosedCancelled' dropdown is available");
			}

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_AllProject = driver.findElement(ExportToExcelWithBudgetAndCurrencyIcon);
					if(ExpIcon_AllProject.isDisplayed())
					{
						System.out.println("'ExportToExcelWithBudgetAndCurrency' icon is available");
					}
					WebElement ExpIcon2_AllProject = driver.findElement(ExportToExcelIcon);
					if(ExpIcon2_AllProject.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}

			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data fund");
			}

		}

		WebElement ExpTab2 = driver.findElement(AllSOWtab);
		String Tabname2=ExpTab2.getText();
		if (Tabname2.contains("All SOW")) 
		{
			System.out.println("'All SOW' tab is present");
			driver.findElement(AllSOWtab).click();
			TimeUnit.SECONDS.sleep(30);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ExportToExcelIcon));

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_AllSOW = driver.findElement(ExportToExcelIcon);
					if(ExpIcon_AllSOW.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}
			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data fund");
			}
		}

		WebElement ExpTab3 = driver.findElement(SendToClientTab);
		String Tabname3=ExpTab3.getText();
		if (Tabname3.contains("Send to Client")) 
		{
			System.out.println("'Send to Client' tab is present");
			driver.findElement(SendToClientTab).click();
			TimeUnit.SECONDS.sleep(30);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ExportToExcelIcon));

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_SendToClient = driver.findElement(ExportToExcelIcon);
					if(ExpIcon_SendToClient.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}
			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data fund");
			}

			WebElement RadioButton1_SendToClient = driver.findElement(TodaysDeliveryRadioButton);
			String RadioButton1name = RadioButton1_SendToClient.getText();
			if(RadioButton1name.contains("Today’s delivery"))
			{
				System.out.println("'Today's delivery' radio button is present");
			}
			WebElement RadioButton2_SendToClient = driver.findElement(Next5DaysRadioButton);
			String RadioButton2name = RadioButton2_SendToClient.getText();
			if(RadioButton2name.contains("Next 5 days"))
			{
				System.out.println("'Next 5 days' radio button is present");
			}
			WebElement RadioButton3_SendToClient = driver.findElement(OverDueRadioButton);
			String RadioButton3name = RadioButton3_SendToClient.getText();
			if(RadioButton3name.contains("Overdue"))
			{
				System.out.println("'Overdue' radio button is present");
			}					
		}

		WebElement ExpTab4 = driver.findElement(ClientReviewTab);
		String Tabname4=ExpTab4.getText();
		if (Tabname4.contains("Client Review")) 
		{
			System.out.println("'Client Review' tab is present");
			driver.findElement(ClientReviewTab).click();
			TimeUnit.SECONDS.sleep(30);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ExportToExcelIcon));

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_ClientReview = driver.findElement(ExportToExcelIcon);
					if(ExpIcon_ClientReview.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}
			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data found");
			}

			WebElement RadioButton1_ClientReview = driver.findElement(TodaysDeliveryRadioButton);
			String RadioButton1name = RadioButton1_ClientReview.getText();
			if(RadioButton1name.contains("Today’s delivery"))
			{
				System.out.println("'Today's delivery' radio button is present");
			}
			WebElement RadioButton2_ClientReview = driver.findElement(Next5DaysRadioButton);
			String RadioButton2name = RadioButton2_ClientReview.getText();
			if(RadioButton2name.contains("Next 5 days"))
			{
				System.out.println("'Next 5 days' radio button is present");
			}
			WebElement RadioButton3_ClientReview = driver.findElement(OverDueRadioButton);
			String RadioButton3name = RadioButton3_ClientReview.getText();
			if(RadioButton3name.contains("Overdue"))
			{
				System.out.println("'Overdue' radio button is present");
			}	
			wait.until(ExpectedConditions.visibilityOfElementLocated(OpenClosedCancelledNotStartedDropdown));
			WebElement ExpDropdown_ClientReview = driver.findElement(OpenClosedCancelledNotStartedDropdown);
			if(ExpDropdown_ClientReview.isDisplayed())
			{
				System.out.println("'NotStartedClosed' dropdown is available");
			}
		}

		WebElement ExpTab5 = driver.findElement(PendingAllocationTab);
		String Tabname5=ExpTab5.getText();
		if (Tabname5.contains("Pending Allocation")) 
		{
			System.out.println("'Pending Allocation' tab is present");
			driver.findElement(PendingAllocationTab).click();
			TimeUnit.SECONDS.sleep(30);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ExportToExcelIcon));

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_PendingAllocation = driver.findElement(ExportToExcelIcon);
					if(ExpIcon_PendingAllocation.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}
			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data fund");
			}
		}

		WebElement ExpTab6 = driver.findElement(InActiveProjectsTab);
		String Tabname6=ExpTab6.getText();
		if (Tabname6.contains("Inactive Projects")) 
		{
			System.out.println("'Inactive Projects' tab is present");
			driver.findElement(InActiveProjectsTab).click();
			TimeUnit.SECONDS.sleep(30);
			//wait.until(ExpectedConditions.visibilityOfElementLocated(ExportToExcelIcon));

			try{
				if(driver.findElement(pMenu).isDisplayed()){ //checking if any project's/sow's/tasks exist
					WebElement ExpIcon_PendingAllocation = driver.findElement(ExportToExcelIcon);
					if(ExpIcon_PendingAllocation.isDisplayed())
					{
						System.out.println("'ExportToExcel' icon is available");
					}
				}
			}
			catch(org.openqa.selenium.NoSuchElementException e){
				System.out.println("No Projects/SOW/Task data fund");
			}
		}		

		TimeUnit.SECONDS.sleep(10);  //This will be the validation point if all if conditions pass for TC class

	}











}

