package allModulesPkg;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CentralAllocation_ObjectClass extends Login {

	BaseClass ObjectsOfBaseClass = new BaseClass();	
	
	String Slots[] = {"QCSlot","SubmitSlot","EditSlot","GraphicsSlot","GalleySlot"};
	
	By ClosePopUp = By.xpath("//span[@class='pi pi-times']");
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By CentralAllocationLink = By.xpath("//a[text()='Central Allocation']");

	By MainFilter = By.xpath("//p-dropdown[contains(@class,'mainfilter')]");
	//Options
	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By RestructureOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Restructure']");	
	By EditOption = By.xpath("//span[@class='ui-menuitem-text' and text()='Edit']");	
	
	By ReviewQc = By.xpath("//div[@draggable='true']//span[contains(text(),'Review-QC')]");
	By DropZone = By.xpath("//div[@id='dropZone']");

	By ClientFilter = By.xpath("//th[@ng-reflect-ng-switch='ClientName']/p-multiselect");
	By ProjectCodeFilter = By.xpath("//th[@ng-reflect-ng-switch='ProjectCode']/p-multiselect");
	By TaskFilter = By.xpath("//th[@ng-reflect-ng-switch='Task']/p-multiselect");
	By StartDateFilter = By.xpath("//th[@ng-reflect-ng-switch='StartDateText']/p-multiselect");
	By EndDateFilter = By.xpath("//th[@ng-reflect-ng-switch='DueDateText']/p-multiselect");
	By MilestoneFilter = By.xpath("//th[@ng-reflect-ng-switch='Milestone']/p-multiselect");
	
//	By ExpandIcon = By.xpath("//tr//td[1]//i[@class='pi pi-chevron-right']");
	By SubTaskMenu = By.xpath("//p-table[@class='subtaskTable']//td//i[@class='pi pi-ellipsis-v']");
	By TaskScopeOption = By.xpath("//span[@class='ui-menuitem-text' and text()='View / Add Scope']");	
	
	By SlotColumn = By.xpath("//p-table[@class='slotTable']//tbody//tr//td[5]");
	
	By GlobalSearch = By.xpath("//input[@placeholder='Global Filter']");
	
	By TaskColumn = By.xpath("//tr[@class='milestoneTable ng-star-inserted']//td[1]/span");
	By ResourceDropdown = By.xpath("//p-dropdown[contains(@class,'resourceDropdown')]");
	By DropdownItem = By.xpath("//li[@class='ui-dropdown-item ui-corner-all']/span");
	By SaveButton = By.xpath("//button[@class='mat-raised-button mat-button-base']//span[contains(text(),'Save')]");
	
	public void Navigation() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(ClosePopUp).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(CentralAllocationLink).click();
		
	}
	
	
	public void SwitchTab() throws InterruptedException{
		TimeUnit.SECONDS.sleep(2);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
	}
	
	public void RestructureOption() throws InterruptedException {
		driver.findElement(pMenu).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(RestructureOption).click();
		TimeUnit.SECONDS.sleep(10);
		Actions builder = new Actions(driver);
		WebElement from = driver.findElement(ReviewQc);
		WebElement to = driver.findElement(DropZone); 
		//Perform drag and drop
//		 builder.clickAndHold(from);
//	        builder.moveToElement(to);
//	        builder.perform();
//	        Thread.sleep(250);
//	        builder.release(to);
//	        builder.perform();
		builder.dragAndDropBy(from, 100,170).perform();
		TimeUnit.SECONDS.sleep(5);
	}
	
	public void SelectClientFilter(String Client) throws InterruptedException {
		driver.findElement(ClientFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Client);
	}
	
	public void SelectProjectFilter(String ProjectCode) throws InterruptedException {
		driver.findElement(ProjectCodeFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(ProjectCode);
	}
	
	public void SelectTaskFilter(String Task) throws InterruptedException {
		driver.findElement(TaskFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Task);
	}
	
	public void SelectStartDateFilter(String StartDate) throws InterruptedException {
		driver.findElement(StartDateFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(StartDate);
	}
	
	public void SelectEndDateFilter(String EndDate) throws InterruptedException {
		driver.findElement(EndDateFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(EndDate);
	}
	
	public void SelectMilestoneFilter(String Milestone) throws InterruptedException {
		driver.findElement(MilestoneFilter).click();
		ObjectsOfBaseClass.SelectCheckboxItemsFromDropdown(Milestone);
	}
	
	public void TaskScopeOfParticularTask(String ProjectCode, String Milestone, String Slot, String Task) throws InterruptedException {
		int rowPostion = 1;
		int taskPosition = 1;
		
		String slots[] = Slot.split(" ");
		String slotType = slots[0]; 
		
		driver.findElement(MainFilter).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown("Allocated");
		TimeUnit.SECONDS.sleep(5);
		SelectProjectFilter(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		SelectMilestoneFilter(Milestone);
		TimeUnit.SECONDS.sleep(2);
		SelectTaskFilter(slotType);
		TimeUnit.SECONDS.sleep(2);
		
		List<WebElement> Column = driver.findElements(SlotColumn);
		if(Column.size() > 1) {
			for(int i=0;i<Column.size();i++) {
				if(Column.get(i).equals(Slot)) {
					rowPostion = i+1;
				}
			}
		}
		
		By ExpandIcon = By.xpath("//tr["+rowPostion+"]//td[1]//i[@class='pi pi-chevron-right']");
		driver.findElement(ExpandIcon).click();
		TimeUnit.SECONDS.sleep(5);
		List<WebElement> tasks = driver.findElements(TaskColumn);
		if(tasks.size() > 1) {
			for(int i=0;i<tasks.size();i++) {
				if(tasks.get(i).getText().contains(Task)) {
					taskPosition = i+1;
//					found = true;
				}
			}
		} else {
			if(tasks.get(0).getText().contains(Task)) {
				taskPosition = 1;
//				found = true;
			}
		}	

		By SubTaskMenu = By.xpath("//p-table[@class='subtaskTable']//tr["+taskPosition+"]//i[@class='pi pi-ellipsis-v']");
		driver.findElement(SubTaskMenu).click();
		TimeUnit.SECONDS.sleep(3);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(TaskScopeOption).click();
	}
	
	public void GlobalFilter(String Type, String Search) throws InterruptedException {
		driver.findElement(MainFilter).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown(Type);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(GlobalSearch).sendKeys(Search);
	}
	
	public void AssignResource(String Type, String ProjectCode, String Milestone,  String Slot ,String Task, String Resource) throws InterruptedException{
		WebElement resourceItem = null;
		int rowPostion = 1;
		int taskPosition = 1;
		boolean found = false;
		
		String slots[] = Slot.split(" ");
		String slotType = slots[0]; 
		
		driver.findElement(MainFilter).click();
		TimeUnit.SECONDS.sleep(2);
		ObjectsOfBaseClass.SelectItemFromSimpleDropdown(Type);
		TimeUnit.SECONDS.sleep(5);
		SelectProjectFilter(ProjectCode);
		TimeUnit.SECONDS.sleep(2);
		SelectMilestoneFilter(Milestone);
		TimeUnit.SECONDS.sleep(2);
		SelectTaskFilter(slotType);
		TimeUnit.SECONDS.sleep(2);
		
		List<WebElement> Column = driver.findElements(SlotColumn);
		if(Column.size() > 1) {
			for(int i=0;i<Column.size();i++) {
				if(Column.get(i).equals(Slot)) {
					rowPostion = i+1;
				}
			}
		}
		
		By ExpandIcon = By.xpath("//tr["+rowPostion+"]//td[1]//i[@class='pi pi-chevron-right']");
		driver.findElement(ExpandIcon).click();
		TimeUnit.SECONDS.sleep(5);
		
		List<WebElement> tasks = driver.findElements(TaskColumn);
		if(tasks.size() > 1) {
			for(int i=0;i<tasks.size();i++) {
				if(tasks.get(i).getText().contains(Task)) {
					taskPosition = i+1;
//					found = true;
				}
			}
		} else {
			if(tasks.get(0).getText().contains(Task)) {
				taskPosition = 1;
//				found = true;
			}
		}	
		if(tasks.size() > 1 || Type.equals("Allocated")) {
			By SubTaskMenu = By.xpath("//p-table[@class='subtaskTable']//tr["+taskPosition+"]//i[@class='pi pi-ellipsis-v']");
			driver.findElement(SubTaskMenu).click();
			TimeUnit.SECONDS.sleep(1);
			driver.findElement(EditOption).click();
			TimeUnit.SECONDS.sleep(1);
		}
		driver.findElement(ResourceDropdown).click();
		TimeUnit.SECONDS.sleep(5);
		ObjectsOfBaseClass.SelectItemFromDropdown(Resource);
//		List<WebElement> resources = driver.findElements(DropdownItem);
//		for(int i=0;i<resources.size();i++) {
//			if(resources.get(i).getText().contains(Resource)) {
//				resourceItem = resources.get(i);
//				break;
//			}
//		}
//		resourceItem.click();
	}
	
	public void AllocateTaskThroughCA(String Type, String ProjectCode, String Milestone, String Slot ,String Task,String Resource) throws InterruptedException {
		AssignResource(Type, ProjectCode, Milestone, Slot, Task, Resource);
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(SaveButton).click();
	}

}
