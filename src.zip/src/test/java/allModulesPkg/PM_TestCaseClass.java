package allModulesPkg;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class PM_TestCaseClass extends Login {	
	PM_TestClass ObjectsOfTestActionsClass = new PM_TestClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	
	Login OjectsOfLoginClass = new Login();

	By ViewProjectsOfSOW_ValPoint1 = By.xpath("//span[contains(@class, 'ui-dialog-title')]//*[text()='View Projects']");
	By SOWCloseSuccessMsg_ValPoint1 = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'Closed')]");
	By SOWCloseSuccessMsg_ValPoint2 = By.xpath("//th[text()=' SOW Code ']");
	By SOWShowHistory_ValPoint = By.xpath("//td[text()='SOW updated' or text()='Attachment']");
	By SOWViewSOW_ValPoint = By.xpath("//td[text()='SOW ID']");
	By AddSOWButton_ValPoint = By.xpath("//span[contains(@class, 'ui-dialog-title')]//*[text()=' Add SOW ']");
	By CreateSOWNegative_ValPoint =By.xpath("//div[@class='error ng-star-inserted']");
	By ProjectCreation_ValPoint = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By SearchProjectSOW_ValPoint = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By EditProject_Valoint = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By ConfirmProject_ValPoint = By.xpath("//span[@class='ng-star-inserted' and text()='Unallocated']");
	By ProjectViewProject_ValPoint = By.xpath("//td[text()='Project ID']");
	By ProjectCommunications_ValPoint = By.xpath("//span[@class='ui-menuitem-text ng-star-inserted' and text()='Source Docs']");
	By ProjectTimeline_ValPoint = By.xpath("//div[@class='table-header-cell-timeline' and text()=' Budget Hrs ']");
	By ProjectScope_ValPoint = By.xpath("//span[@class='_6EkCIBulssv0eDQ55G3yH' and text()='Word']");
	By ProjectViewCDsPFs_ValPoint = By.xpath("//span[@class='ui-tabview-title ng-star-inserted' and text()='Client Dissatisfaction']");
	By ProjectViewPubSupport_ValPoint = By.xpath("//span[text()='Journal/Conference Details']");
	By ProjectManageFinance_ValPoint = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Add Budget']|//p-header[@class='financeHeader ng-star-inserted']");
	By ProjectChangeSOW_ValPoint = By.xpath("//span[@class='ui-button-text ui-clickable' and text()='Move']");
	By ProjectExpense_ValPoint = By.xpath("//th[@ng-reflect-field='ExpenseType']");
	By ProjectShowHistory_ValPoint = By.xpath("//td[text()='Invoice Edited' or text()='Attachment' or text()='Invoice Scheduled' or text()='Project updated']");
	By ProjectProposeClosureNegative_ValPoint = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'line item is not Confirmed')]");
	By ProposeClosureProject_ValPoint = By.xpath("//span[@class='ng-star-inserted' and text()='CS Audit']");
	By ProjectOnHold_ValPoint = By.xpath("//span[@class='ng-star-inserted' and text()='On Hold']");
	By ProjectOffHoldToUnallocated_ValPoint = By.xpath("//span[@class='ng-star-inserted' and text()='Unallocated']");
	By ProjectCSAudit_ValPoint = By.xpath("//span[@class='ng-star-inserted' and text()='Finance Audit']");
	By ProjectCancel_ValPoint = By.xpath("//div[@class='ui-toast-detail' and contains(text(), 'cancelled')]");


	//To validate whether user is able to create SOW: TC01
	@Test(enabled = false)
	public void TC01_CreateSOW() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateSOW("Test_Auto_SOWCode3", "Test_Auto_SOWTitle3", 7, 4);
		TimeUnit.SECONDS.sleep(10);			
		/*/write a validation condition
		p-menu should work
		/*/
		ObjectsOfBaseClass.CloseBrowser();
	}


	//To validate whether user is able to Edit existing SOW: TC02, TC43
	@Test(enabled = false)
	public void TC02_EditSOW() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditSOWTitle(7, 4);
		TimeUnit.SECONDS.sleep(5);
		//write a validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Update Budget on existing SOW by Adding budget: TC03
	@Test(enabled = false)
	public void TC03_UpdateSOWBudget_Add() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_UpdateSOWBudgetAdd(7, 4);
		TimeUnit.SECONDS.sleep(5);
		//write a validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}


	//To validate whether user is able to Update Budget on existing SOW by Reducing budget: TC04
	@Test(enabled = false)
	public void TC04_UpdateSOWBudget_Reduce() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_UpdateSOWBudgetReduce(7, 4);
		TimeUnit.SECONDS.sleep(5);
		//write a validation condition
		ObjectsOfBaseClass.CloseBrowser();	
	}



	//To validate whether user is able to Update Budget on existing SOW by Restructuring budget: TC05
	@Test(enabled = false)
	public void TC05_UpdateSOWBudget_ReStructure() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_UpdateSOWBudgetRestructure(7, 4);
		TimeUnit.SECONDS.sleep(5);
		//write a validation condition
		//ObjectsOfBaseClass.CloseBrowser();	
	}


	//To validate whether user is able to View associated projects on SOW: TC06 & TC14
	@Test(enabled = false)
	public void TC06ANDTC14_ViewProjectsOfSOW() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectsOfSOW(7, 4);
		//TimeUnit.SECONDS.sleep(5);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ViewProjectsOfSOW_ValPoint1));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Close SOW: TC07
	@Test(enabled = false)
	public void TC07_CloseSOW() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateSOW("Test_Auto_SOWCode4", "Test_Auto_SOWTitle4", 13, 4);
		ObjectsOfTestActionsClass.Test_CloseSOW(13, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWCloseSuccessMsg_ValPoint1));
		TimeUnit.SECONDS.sleep(3);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWCloseSuccessMsg_ValPoint2));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}		

	//To validate whether Manager is able to search for existing SOW: TC08 & TC13 & TC28   
	@Test(priority=1, enabled = false)
	public void TC08_TC13_TC28_SearchExistingSOWByManager() throws InterruptedException, IOException{				
		OjectsOfLoginClass.Launch();	
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);  //1, 2, 3
		ObjectsOfTestActionsClass.Test_SearchExistingSOW(7, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));;
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();		
	}

	//To validate whether CM user is able to search for existing SOW: TC36 & TC38
	@Test(priority=2, enabled = false)
	public void TC36_TC38_SearchExistingSOWByCM() throws InterruptedException, IOException{				
		OjectsOfLoginClass.Launch();	
		OjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);  //1, 2, 3
		ObjectsOfTestActionsClass.Test_SearchExistingSOW(7, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));;
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();		
	}
	//To validate whether Delivert user is able to search for existing SOW
	@Test(priority=3, enabled = false)
	public void TC40_TC42_SearchExistingSOWByDel() throws InterruptedException, IOException{				
		OjectsOfLoginClass.Launch();	
		OjectsOfLoginClass.LoginFunctionDataDriven(3, 0, 3, 1);  //1, 2, 3
		ObjectsOfTestActionsClass.Test_SearchExistingSOW(7, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));;
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();		
	}

	//To validate whether user is able to see the History of SOW: TC09
	@Test(enabled = false)
	public void TC09_SOWShowHistory() throws IOException, InterruptedException{		
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_SOWShowHistory(7, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}		

	//To validate whether user is able to view existing SOW details: TC10
	@Test(enabled = false)
	public void TC10_ViewSOW() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewSOW(7, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(SOWViewSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate "Create New  SOW" button functionality: TC11
	@Test(enabled = false)
	public void TC11_AddSOWButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_AddSOWButton();
		//validation condition	
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddSOWButton_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create new SOW by missing one or multiple mandatory fields: TC12
	@Test(enabled = false)
	public void TC12_CreateSOWNegative() throws InterruptedException, IOException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_CreateSOWNegative();
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(CreateSOWNegative_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate "Add Project" main button functionality: TC15
	@Test(enabled = false)
	public void TC15_AddProjectButonMain() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_AddProjectButtonMain();
		//validation included in Test class itself
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate "Add Project" option functionality under SOW tab: TC16
	@Test(enabled = false)
	public void TC16_AddProjectSOWOption() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_AddProjectSOWOption(7, 4);
		//validation included in Test class itself
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create Deliverable Project using 'Add Project' button: TC17
	@Test(enabled = false)
	public void TC17_CreateDelNonStandardProjectThroughAddProjectButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 24, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create Deliverable Non Standard Project through 'AllSOW' tab: TC18
	@Test(enabled = false)
	public void TC18_CreateDelNonStandardProjectThroughAllSOWTab() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAllSOWTab(7, 4, 25, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();		
	}

	//To validate whether user is able to create Deliverable Standard Project using 'Add Project' button: TC19
	@Test(enabled = false)
	public void TC19_CreateDelStandardProjectThroughAddProjectButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelStandardProjectThroughAddProjectButton(7, 4, 26, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();		
	}

	//To validate whether user is able to create Deliverable Standard Project through 'AllSOW' tab: TC20
	@Test(enabled = false)
	public void TC20_CreateDelStandardProjectThroughAllSOWTab() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelStandardProjectThroughAllSOWTab(7, 4, 27, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();	
	}

	//To validate whether user is able to create Hourly Non Standard Project using 'Add Project' button: TC21
	@Test(enabled = false)
	public void TC21_CreateHourlyNonStandardProjectThroughAddProjectButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyNonStandardProjectThroughAddProjectButton(7, 4, 28, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();	
	}

	//To validate whether user is able to create Hourly Non Standard Project through 'AllSOW' tab: TC22
	@Test(enabled = false)
	public void TC22_CreateHourlyNonStandardProjectThroughAllSOWTab() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyNonStandardProjectThroughAllSOWTab(7, 4, 29, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create Hourly Standard Project using 'Add Project' button: TC23 (Project Created by Manager) TC33
	@Test(enabled = false)
	public void TC23_CreateHourlyStandardProjectThroughAddProjectButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyStandardProjectThroughAddProjectButton(7, 4, 30, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create Hourly Standard Project through 'AllSOW' tab: TC24 (Project Created by Manager TC34	
	@Test(priority = 2, enabled = false)
	public void TC24_CreateHourlyStandardProjectThroughAllSOWTab() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyStandardProjectThroughAllSOWTab(7, 4, 31, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to create FTE Non Standard Project using 'Add Project' button: TC25 (Project Creation by CM user) TC29; TC31
	@Test(priority = 1, enabled = false)
	public void TC25_CreateFTENonStandardProjectThroughAddProjectButton() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CreateFTENonStandardProjectThroughAddProjectButton(7, 4, 32, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();		
	}

	//To validate whether user is able to create FTE Non Standard Project through 'AllSOW' tab: TC26 (Project Creation by CM user) TC30; TC32
	@Test(enabled = false)
	public void TC26_CreateFTENonStandardProjectThroughAllSOWTab() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);
		ObjectsOfTestActionsClass.CreateFTENonStandardProjectThroughAllSOWTab(7, 4, 33, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCreation_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();	
	}	

	//To validate whether Manager is able to search for existing Project: TC27
	@Test(enabled = false)
	public void TC27_SearchProjectByManager() throws IOException, InterruptedException{		
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);  //1, 2, 3
		ObjectsOfTestActionsClass.CreateDelStandardProjectThroughAddProjectButton(7, 4, 34, 4);
		ObjectsOfTestActionsClass.SearchProject(34, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();			
	}

	//To validate whether CM user is able to search for existing project: TC35 & TC37
	@Test(enabled = false)
	public void TC35_TC37_SearchProjectByCM() throws IOException, InterruptedException{		
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(2, 0, 2, 1);  //1, 2, 3
		//ObjectsOfTestActionsClass.CreateDelStandardProjectThroughAddProjectButton(7, 4, 34, 4); not required as searching recent project created by Manager
		ObjectsOfTestActionsClass.SearchProject(34, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();			
	}
	//To validate whether Delivery user is able to search for existing project: TC39 & TC41
	@Test(enabled = false)
	public void TC39_41_SearchProjectByDel() throws IOException, InterruptedException{		
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(3, 0, 3, 1);  //1, 2, 3
		//ObjectsOfTestActionsClass.CreateDelStandardProjectThroughAddProjectButton(7, 4, 34, 4);  not required as searching recent project created by Manager
		ObjectsOfTestActionsClass.SearchProject(34, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));
		//validation condition to see whether page is loaded
		ObjectsOfBaseClass.CloseBrowser();			
	}

	//To validate whether user is able to Edit existing SOW by uploading new doc: TC44
	@Test(enabled = false)
	public void TC44_EditSOWTitleByFileUpload() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditSOWTitleByFileUpload(7, 4);
		//validation condition to see whether page is loaded
		wait.until(ExpectedConditions.visibilityOfElementLocated(SearchProjectSOW_ValPoint));
		//validation condition to see whether page is loaded		
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate elements and tabs: TC45-TC63
	@Test(enabled = false)
	public void TC45ToTC63_HomePageElements() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_HomePageElements();
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Confirm 'In Discussion' project: TC64
	@Test(enabled = false)
	public void TC64() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 118, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(118, 4);
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ConfirmProject_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to View project details of 'In Discussion' project: TC65
	@Test(enabled = false)
	public void TC65() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 119, 4);
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Edit 'In Discussion' project: TC66
	@Test(enabled = false)
	public void TC66() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Communications option of 'In Discussion' project: TC67
	@Test(enabled = false)
	public void TC67() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Timeline option of 'In Discussion' project: TC69
	@Test(enabled = false)
	public void TC69() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Go to Allocation option of 'In Discussion' project: TC70
	@Test(enabled = false)
	public void TC70() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'In Discussion' project: TC71
	@Test(enabled = false)
	public void TC71() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(119, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View CD/PF option of 'In Discussion' project: TC72
	@Test(enabled = false)
	public void TC72() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View Pub Support option of 'In Discussion' project: TC73
	@Test(enabled = false)
	public void TC73() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewPubSupport(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewPubSupport_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Manage Finance option of 'In Discussion' project: TC74
	@Test(enabled = false)
	public void TC74() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Change SOW option of 'In Discussion' project: TC76
	@Test(enabled = false)
	public void TC76() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Expense option of 'In Discussion' project: TC78
	@Test(enabled = false)
	public void TC78() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Show History option of 'In Discussion' project: TC79
	@Test(enabled = false)
	public void TC79() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(119, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Propose Closure option of 'Unallocated' project when lineitem not confirmed: TC81
	@Test(enabled = false)
	public void TC81() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 137, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(137, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject_LineitemScheduled_Negative(137, 4);
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectProposeClosureNegative_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Propose Closure option of 'Unallocated' project: TC82
	@Test(enabled = false)
	public void TC82() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(137, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject(137, 4); //Searching already confirmed project in TC81
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProposeClosureProject_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to View Project Details of 'Unallocated' project: TC83
	@Test(enabled = false)
	public void TC83() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 139, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(139, 4);
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to put 'Unallocated' project On Hold: TC84
	@Test(enabled = false)
	public void TC84() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);		
		ObjectsOfTestActionsClass.ProjectOnHold(139, 4); //Searching already confirmed project in TC81
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectOnHold_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to put On Hold project back to 'Unallocated': TC85
	@Test(enabled = false)
	public void TC85() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.ProjectOffHold(139, 4); //Searching already confirmed project in TC81
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectOffHoldToUnallocated_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Edit 'Unallocated' project: TC86
	@Test(enabled = false)
	public void TC86() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Communications option of 'Unallocated' project: TC87
	@Test(enabled = false)
	public void TC87() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Timeline option of 'Unallocated' project: TC89
	@Test(enabled = false)
	public void TC89() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Go to Allocation option of 'Unallocated project: TC90
	@Test(enabled = false)
	public void TC90() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'Unallocated' project: TC91
	@Test(enabled = false)
	public void TC91() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(139, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View CD/PF option of 'Unallocated' project: TC92
	@Test(enabled = false)
	public void TC92() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View Pub Support option of 'Unallocated' project: TC93
	@Test(enabled = false)
	public void TC93() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewPubSupport(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewPubSupport_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Manage Finance option of 'Unallocated' project: TC94
	@Test(enabled = false)
	public void TC94() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Change SOW option of 'Unallocated' project: TC96
	@Test(enabled = false)
	public void TC96() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Expense option of 'Unallocated' project: TC98
	@Test(enabled = false)
	public void TC98() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Show History option of 'Unallocated' project: TC99
	@Test(enabled = false)
	public void TC99() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(139, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}


	//To validate whether user is able to perfoem CS Audit of 'CS Audit' project: TC101
	@Test(enabled = false)
	public void TC101() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 159, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(159, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(159, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject(159, 4);
		ObjectsOfTestActionsClass.CSAudit(159, 4);
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCSAudit_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to View Project Details of 'CS Audit' project: TC102
	@Test(enabled = false)
	public void TC102() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 160, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(160, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(160, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject(160, 4);
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Edit 'CS Audit' project: TC103
	@Test(enabled = false)
	public void TC103() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Communications option of 'CS Audit' project: TC104
	@Test(enabled = false)
	public void TC104() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}	

	//To validate whether user is able to click on Timeline option of 'CS Audit' project: TC106
	@Test(enabled = false)
	public void TC106() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Go to Allocation option of 'CS Audit project: TC107
	@Test(enabled = false)
	public void TC107() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'CS Audit' project: TC108
	@Test(enabled = false)
	public void TC108() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(160, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View CD/PF option of 'CS Audit' project: TC109
	@Test(enabled = false)
	public void TC109() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Manage Finance option of 'CS Audit' project: TC110
	@Test(enabled = false)
	public void TC110() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Change SOW option of 'CS Audit' project: TC112
	@Test(enabled = false)
	public void TC112() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Expense option of 'CS Audit' project:TC114
	@Test(enabled = false)
	public void TC114() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Show History option of 'CS Audit' project: TC115
	@Test(enabled = false)
	public void TC115() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(160, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	
	//To validate whether user is able to perform Finance Audit of 'Finance Audit' project: TC116
	@Test(enabled = false)
	public void TC116() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 176, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(176, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(176, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject(176, 4);
		ObjectsOfTestActionsClass.CSAudit(176, 4);
		//Lineitem should be invoiced
		//Intergration with FD to make lineitem Invoiced		
		ObjectsOfTestActionsClass.FinanceAudit(176, 4);
		//validation condition		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCSAudit_ValPoint));
		//validation condition
		//ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to View Project Details of 'Finance Audit' project: TC117
	@Test(enabled = false)
	public void TC117() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 177, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(177, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(177, 4);
		ObjectsOfTestActionsClass.ProposeCloseProject(177, 4);
		ObjectsOfTestActionsClass.CSAudit(177, 4);
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Edit 'Finance Audit' project: TC118
	@Test(enabled = false)
	public void TC118() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Communications option of 'Finance Audit' project: TC119
	@Test(enabled = false)
	public void TC119() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}	

	//To validate whether user is able to click on Timeline option of 'Finance Audit' project: TC121
	@Test(enabled = false)
	public void TC121() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Go to Allocation option of 'Finance Audit' project: TC122
	@Test(enabled = false)
	public void TC122() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'Finance Audit' project: TC123
	@Test(enabled = false)
	public void TC123() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(177, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on View CD/PF option of 'Finance Audit' project: TC124
	@Test(enabled = false)
	public void TC124() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Manage Finance option of 'Finance Audit' project: TC125
	@Test(enabled = false)
	public void TC125() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Change SOW option of 'Finance Audit' project: TC127
	@Test(enabled = false)
	public void TC127() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Expense option of 'Finance Audit' project: TC129
	@Test(enabled = false)
	public void TC129() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Show History option of 'Finance Audit' project: TC130
	@Test(enabled = false)
	public void TC130() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(177, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to View Project Details of 'On Hold' project: TC131	
	@Test(enabled = false)
	public void TC131() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);	
		ObjectsOfTestActionsClass.CreateDelNonStandardProjectThroughAddProjectButton(7, 4, 193, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(193, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProjectLineitem(193, 4);
		ObjectsOfTestActionsClass.ProjectOnHold(193, 4); //Searching already confirmed project in TC81
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to Edit 'OnHold' project: TC132
	@Test(enabled = false)
	public void TC132() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Communications option of 'On Hold' project: TC133
	@Test(enabled = false)
	public void TC133() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Timeline option of 'On Hold' project: TC135
	@Test(enabled = false)
	public void TC135() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Go to Allocation option of 'On Hold' project: TC136
	@Test(enabled = false)
	public void TC136() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'On Hold' project: TC137
	@Test(enabled = false)
	public void TC137() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(193, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on View CD/PF option of 'On Hold' project: TC138
	@Test(enabled = false)
	public void TC138() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on View Pub Support option of 'On Hold' project: TC139
	@Test(enabled = false)
	public void TC139() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewPubSupport(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewPubSupport_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Manage Finance option of 'On Hold' project: TC140
	@Test(enabled = false)
	public void TC140() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Change SOW option of 'On Hold' project: TC142
	@Test(enabled = false)
	public void TC142() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Expense option of 'On Hold' project: TC144
	@Test(enabled = false)
	public void TC144() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Show History option of 'On Hold' project: TC145
	@Test(enabled = false)
	public void TC145() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(193, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
		
	//HOURLY PROJECT
	//To validate whether user is able to Confirm 'In Discussion' project: TC146
	@Test(enabled = false)
	public void TC146() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyNonStandardProjectThroughAddProjectButton(7, 4, 210, 4);
		ObjectsOfTestActionsClass.Test_ConfirmProject(210, 4);
		//validation condition		
		wait.until(ExpectedConditions.visibilityOfElementLocated(ConfirmProject_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to View project details of 'In Discussion' project: TC147
	@Test(enabled = false)
	public void TC147() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyNonStandardProjectThroughAddProjectButton(7, 4, 211, 4);
		ObjectsOfTestActionsClass.Test_ViewProjectDetails(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewProject_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Edit 'In Discussion' project: TC148
	@Test(enabled = false)
	public void TC148() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_EditProject(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(EditProject_Valoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Communications option of 'In Discussion' project: TC149
	@Test(enabled = false)
	public void TC149() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectCommunications(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCommunications_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Timeline option of 'In Discussion' project: TC151
	@Test(enabled = false)
	public void TC151() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectTimeline(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to click on Go to Allocation option of 'In Discussion' project: TC152
	@Test(enabled = false)
	public void TC152() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectGoToAllocation(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectTimeline_ValPoint));		
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Project Scope option of 'In Discussion' project: TC153
	@Test(enabled = false)
	public void TC153() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectScope(211, 4);
		//validation condition
		//wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectScope_ValPoint));	//is not working	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on View CD/PF option of 'In Discussion' project: TC154
	@Test(enabled = false)
	public void TC154() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ViewProjectCDsPFs(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectViewCDsPFs_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Manage Finance option of 'In Discussion' project: TC155
	@Test(enabled = false)
	public void TC155() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectManageFinance(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectManageFinance_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Change SOW option of 'In Discussion' project: TC157
	@Test(enabled = false)
	public void TC157() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectChangeSOW(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectChangeSOW_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Expense option of 'In Discussion' project: TC159
	@Test(enabled = false)
	public void TC159() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectExpense(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectExpense_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}

	//To validate whether user is able to click on Show History option of 'In Discussion' project: TC160
	@Test(enabled = false)
	public void TC160() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.Test_ProjectShowHistory(211, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectShowHistory_ValPoint));
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();
	}
	
	//To validate whether user is able to Cancel 'In Discussion' project: TC161
	@Test(enabled = true)
	public void TC161() throws IOException, InterruptedException{
		OjectsOfLoginClass.Launch();
		OjectsOfLoginClass.LoginFunctionDataDriven(1, 0, 1, 1);
		ObjectsOfTestActionsClass.CreateHourlyNonStandardProjectThroughAddProjectButton(7, 4, 225, 4);
		ObjectsOfTestActionsClass.CancelProject(225, 4);
		//validation condition
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProjectCancel_ValPoint));	
		//validation condition
		ObjectsOfBaseClass.CloseBrowser();				
	}
	
	
	
	
	
	
	
	
	
	

	

	/*
	 //To validate whether user is able to perform CS Audit on a project	
	@Test
	public void TC_PeformCSAuditOnProject() throws InterruptedException{		
		ObjectsOfTestActionsClass.Login();
		//ObjectsOfTestActionsClass.PMNavigation();
		//ObjectsOfTestActionsClass.SwitchToPMPage();
		ObjectsOfTestActionsClass.CSAudit();	
		ObjectsOfBaseClass.CloseBrowser();			
	 */
}
