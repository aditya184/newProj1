package allModulesPkg;

import org.testng.annotations.Test;

public class QMS_TestClass {

	Login ObjectsOfLoginClass = new Login();
	QMS_ObjectClass ObjectsOfQMSObjectClass = new QMS_ObjectClass();
	BaseClass ObjectsOgBaseClass = new BaseClass();	

	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Jun");		
	}
	
	@Test(priority = 2, enabled = true)
	public void QMSNavigation() throws InterruptedException{
		ObjectsOfQMSObjectClass.Navigation();		
	}
	
	@Test(priority = 3, enabled = true)
	public void SwitchToQMSPage() throws InterruptedException{
		ObjectsOfQMSObjectClass.Navigation();	
		ObjectsOfQMSObjectClass.SwitchTab();
	}

	@Test(priority = 3, enabled = false)
	public void SwitchToReviewerTab() throws InterruptedException{
		ObjectsOfQMSObjectClass.SwitchToReviewerTab();
	}
	
	@Test(priority = 3, enabled = false)
	public void SwitchToFeedbackForMeTab() throws InterruptedException{
		ObjectsOfQMSObjectClass.SwitchToFeedbackForMeTab();
	}
	
	@Test(priority = 3, enabled = false)
	public void SwitchToAdminScorecardTab() throws InterruptedException{
		ObjectsOfQMSObjectClass.SwitchToAdminScorecardsTab();
	}
	
	@Test(priority = 3, enabled = false)
	public void SwitchToClientFeedbackCDTab() throws InterruptedException{
		ObjectsOfQMSObjectClass.SwitchToClientFeedbackCDTab();
	}
	
	@Test(priority = 3, enabled = false)
	public void SwitchToClientFeedbackPFTab() throws InterruptedException{
		ObjectsOfQMSObjectClass.SwitchToClientFeedbackPFTab();
	}
	
	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByLast10Days() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Last 10");		
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByLast20Days() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Last 20");		
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByLast30Days() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Last 30");		
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear1() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 1"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear2() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 2"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear3() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 3"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear4() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 4"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear5() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2019"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 1"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear6() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2019"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 2"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear7() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2019"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 3"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void ManagerViewDataByYear8() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2019"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 4"); //datadriven
	}

	@Test(priority = 4, enabled = false)
	public void FeedbackForMeDataByYear() throws InterruptedException{
		ObjectsOfQMSObjectClass.FeedbackForMeData("Year");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
	}
	
	@Test(priority = 4, enabled = false)
	public void FeedbackForMeDataByQuarter() throws InterruptedException{
		ObjectsOfQMSObjectClass.FeedbackForMeData("Date range");	
		ObjectsOfQMSObjectClass.SelectYear("2020"); //data driven
		ObjectsOfQMSObjectClass.SelectQuarter("Quarter 4"); 
	}
	
	@Test(priority = 4, enabled = false)
	public void FeedbackForMeDataByDateRange() throws InterruptedException{
		ObjectsOfQMSObjectClass.FeedbackForMeDateRange("DateRange", "1-Nov 2020", "30-Nov 2020");	
	}
	
	@Test(priority = 4, enabled = false)
	public void ManagerViewEnterFeedBack() throws InterruptedException{
		ObjectsOfQMSObjectClass.ManagerViewProvideFeedback();
	}
	
	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackMIL() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("Write","CLE22-ORP-200261 Kick Off Write","MIL");
	}

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackPOSTER_NW() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","POSTER_NW");
	}

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackMANUSCRIPT_NW() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","MANUSCRIPT_NW");

	}

	@Test(priority = 4, enabled = true)
	public void AdminViewProvideFeedbackABSTRACT_NW() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","ABSTRACT_NW");

	}

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackSLIDEDECK_NW() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","SLIDE DECK_NW");
	}

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackEDITING() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","EDITING");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackWrite() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("Write","CLE22-ABS-200281 Kick Off Write 2 - CEP","Write");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackQC() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","QC");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackRegulatoryQC() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","Regulatory QC");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackMEDCOMM() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","MEDCOMM");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackCER() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","CER");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackBASICTEMPLATE() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","BASIC TEMPLATE");
	}	

	@Test(priority = 4, enabled = false)
	public void AdminViewProvideFeedbackGALLEYPROOFS() throws InterruptedException{
		ObjectsOfQMSObjectClass.AdminViewProvideRatingQC("QC","RTB17-CDT-201398 Final Draft QC","GALLEY PROOFS");
	}	

	@Test(priority = 5, enabled = false)
	public void UpdateAndCloseCDwithSS() throws InterruptedException{
		ObjectsOfQMSObjectClass.ClientFeedbackCDUpdateAndClose("PRA08-ABS-201609", "SS", "Internal", "High", "ATD issues"); //create all P&C scenarios
	}

	@Test(priority = 6, enabled = false)
	public void DeleteCDReason1() throws InterruptedException{
		ObjectsOfQMSObjectClass.ClientFeedbackCDDelete(" ", "Duplicate Entry");
	}
	
	@Test(priority = 6, enabled = false)
	public void DeleteCDReason2() throws InterruptedException{
		ObjectsOfQMSObjectClass.ClientFeedbackCDDelete(" ", "Incorrect CD");
	}

	
	




}
