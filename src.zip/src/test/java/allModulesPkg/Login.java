package allModulesPkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {

	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Actions act;
	XSSFWorkbook wb;
	By NextButton = By.xpath("//input[@id='idSIButton9']");
	By Username = By.xpath("//input[@name='loginfmt']");
	By PasswordTextBox = By.xpath("//input[@id='passwordInput']");
	By SignIn = By.xpath("//span[@id='submitButton']");
	By SigninPopup = By.xpath("//input[@id='idSIButton9']");
	By InvalidCredentials_ValPoint = By.xpath("//span[@id='errorText' and contains(text(), 'Incorrect user ID or password')]"); 

	//@Test(priority = 1, enabled = true)
	public void Launch(){
		System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");
		System.setProperty("webdriver.chrome.driver", "D:\\Aditya\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		act = new Actions(driver);
	}

	//@Test(priority = 2, enabled = true)
	public void LoginFunction(String ID, String Password){
		driver.get("https://cactusglobal.sharepoint.com/sites/medcomqa/dashboard#/projectMgmt/allProjects");
		wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NextButton));
		driver.findElement(Username).sendKeys(ID);	
		driver.findElement(NextButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PasswordTextBox));
		driver.findElement(PasswordTextBox).sendKeys(Password);
		driver.findElement(SignIn).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SigninPopup));
		driver.findElement(SigninPopup).click();	
	}

	public void readCredentialsFromProperties() throws IOException {
		Properties prop = readPropertiesFile("config.properties");
		driver.get("https://cactusglobal.sharepoint.com/sites/medcomqa/dashboard#/projectMgmt/allProjects");
		wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NextButton));
		driver.findElement(Username).sendKeys(prop.getProperty("username"));	
		driver.findElement(NextButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PasswordTextBox));
		driver.findElement(PasswordTextBox).sendKeys(prop.getProperty("password"));
		driver.findElement(SignIn).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SigninPopup));
		driver.findElement(SigninPopup).click();
	}
	public void LoginFunctionDataDriven(int UNrow, int UNcolumn, int PWrow, int PWcolumn) throws IOException{
		wb = getExcel();
		XSSFSheet ws=wb.getSheet("Login");
		driver.get("https://cactusglobal.sharepoint.com/sites/medcomqa/dashboard#/projectMgmt/allProjects");
		wait = new WebDriverWait(driver,200);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NextButton));
		driver.findElement(Username).sendKeys(ws.getRow(UNrow).getCell(UNcolumn).getStringCellValue());	
		driver.findElement(NextButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PasswordTextBox));
		driver.findElement(PasswordTextBox).sendKeys(ws.getRow(PWrow).getCell(PWcolumn).getStringCellValue());
		driver.findElement(SignIn).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SigninPopup));
		driver.findElement(SigninPopup).click();	

	}
	public Properties readPropertiesFile(String fileName) throws IOException {
		InputStream inputStream = null;
		Properties prop = new Properties();
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
			}
		}catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return prop;
		}

 public XSSFWorkbook getExcel() throws IOException {
	 if(wb!=null) {
		 return wb;
	 }else {
		 FileInputStream fis=new FileInputStream("D:\\Aditya\\AutomationSuite_AllModules.xlsx");	
		 wb =new XSSFWorkbook(fis);
		 return wb;
	 }
 }
 
 public void ForInvalidLoginFunctionDataDriven(int UNrow, int UNcolumn, int PWrow, int PWcolumn) throws IOException{
		FileInputStream fis=new FileInputStream("D:\\Aditya\\AutomationSuite_AllModules.xlsx");	
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet ws=wb.getSheet("Login");

		driver.get("https://cactusglobal.sharepoint.com/sites/medcomqa/dashboard#/projectMgmt/allProjects");
		wait = new WebDriverWait(driver,200);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NextButton));
		driver.findElement(Username).sendKeys(ws.getRow(UNrow).getCell(UNcolumn).getStringCellValue());	
		driver.findElement(NextButton).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(PasswordTextBox));
		driver.findElement(PasswordTextBox).sendKeys(ws.getRow(PWrow).getCell(PWcolumn).getStringCellValue());
		driver.findElement(SignIn).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(InvalidCredentials_ValPoint));
		driver.findElement(InvalidCredentials_ValPoint).click();	
	}
}
