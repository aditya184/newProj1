package allModulesPkg;

import java.text.ParseException;

import org.testng.Assert;
import org.testng.annotations.Test;

public class LeaveCalendar_TestClass {
	
	Login ObjectsOfLoginClass = new Login();
	LeaveCalendar_ObjectClass ObjectsOfLeaveCalendarObjectClass = new LeaveCalendar_ObjectClass();
	BaseClass ObjectsOgBaseClass = new BaseClass();	
	
	
	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Apr");	
	}
	
	@Test(priority = 2, enabled = true)
	public void LeaveCalendarNavigation() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.Navigation();
		
	}
	
	@Test(priority = 3, enabled = true)
	public void SwitchToLeaveCalendarPage() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.SwitchTab();
	}
	
	@Test(priority = 4, enabled = true)
	public void GetTotalLeaves() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.TotalLeaves();
	}
	
	
	@Test(priority = 5, enabled = true)
	public void GetTotalFullDayLeaves() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.FullDaylLeaves();
	}
	
	
	@Test(priority = 6, enabled = true)
	public void GetTotalHalfDayLeaves() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.HalfDaylLeaves();
	}
	
	//This method is not required when started working with test.xml file as we can directly include from class
	@Test(priority = 7, enabled = true)
	public void ApplyLeaveThroughMyDashboard(String leaveType,String toDate,String fromDate) throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
		ObjectsOfLeaveCalendarObjectClass.ApplyLeave(leaveType,toDate,fromDate);
		ObjectsOfLeaveCalendarObjectClass.Validation();		
	}
	
//	@Test
//	public void ValidateApplyLeave(String leaveType,String toDate,String fromDate) throws InterruptedException{
//		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
//		ObjectsOfLeaveCalendarObjectClass.ApplyLeave(leaveType,toDate,fromDate);
//	}
	
	@Test
	public void ShowAppliedLeave(String leaveType, String date) throws InterruptedException, ParseException {
		ObjectsOfLeaveCalendarObjectClass.ShowLeave(leaveType,date);
	}
	
	@Test
	public void ValidateDeletedLeave(String date) throws InterruptedException, ParseException {
		ObjectsOfLeaveCalendarObjectClass.ValidateDeletedLeave(date);
	}
	
	@Test
	public void DeleteLeaveThroughMyDashboard(String leaveType,String date) throws InterruptedException, ParseException{
		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
		ObjectsOfLeaveCalendarObjectClass.DeleteLeave(leaveType,date);
		ObjectsOfLeaveCalendarObjectClass.Validation();		
	}
	
	@Test
	public void ApplyLeaveOnFriday(String leaveType,String date) throws InterruptedException, ParseException{
		String day = ObjectsOgBaseClass.dayOfWeek(date);
		Assert.assertEquals(day,"Friday");
		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
		ObjectsOfLeaveCalendarObjectClass.ApplyLeave(leaveType, date, date);
		ObjectsOfLeaveCalendarObjectClass.Validation();		
	}
	
	@Test
	public void ApplyLeaveOnMonday(String leaveType,String date) throws InterruptedException, ParseException{
		String day = ObjectsOgBaseClass.dayOfWeek(date);
		Assert.assertEquals(day,"Monday");
		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
		ObjectsOfLeaveCalendarObjectClass.ApplyLeave(leaveType, date, date);
		ObjectsOfLeaveCalendarObjectClass.Validation();		
	}
	
//	@Test
//	public void ApplyLeaveOnBothMondayAndFriday(String leaveType) throws InterruptedException, ParseException{
//		ApplyLeaveOnMonday(leaveType);
//		ApplyLeaveOnFriday(leaveType);
//	}
	
	@Test
	public void validateLeaveCalendarPageElements() throws InterruptedException {
		ObjectsOfLeaveCalendarObjectClass.LeaveCalendarPageElements();
	}
	
	@Test
	public void MyDashboardNavigation() throws InterruptedException{
		ObjectsOfLeaveCalendarObjectClass.MyDashBoardNavigation();
	}
	
	
	
	

}
