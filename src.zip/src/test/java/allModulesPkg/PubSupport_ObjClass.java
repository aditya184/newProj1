package allModulesPkg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class PubSupport_ObjClass extends Login {
	BaseClass ObjectsOfBaseClass = new BaseClass();
	By Username = By.xpath("//input[@name='loginfmt']");
	By NextButton = By.xpath("//input[@id='idSIButton9']");
	By Password = By.xpath("//input[@id='passwordInput']");
	By SignIn = By.xpath("//span[@id='submitButton']");
	By SigninPopup = By.xpath("//input[@id='idSIButton9']");
	By NavigateButton = By.xpath("//i[@class='pi pi-list sidebar-icon']");
	By PubS = By.xpath("//a[text()='Publication Support']");
	By PCodeBox = By.xpath("//th[@ng-reflect-ng-switch='ProjectCode']//input[@type='text']");
	By pMenu = By.xpath("//i[@class='pi pi-ellipsis-v']");
	By AddJCoption = By.xpath("//span[text()='Add Journal / Conference']");
	By AddAUTHoption = By.xpath("//span[text()='Add Authors']");
	By UpdateAUForms = By.xpath("//span[text()='Update Author forms & emails']");
	By Type = By.xpath("//p-dropdown[@formcontrolname='EntryType']//label");
	By List = By.xpath("//p-dropdown[@formcontrolname='jcLineItem']//label");
	By Milestone = By.xpath("//p-dropdown[@formcontrolname='Milestone']//label");
	By SubmitB = By.xpath("//button[@label='Submit']");
	By UpdateButton = By.xpath("//span[text()='Update']");

	// Code Added by Arvind 
	By PubSupportStatusBox = By.xpath("//th[@ng-reflect-ng-switch='PubSupportStatus']//input[@type='text']");
	By EditJConfClick = By.xpath("//span[text()='Edit Journal / Conference']");
	By ConfUserName = By.xpath("//input[@formcontrolname='UserName']");
	By ConfPassword = By.xpath("//input[@formcontrolname='Password']");
	By UpdateB = By.xpath("//button[@label='Update']");
	By CongressDate = By.xpath("//p-calendar[@formcontrolname='CongressDate']//button");
	By SubmissionDeadline = By.xpath("//p-calendar[@formcontrolname='AbstractSubmissionDeadline']//button");
	By PComments = By.xpath("//textarea[@formcontrolname='Comments']");
	By CancelJournceConf = By.xpath("//span[text()='Cancel Journal Conference']");
	By YesButton = By.xpath("//span[text()='Yes']");

	// Add Author
	By FirstName = By.xpath("//input[@formcontrolname='FirstName']");
	By LastName = By.xpath("//input[@formcontrolname='LastName']");
	By Comments = By.xpath("//textarea[@formcontrolname='Comments']");
	By HighestDegree = By.xpath("//input[@formcontrolname='HighestDegree']");
	By EmailAddress = By.xpath("//input[@formcontrolname='EmailAddress']");
	By Address = By.xpath("//input[@formcontrolname='Address']");
	By Affiliation = By.xpath("//textarea[@formcontrolname='Affiliation']");
	By Phone_x0020_No = By.xpath("//input[@formcontrolname='Phone_x0020_No']");
	By Fax = By.xpath("//input[@formcontrolname='Fax']");
	By AuthorType = By.xpath("//select[@formcontrolname='AuthorType']");
	By AddButton = By.xpath("//span[text()='Add']");
	By SelectAuthor = By.xpath("//select[@formcontrolname='existingAuthorList']");
	By UploadFiles = By.xpath("//input[@formcontrolname='file']");
	By UpdateAuthorFormsAndEmailsClick = By.xpath("//span[text()='Update Author forms & emails']");
	By UpdateJournalRequirementClick = By.xpath("//span[text()='Update Journal Requirement']");
	By UpdateDecisionDetailsClick = By.xpath("//span[text()='Update Decision details']");
	By RevertDecisionDetailsClick = By.xpath("//span[text()='Revert Decision']");
	By UploadFilesUpdateReq = By.xpath("//input[@formcontrolname='JournalRequirementResponse']");
	By ExpextedReviewPeriodField = By.xpath("//input[@formcontrolname='ExpectedReviewPeriod']");
	By IF = By.xpath("//input[@formcontrolname='IF']");
	By ImpactFactorField = By.xpath("//input[@formcontrolname='ImpactFactor']");
	By RejectionRateField = By.xpath("//input[@formcontrolname='RejectionRate']");
	By CommentsField = By.xpath("//textarea[@formcontrolname='Comments']");
	By JournalEditorInfoField = By.xpath("//textarea[@formcontrolname='JournalEditorInfo']");
	By AddJournalConferencePlusClick = By
			.xpath("//p-dialog[@header='Add Journal conference details']//i[@class='pi pi-plus-circle']");
	By ConferenceNameField = By.xpath("//textarea[@formcontrolname='ConferenceName']");
	By ConferenceDateField = By.xpath("//p-calendar[@formcontrolname='ConferenceDate']//button");
	By SubmissionDeadlineField = By.xpath("//p-calendar[@formcontrolname='SubmissionDeadline']//button");
	By CreateB = By.xpath("//button[@label='Create']");
	By SuccessMsg = By.xpath("//div[text()='Success Message']");
	By JournalNameField = By.xpath("//textarea[@formcontrolname='JournalName']");
	By DecisionSelectField = By.xpath("//select[@formcontrolname='Decision']");
	By AuthorDetailsLinkClick = By.xpath("//div[@class='pubsuppotTable']//td//a[text()='Author Details']");
	By AuthorsTabClick = By.xpath("//p-tabview//span[text()='Authors']");
	By AuthorsFormsTabClick = By.xpath("//p-tabview//span[text()='Authors Forms']");
	By CloseAuthorsFormTab = By.xpath("//p-dynamicdialog//a[@tabindex='0']");
	By ExpandProjectRightArrow = By.xpath("//a//i[@class='pi pi-chevron-right']");
	By CollapseProjectDownArrow = By.xpath("//a//i[@class='pi pi-chevron-down']");
	By ViewDetailsLinkClick = By.xpath("//a[text()=' View details ']");
	By ReplaceDocumentUpload = By.xpath("//input[@formcontrolname='documentFile']");
	// Code Ended by Arvind 
	public void Navigation() throws InterruptedException, IOException {
		TimeUnit.SECONDS.sleep(2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(NavigateButton));
		driver.findElement(NavigateButton).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(PubS).click();
	}

	public void SearchProjectCode(String projectCode) throws IOException, InterruptedException {
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		wait.until(ExpectedConditions.visibilityOfElementLocated(PCodeBox));
		driver.findElement(PCodeBox).sendKeys(projectCode);
		TimeUnit.SECONDS.sleep(3);
	}

	public void SearchPubSupportStatus(String status) throws IOException, InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(PubSupportStatusBox));
		driver.findElement(PubSupportStatusBox).sendKeys(status);
		TimeUnit.SECONDS.sleep(3);
	}

	public void CreateConference(String eDeliveyType, String eList, String eMilestone)
			throws InterruptedException, IOException {
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Type));
		driver.findElement(Type).click();
		By eDeliveryTypeValue = By.xpath("//span[text()='" + eDeliveyType + "']");
		driver.findElement(eDeliveryTypeValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(List));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(List).click();
		By eListValue = By.xpath("//span[text()='" + eList + "']");
		driver.findElement(eListValue).click();
		driver.findElement(Milestone).click();
		By eMilestoneValue = By.xpath("//span[text()='" + eMilestone + "']");
		driver.findElement(eMilestoneValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(SubmitB).click();
	}

	public void EditConference(String milestone, String userName, String password, String confDate, String subDate,
			String Comments) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(EditJConfClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ConfUserName));
		if (!isNullOrEmpty(milestone)) {
			driver.findElement(Milestone).click();
			By milestoneExcelValue = By.xpath("//span[text()='" + milestone + "']");
			driver.findElement(milestoneExcelValue).click();
		}
		if (!isNullOrEmpty(userName) && !driver.findElement(ConfUserName).getAttribute("value").equals(userName)) {
			driver.findElement(ConfUserName).clear();
			driver.findElement(ConfUserName).sendKeys(userName);
		} else {
			driver.findElement(ConfUserName).sendKeys("SPSupport");
		}
		if (!isNullOrEmpty(password) && !driver.findElement(ConfPassword).getAttribute("value").equals(password)) {
			driver.findElement(ConfPassword).clear();
			driver.findElement(ConfPassword).sendKeys(password);
		} else {
			driver.findElement(ConfPassword).sendKeys("SPSupport");
		}
		if (!isNullOrEmpty(Comments) && !driver.findElement(PComments).getAttribute("value").equals(Comments)) {
			driver.findElement(PComments).clear();
			driver.findElement(PComments).sendKeys(Comments);
		}
		if (!isNullOrEmpty(confDate)) {
			driver.findElement(CongressDate).click();
			ObjectsOfBaseClass.Datepicker(confDate);
			TimeUnit.SECONDS.sleep(1);
		}
		if (!isNullOrEmpty(subDate)) {
			driver.findElement(SubmissionDeadline).click();
			ObjectsOfBaseClass.Datepicker(subDate);
			TimeUnit.SECONDS.sleep(1);
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateB));
		driver.findElement(UpdateB).click();
	}

	public void CancelConference() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(CancelJournceConf).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(YesButton));
		driver.findElement(YesButton).click();
	}

	public void addAuthors(String eFirstName, String eLastName, String eComments, String eHighestDegree,
			String eEmailAddress, String eAddress, String eAffiliation, String ePhone_x0020_No, String eFax,
			String eAuthorType) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddAUTHoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(FirstName));
		if (!isNullOrEmpty(eFirstName)) {
			driver.findElement(FirstName).clear();
			driver.findElement(FirstName).sendKeys(eFirstName);
		}
		if (!isNullOrEmpty(eLastName)) {
			driver.findElement(LastName).clear();
			driver.findElement(LastName).sendKeys(eLastName);
		}
		if (!isNullOrEmpty(eComments)) {
			driver.findElement(Comments).clear();
			driver.findElement(Comments).sendKeys(eComments);
		}
		if (!isNullOrEmpty(eHighestDegree)) {
			driver.findElement(HighestDegree).clear();
			driver.findElement(HighestDegree).sendKeys(eHighestDegree);
		}
		if (!isNullOrEmpty(eEmailAddress)) {
			driver.findElement(EmailAddress).clear();
			driver.findElement(EmailAddress).sendKeys(eEmailAddress);
		}
		if (!isNullOrEmpty(eAddress)) {
			driver.findElement(Address).clear();
			driver.findElement(Address).sendKeys(eAddress);
		}
		if (!isNullOrEmpty(eAffiliation)) {
			driver.findElement(Affiliation).clear();
			driver.findElement(Affiliation).sendKeys(eAffiliation);
		}
		if (!isNullOrEmpty(ePhone_x0020_No)) {
			driver.findElement(Phone_x0020_No).clear();
			driver.findElement(Phone_x0020_No).sendKeys(ePhone_x0020_No);
		}
		if (!isNullOrEmpty(eFax)) {
			driver.findElement(Fax).clear();
			driver.findElement(Fax).sendKeys(eFax);
		}
		if (!isNullOrEmpty(eAuthorType)) {
			driver.findElement(AuthorType).click();
			By ExcelAuthorType = By.xpath("//option[text()='" + eAuthorType + "']");
			driver.findElement(ExcelAuthorType).click();
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(AddButton));
		driver.findElement(AddButton).click();
	}

	public void UpdateAuthors(String eFileName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(UpdateAuthorFormsAndEmailsClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateB));
		driver.findElement(By.id("myfile")).sendKeys(eFileName);
		driver.findElement(UpdateB).click();
	}

	public void SelectFromExistingAuthors(String eExistingAuthorProjectCode) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(UpdateAuthorFormsAndEmailsClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateB));
		Select drpDecisionDetails = new Select(driver.findElement(SelectAuthor));
		drpDecisionDetails.selectByVisibleText(eExistingAuthorProjectCode);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(UpdateB).click();
	}

	public void UpdateJournalRequirement(String eFileName) {
		driver.findElement(pMenu).click();
		driver.findElement(UpdateJournalRequirementClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(UploadFilesUpdateReq).sendKeys(eFileName);
		driver.findElement(SubmitB).click();
	}

	public void AddJournal(String eDeliveryType, String eList, String eMilestone, String eExpectedReviewPeriod,
			String eImpactFactor, String eRejectionRatio, String eJournalEditInfo)
			throws InterruptedException, IOException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Type));
		driver.findElement(Type).click();
		By eDeliveryTypeValue = By.xpath("//span[text()='" + eDeliveryType + "']");
		driver.findElement(eDeliveryTypeValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(List));
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(List).click();
		By eListValue = By.xpath("//span[text()='" + eList + "']");
		driver.findElement(eListValue).click();
		driver.findElement(Milestone).click();
		By eMilestoneValue = By.xpath("//span[text()='" + eMilestone + "']");
		driver.findElement(eMilestoneValue).click();
		driver.findElement(ExpextedReviewPeriodField).sendKeys(eExpectedReviewPeriod);
		driver.findElement(IF).sendKeys(eImpactFactor);
		driver.findElement(RejectionRateField).sendKeys(eRejectionRatio);
		driver.findElement(JournalEditorInfoField).sendKeys(eJournalEditInfo);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(SubmitB).click();
	}

	public void CreateConferenceByAddingNewConference(String eDeliveryType, String eConferenceName,
			String eConferenceDate, String eSubmissionDeadline, String eComments, String eMilestone)
			throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Type));
		driver.findElement(Type).click();
		By eDeliveryTypeValue = By.xpath("//span[text()='" + eDeliveryType + "']");
		driver.findElement(eDeliveryTypeValue).click();
		driver.findElement(AddJournalConferencePlusClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ConferenceNameField));
		driver.findElement(ConferenceNameField).sendKeys(eConferenceName);
		driver.findElement(ConferenceDateField).click();
		ObjectsOfBaseClass.Datepicker(eConferenceDate);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(SubmissionDeadlineField).click();
		ObjectsOfBaseClass.Datepicker(eSubmissionDeadline);
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(CommentsField).sendKeys(eComments);
		driver.findElement(CreateB).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		driver.findElement(List).click();
		By eListValue = By.xpath("//span[text()='" + eConferenceName + "']");
		driver.findElement(eListValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Milestone));
		driver.findElement(Milestone).click();
		By eMilestoneValue = By.xpath("//span[text()='" + eMilestone + "']");
		driver.findElement(eMilestoneValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(SubmitB).click();
	}

	public void CreateJournalByAddingNewJournal(String eDeliveryType, String eJournalName, String eExpectedReviewPeriod,
			String eImpactFactor, String eRejectionRatio, String eComments, String eJournalEditorInfo,
			String eMilestone) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Type));
		driver.findElement(Type).click();
		By eDeliveryTypeValue = By.xpath("//span[text()='" + eDeliveryType + "']");
		driver.findElement(eDeliveryTypeValue).click();
		driver.findElement(AddJournalConferencePlusClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(JournalNameField));
		driver.findElement(JournalNameField).sendKeys(eJournalName);
		driver.findElement(ExpextedReviewPeriodField).sendKeys(eExpectedReviewPeriod);
		driver.findElement(ImpactFactorField).sendKeys(eImpactFactor);
		driver.findElement(RejectionRateField).sendKeys(eRejectionRatio);
		driver.findElement(CommentsField).sendKeys(eComments);
		driver.findElement(JournalEditorInfoField).sendKeys(eJournalEditorInfo);
		driver.findElement(CreateB).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
		driver.findElement(List).click();
		By eListValue = By.xpath("//span[text()='" + eJournalName + "']");
		driver.findElement(eListValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Milestone));
		driver.findElement(Milestone).click();
		By eMilestoneValue = By.xpath("//span[text()='" + eMilestone + "']");
		driver.findElement(eMilestoneValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(SubmitB).click();
	}

	public void UpdateDecisionDetails(String eFileName, String eDecision) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(UpdateDecisionDetailsClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(UpdateB));
		driver.findElement(UploadFiles).sendKeys(eFileName);
		Select drpDecisionDetails = new Select(driver.findElement(DecisionSelectField));
		drpDecisionDetails.selectByValue(eDecision);
		// drpDecisionDetails.getOptions().isEmpty();
		driver.findElement(UpdateB).click();
	}

	public void RevertDecision() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(RevertDecisionDetailsClick).click();
	}

	public void VerifyAuthors(String eProjectCode, String eName, String eHighestDegree, String eAddress,
			String eAffiliation, String eEmailAddress, String eAuthorType, String ePhoneNumber)
			throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(AuthorDetailsLinkClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//span[text()='Authors & Authors Form - " + eProjectCode + "']")));
		driver.findElement(AuthorsTabClick).click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//p-tabpanel//td[text()='" + eName + "']")));
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eName + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eHighestDegree + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eAddress + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eAffiliation + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eEmailAddress + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + eAuthorType + "']")).isDisplayed();
		driver.findElement(By.xpath("//p-tabpanel//td[text()='" + ePhoneNumber + "']")).isDisplayed();
		driver.findElement(CloseAuthorsFormTab).click();
	}

	public void VerifyAuthorsForms(String eProjectCode, String eFileName) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(AuthorDetailsLinkClick).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//span[text()='Authors & Authors Form - " + eProjectCode + "']")));
		driver.findElement(AuthorsFormsTabClick).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.xpath("//p-tabpanel//a[text()='" + eFileName + "']")).isDisplayed();
		driver.findElement(CloseAuthorsFormTab).click();
	}

	public void VerifyConferenceDetails(String eConferenceName, String eDeliveryType, String eMilestone,
			String eConfDate, String eSubDate, String eUN, String ePwd, String eComments) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(ExpandProjectRightArrow).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ViewDetailsLinkClick));
		driver.findElement(ViewDetailsLinkClick).click();
		if (!isNullOrEmpty(eConferenceName)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span[contains(text(),'"+ eConferenceName + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eDeliveryType)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span[contains(text(),'"+ eDeliveryType + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eMilestone)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span[contains(text(),'"+ eMilestone + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eConfDate)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span//b[contains(text(),'"+ eConfDate + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eSubDate)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span//b[contains(text(),'"+ eSubDate + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eUN)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span//b[contains(text(),'"+ eUN + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(ePwd)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span//b[contains(text(),'"+ ePwd + "')]")).isDisplayed();
		}
		if (!isNullOrEmpty(eComments)) {
			driver.findElement(By.xpath("//app-journal-conference-details//span//b[contains(text(),'"+ eComments + "')]")).isDisplayed();
		}
		driver.findElement(CollapseProjectDownArrow).click();
	}

	public void DocumentUploadDownload(int downloadFileCode, boolean IsDownload, String eFileName)
			throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(ExpandProjectRightArrow).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(ViewDetailsLinkClick));
		By JRDocumentDownload = By.xpath("//a[starts-with(@class, 'CLS_JR_Download')]");
		By JRDocumentUpload = By.xpath("//a[starts-with(@class, 'CLS_JR_Upload')]");
		By JRRDocumentDownload = By.xpath("//a[starts-with(@class, 'CLS_JRR_Download')]");
		By JRRDocumentUpload = By.xpath("//a[starts-with(@class, 'CLS_JRR_Upload')]");
		By SPDocumentDownload = By.xpath("//a[starts-with(@class, 'CLS_SP_Download')]");
		By SPDocumentUpload = By.xpath("//a[starts-with(@class, 'CLS_SP_Upload')]");
		By SCDocumentDownload = By.xpath("//a[starts-with(@class, 'CLS_SC_Download')]");
		By SCDocumentUpload = By.xpath("//a[starts-with(@class, 'CLS_SC_Upload')]");
		By DecisionDocumentDownload = By.xpath("//a[starts-with(@class, 'CLS_DC_Download')]");
		By DecisionDocumentUpload = By.xpath("//a[starts-with(@class, 'CLS_DC_Upload')]");
		By JSDownload = By.xpath("//a[starts-with(@class, 'CLS_JS_Download')]");
		By JSUpload = By.xpath("//a[starts-with(@class, 'CLS_JS_Upload')]");
		By PPDownload = By.xpath("//a[starts-with(@class, 'CLS_PP_Download')]");
		By PPUpload = By.xpath("//a[starts-with(@class, 'CLS_PP_Upload')]");
		By SubmissionDetailsLinkClick = By.xpath("//app-journal-conference-details//a[contains(text(),'Submission Details')]");
		
		if (!IsDownload) {
			downloadFileCode = downloadFileCode + 1;
		}
		switch (downloadFileCode) {
		case 1:
			driver.findElement(JRDocumentDownload).click();
			break;
		case 2:
			driver.findElement(JRDocumentUpload).click();
			break;
		case 3:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SPDocumentDownload));
			driver.findElement(SPDocumentDownload).click();
			break;
		case 4:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SPDocumentUpload));
			driver.findElement(SPDocumentUpload).click();
			break;
		case 5:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SCDocumentDownload));
			driver.findElement(SCDocumentDownload).click();
			break;
		case 6:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SCDocumentUpload));
			driver.findElement(SCDocumentUpload).click();
			break;
		case 7:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(DecisionDocumentDownload));
			driver.findElement(DecisionDocumentDownload).click();
			break;
		case 8:
			driver.findElement(SubmissionDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(DecisionDocumentUpload));
			driver.findElement(DecisionDocumentUpload).click();
			break;
		case 9:
			driver.findElement(JRRDocumentDownload).click();
			break;
		case 10:
			driver.findElement(JRRDocumentUpload).click();
			break;
		case 11:
			driver.findElement(ViewDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(JSDownload));
			driver.findElement(JSDownload).click();
			break;
		case 12:
			driver.findElement(ViewDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(JSUpload));
			driver.findElement(JSUpload).click();
			break;
		case 13:
			driver.findElement(ViewDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(PPDownload));
			driver.findElement(PPDownload).click();
			break;
		case 14:
			driver.findElement(ViewDetailsLinkClick).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(PPUpload));
			driver.findElement(PPUpload).click();
			break;
		}
		if (IsDownload && isNullOrEmpty(eFileName)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(SuccessMsg));
			driver.findElement(CollapseProjectDownArrow).click();
		} else {
			wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
			driver.findElement(ReplaceDocumentUpload).sendKeys(eFileName);
			TimeUnit.SECONDS.sleep(2);
			driver.findElement(SubmitB).click();
		}
	}

	public void IsMilestoneAvailable(String eDeliveryType) throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Type));
		driver.findElement(Type).click();
		By eDeliveryTypeValue = By.xpath("//span[text()='" + eDeliveryType + "']");
		driver.findElement(eDeliveryTypeValue).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Milestone));
		driver.findElement(Milestone).isDisplayed();
	}

	public void IsMilestoneMandatory() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(SubmitB).click();
		driver.findElement(By.xpath("//div[contains(text(),'Please select one of milestone & try again.')]"))
				.isDisplayed();

	}
	public void ValidateMilestones(String eMilestone) {
		List<String> eMilestoneList = new ArrayList<String>(Arrays.asList(eMilestone.split(",")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(pMenu));
		driver.findElement(pMenu).click();
		driver.findElement(AddJCoption).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(SubmitB));
		driver.findElement(Milestone).click();
		WebElement MilestoneUL = driver.findElement(By.xpath("//p-dropdown[@formcontrolname='Milestone']"));
		List<WebElement> MilestoneList = MilestoneUL.findElements(By.tagName("li"));
		for(int i=0; i<MilestoneList.size(); i++) {
			Assert.assertTrue(MilestoneList.get(i).getText().equals(eMilestoneList.get(i)));;
		}
	}

	public static boolean isNullOrEmpty(String str) {
		if (str != null && !str.isEmpty())
			return false;
		return true;
	}
}
