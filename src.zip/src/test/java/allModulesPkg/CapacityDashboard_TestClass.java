package allModulesPkg;

import java.text.ParseException;
import java.util.List;

import org.apache.xmlbeans.xml.stream.events.ElementTypeNames;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class CapacityDashboard_TestClass {


	Login ObjectsOfLoginClass = new Login();
	CapacityDashboard_ObjectClass ObjectsOfCapacityDashboardObjectClass = new CapacityDashboard_ObjectClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();	

	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Jun");
	}
	
	@Test(priority = 2, enabled = true)
	public void CapacityDashboardNavigation() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.Navigation();		
	}
	
	@Test(priority = 3, enabled = true)
	public void SwitchToCapacityDashboardPage() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.SwitchTab();
	}

	@Test(priority = 4, enabled = true)
	public void FetchCapacitySingleUser() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.ClearBuckerDropdown();
		ObjectsOfCapacityDashboardObjectClass.SelectBucket("Others");
		ObjectsOfCapacityDashboardObjectClass.ClearPracticeAreaDropdown();
		ObjectsOfCapacityDashboardObjectClass.SelectPracticeArea("Devices");
		ObjectsOfCapacityDashboardObjectClass.ClearSkillDropdown();
		ObjectsOfCapacityDashboardObjectClass.SelectSkill("Editor");
		ObjectsOfCapacityDashboardObjectClass.ClearResourceDropdown();
		ObjectsOfCapacityDashboardObjectClass.SelectReasource("Test SP");		
		ObjectsOfCapacityDashboardObjectClass.SelectTaskStatus("All");		
		ObjectsOfCapacityDashboardObjectClass.SelectReasourceType("On Job Resource");		
		ObjectsOfCapacityDashboardObjectClass.SelectStartEndDates("7-December 2020", "10-December 2020");
		ObjectsOfCapacityDashboardObjectClass.SearchAction();
	}

	@Test(priority = 5, enabled = true)
	public void GetTotalAllocatedHrs() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.TotalAllocatedHrs();
		
	}
	
	@Test(priority = 6, enabled = true)
	public void GetTotalSpentHrs() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.TotalSpent();		
	}
	
	@Test(priority = 7, enabled = true)
	public void GetTotalUnallocatedHrs() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.TotalUnallocatedHrs();	
	}
	
	@Test(priority = 8, enabled = true)
	public void GetTotalBenchHrs() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.TotalBenchHrs();		
	}
	
	@Test(priority = 9, enabled = true)
	public void ValidateElements() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.ValidateElements();
	}
	
	@Test(priority = 10, enabled = true)
	public void VerifyValueInFilters(String filter) throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.VerifyValueInFilters(filter);
	}
	
	@Test(priority = 11, enabled = true)
	public void ResetFilter() throws InterruptedException{
		ObjectsOfCapacityDashboardObjectClass.ResetFilter();
	}
	
	@Test(priority = 12, enabled = true)
	public void ValidationPoint() throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.ValidationPointAfterResetFilter();
	}
	
	@Test(priority = 13, enabled = true)
	public void DefaultFilters() throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.defaultFilters();
	}
	
	@Test(priority = 14, enabled = true)
	public void ValidateBucketFilterSelection(String Bucket) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.BucketFilterSelection(Bucket);
	}
	
	@Test(priority = 15, enabled = true)
	public void ValidatePracticeAreaFilterSelection(String PracticeArea) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.PracticeAreaFilterSelection(PracticeArea);
	}
	
	@Test(priority = 16, enabled = true)
	public void ValidateSkillFilterSelection(String Skill) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.SkillFilterSelection(Skill);
	}
	
	@Test(priority = 17, enabled = true)
	public void ValidateResourcesFilterSelection(String Resources) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.ResourcesFilterSelection(Resources);
	}
	
	@Test(priority = 18, enabled = true)
	public void SelectDates(String startDate, String endDate) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.SelectStartEndDates(startDate, endDate);
	}
	
	@Test(priority = 19, enabled = true)
	public void BucketSelection(String Bucket) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.SelectBucket(Bucket);
	}
	
	@Test(priority = 20, enabled = true)
	public void ClearBucketSelection() throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.ClearBuckerDropdown();
	}
	
	@Test(priority = 21, enabled = true)
	public void UserCapacityTasks(String date) throws InterruptedException {
		ObjectsOfCapacityDashboardObjectClass.UserAssignedDefaultTask(date);
	}
	
	@Test(priority = 22, enabled = true)
	public void UserAssignedDefaultTaskForMultipleLeave(String fromdate, String todate) throws InterruptedException, ParseException {
		ObjectsOfCapacityDashboardObjectClass.UserAssignedDefaultTaskForMultipleLeave(fromdate,todate);
	}
		
	@Test(priority = 23, enabled = true)
	public void ApplyBlockResource(String fromdate, String todate) throws InterruptedException, ParseException {
		ObjectsOfCapacityDashboardObjectClass.ApplyBlockResource(fromdate,todate);
	}
	
	@Test(priority = 24, enabled = true)
	public void ValidateAppliedBlockResourceForMultipleLeave(String fromdate, String todate) throws InterruptedException, ParseException {
		ObjectsOfCapacityDashboardObjectClass.ValidateAppliedBlockResourceForMultipleLeave(fromdate,todate);
	}
}
