package allModulesPkg;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class PubSupport_TestClass {
	Login ObjectsOfLoginClass = new Login();
	PubSupport_ObjClass ObjectsOfPubSupportClass = new PubSupport_ObjClass();
	BaseClass ObjectsOfBaseClass = new BaseClass();
	XSSFSheet ws;
	XSSFWorkbook wb;
	@Test(enabled = true)
	public void CreateConference(String eDeliveyType, String eList, String eMilestone)
			throws InterruptedException, IOException {
		ObjectsOfPubSupportClass.CreateConference(eDeliveyType, eList, eMilestone);
	}
	@Test(enabled = true)
	public void EditConferenceUserNamePassword() throws InterruptedException, IOException {
		String projectCode = ws.getRow(2).getCell(1).getStringCellValue();
		String userName = ws.getRow(2).getCell(5).getStringCellValue();
		String password = ws.getRow(2).getCell(6).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.EditConference(null, userName, password, null, null, null);
	}
	@Test(enabled = true)
	public void EditOtherConferenceProperties() throws IOException, InterruptedException {
		String userName = ws.getRow(3).getCell(5).getStringCellValue();
		String password = ws.getRow(3).getCell(6).getStringCellValue();
		String projectCode = ws.getRow(3).getCell(1).getStringCellValue();
		String milestones = ws.getRow(3).getCell(4).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		String conferenceDate = ws.getRow(3).getCell(7).getStringCellValue();
		String submissionDeadline = ws.getRow(3).getCell(8).getStringCellValue();
		String comments = ws.getRow(3).getCell(9).getStringCellValue();
		ObjectsOfPubSupportClass.EditConference(milestones, userName, password, conferenceDate, submissionDeadline,
				comments);
	}
	@Test(enabled = true)
	public void CancelConference() throws IOException, InterruptedException {
		String projectCode = ws.getRow(2).getCell(1).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.CancelConference();
	}
	@Test(enabled = true)
	public void addAuthors() throws IOException, InterruptedException {
		String projectCode = ws.getRow(11).getCell(1).getStringCellValue();
		String firstName = ws.getRow(11).getCell(2).getStringCellValue();
		String lastName = ws.getRow(11).getCell(3).getStringCellValue();
		String comments = ws.getRow(11).getCell(4).getStringCellValue();
		String highestDegree = ws.getRow(11).getCell(5).getStringCellValue();
		String emailAddress = ws.getRow(11).getCell(6).getStringCellValue();
		String address = ws.getRow(11).getCell(7).getStringCellValue();
		String affilation = ws.getRow(11).getCell(8).getStringCellValue();
		String phoneNumber = String.valueOf(ws.getRow(11).getCell(9).getNumericCellValue());
		String fax = String.valueOf(ws.getRow(11).getCell(10).getNumericCellValue());
		String type = ws.getRow(11).getCell(11).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.addAuthors(firstName, lastName, comments, highestDegree, emailAddress, address,
				affilation, phoneNumber, fax, type);
	}
	@Test(enabled = true)
	public void updateAuthors() throws IOException, InterruptedException {
		String projectCode = ws.getRow(16).getCell(1).getStringCellValue();
		String uploadFileName = ws.getRow(16).getCell(3).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.UpdateAuthors(uploadFileName);
	}
	@Test(enabled = false)
	public void selectFromExistingAuthors() throws IOException, InterruptedException {
		String projectCode = ws.getRow(16).getCell(1).getStringCellValue();
		String exitingProjectCode = ws.getRow(16).getCell(2).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.SelectFromExistingAuthors(exitingProjectCode);
	}
	@Test(enabled = false)
	public void updateJournalRequirements() throws IOException, InterruptedException {
		String projectCode = ws.getRow(16).getCell(1).getStringCellValue();
		String uploadFileName = ws.getRow(16).getCell(3).getStringCellValue();
		ObjectsOfPubSupportClass.SearchProjectCode(projectCode);
		ObjectsOfPubSupportClass.UpdateJournalRequirement(uploadFileName);
	}
}
