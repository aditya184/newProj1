package allModulesPkg;

import java.io.IOException;

import org.testng.annotations.Test;

public class Admin_TestClass {
	
	Login ObjectsOfLoginClass = new Login();
	Admin_ObjectClass ObjectsOfAdminObjectClass = new Admin_ObjectClass();
	BaseClass ObjectsOgBaseClass = new BaseClass();
	
	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException{
		ObjectsOfLoginClass.Launch();
		ObjectsOfLoginClass.LoginFunction("praveen.amancha@cactusglobal.com", "Zero@Jun");	
	}
	
	@Test(priority = 2, enabled = true)
	public void AdminNavigation() throws InterruptedException{
		ObjectsOfAdminObjectClass.Navigation();
		
	}
	
	@Test(priority = 3, enabled = true)
	public void SwitchToAdminPage() throws InterruptedException{
		ObjectsOfAdminObjectClass.SwitchTab();
	}

	@Test(priority = 4, enabled = false)
	public void AddNewClient() throws InterruptedException{
		ObjectsOfAdminObjectClass.AddNewClient("Test_CLE_DB2", "CLE24", "Test_NewDB");
	}
		
	@Test(priority = 5, enabled = false)
	public void EditClinetSingleField() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB2");
		ObjectsOfAdminObjectClass.EditClientForm();
		ObjectsOfAdminObjectClass.EditClientNotes();
		ObjectsOfAdminObjectClass.UpdateAction();
	}
	
	@Test(priority = 6, enabled = false)
	public void EditClientMultipleFields() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB2");
		ObjectsOfAdminObjectClass.EditClientForm();
		ObjectsOfAdminObjectClass.EditClientNotes();
		ObjectsOfAdminObjectClass.EditClientAddress();
		ObjectsOfAdminObjectClass.UpdateAction();				
	}
	
	@Test(priority = 7, enabled = false)
	public void AddSubDivision() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB2");
		ObjectsOfAdminObjectClass.SubDivisionDetails("Test_SD1_Auto");
	}
	
	@Test(priority = 8, enabled = false)
	public void EditSubDivisionDL() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB2");
		ObjectsOfAdminObjectClass.EditSubDivision("Test_SD1_Auto");
	}
	
	
	@Test(priority = 8, enabled = false)
	public void AddPOC() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.POC("Test_Auto_FN1");
	}
	
	
	@Test(priority = 8, enabled = false)
	public void EditPOC() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.EditPOC("Test_Auto_FN1");
	}
	
	@Test(priority = 8, enabled = true)
	public void AddPO() throws InterruptedException, IOException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.PO("Test_PONo6_Auto", "Test_POName6_Auto", "USD");
	}
	
	@Test(priority = 8, enabled = false)
	public void EditPO() throws InterruptedException, IOException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.EditPO("Test_PONo_Auto");
	}
	
	@Test(priority = 8, enabled = false)
	public void AddPOBudget() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.AddPOBudget("Test_PONo_Auto");
	}
	
	@Test(priority = 8, enabled = false)
	public void ReducePOBudget() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.ReducePOBudget("Test_PONo_Auto");
	}
	
	
	@Test(priority = 8, enabled = false)
	public void ReStructurePOBudget() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_CLE_DB");
		ObjectsOfAdminObjectClass.RestructurePOBudget("Test_PONo_Auto");
	}
	
	@Test(priority = 9, enabled = false)
	public void DeleteClient() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_Auto");
		ObjectsOfAdminObjectClass.DeleteClient();
	}
	
	@Test(priority = 9, enabled = false)
	public void DeleteSubDivision() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_Auto");
		ObjectsOfAdminObjectClass.DeleteSubDivision("Test_SD1_Auto");
	}
	
	@Test(priority = 10, enabled = false)
	public void DeletePOC() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_Auto");
		ObjectsOfAdminObjectClass.DeletePOC("Test_Auto_FN1");
	}
	
	@Test(priority = 11, enabled = false)
	public void DeletePO() throws InterruptedException{
		ObjectsOfAdminObjectClass.SearchClient("Test_Auto");
		ObjectsOfAdminObjectClass.DeletePO("Test_PONo_Auto");
	}
	
	@Test(priority = 12, enabled = false)
	public void AddUser() throws InterruptedException{
		ObjectsOfAdminObjectClass.AddNewUserFTENo("Jr QC Offsite", "Quality Check", "8", "CM L1");
	}
	
	@Test(priority = 13, enabled = false)
	public void EditUser() throws InterruptedException{
		ObjectsOfAdminObjectClass.EditUser("Test SP");
	}
	
	@Test(priority = 14, enabled = false)
	public void AddBucket() throws InterruptedException{
		ObjectsOfAdminObjectClass.Bucket();
	}
	
	@Test(priority = 15, enabled = false)
	public void EditBucket() throws InterruptedException{
		ObjectsOfAdminObjectClass.EditBucket("Test_Auto_Bucket");
	}

	@Test(priority = 16, enabled = false)
	public void AddProjectType() throws InterruptedException{
		ObjectsOfAdminObjectClass.ProjectType();
	}
	
	@Test(priority = 17, enabled = false)
	public void DeleteProjectType() throws InterruptedException{
		ObjectsOfAdminObjectClass.DeleteProjectType("Test_Auto_ProjectType");
	}
	
	@Test(priority = 18, enabled = false)
	public void AddDeliverableType() throws InterruptedException{
		ObjectsOfAdminObjectClass.DeliverableType();
	}
	
	@Test(priority = 19, enabled = false)
	public void DeleteDelType() throws InterruptedException{
		ObjectsOfAdminObjectClass.DeleteDelType("TestP");
	}
	
	@Test(priority = 20, enabled = false)
	public void AdddTA() throws InterruptedException{
		ObjectsOfAdminObjectClass.TA();
	}
	
	@Test(priority = 21, enabled = false)
	public void DelereTA() throws InterruptedException{
		ObjectsOfAdminObjectClass.DeleteTA("Test_Auto_TA");
	}
	
	@Test(priority = 22, enabled = false)
	public void AddPracticeArea() throws InterruptedException{
		ObjectsOfAdminObjectClass.PracticeArea();
	}
	
	@Test(priority = 22, enabled = false)
	public void DeletePA() throws InterruptedException{
		ObjectsOfAdminObjectClass.DeletePracticeArea("Test_Auto_PracticeArea");
	}
	
}
